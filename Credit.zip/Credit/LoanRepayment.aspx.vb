﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Credit_LoanRepayment
    Inherits System.Web.UI.Page
    Dim cmd As SqlCommand
    Dim con As New SqlConnection
    Dim connection As String

    Public Shared Function convertToSaveDate(ByVal dbl As String) As String
        If dbl.ToString.Contains(".") Then
            dbl = dbl.ToString.Replace(".", "/")
        End If
        Return dbl
    End Function

    Public Shared Function convertToSaveFormat(ByVal dbl As String) As String
        If dbl.ToString.Contains(",") Then
            dbl = dbl.ToString.Replace(",", ".")
        End If
        Return dbl
    End Function

    Public Sub msgbox(ByVal strMessage As String)

        'finishes server processing, returns to client.
        Dim strScript As String = "<script language=JavaScript>"
        strScript += "window.alert(""" & strMessage & """);"
        strScript += "</script>"
        Dim lbl As New System.Web.UI.WebControls.Label
        lbl.Text = strScript
        Page.Controls.Add(lbl)
    End Sub

    Protected Sub btnRepay_Click(sender As Object, e As EventArgs) Handles btnRepay.Click
        Dim loanID = hidLoanID.Value
        Dim payNo = getInstalment(loanID)
        Dim datePaid = txtRepayDate.Text
        If isPartiallyPaid(loanID, payNo) Then
            'cmd = New SqlCommand("update LOAN_REPAYMENT_SCHEDULE set DATE_PAID=GETDATE(),AMOUNT_PAID=isnull(AMOUNT_PAID,0) + " & txtRepayAmt.Text & ",INST_PRINCIPAL_BALANCE=INST_PRINCIPAL_BALANCE + " & txtRepayAmt.Text & " where LOANID='" & loanID & "' and PAYMENT_NO='" & payNo & "'", con)
            cmd = New SqlCommand("update LOAN_REPAYMENT_SCHEDULE set DATE_PAID='" & datePaid & "',AMOUNT_PAID=isnull(AMOUNT_PAID,0) + " & txtRepayAmt.Text & ",INST_PRINCIPAL_BALANCE=INST_PRINCIPAL_BALANCE + " & txtRepayAmt.Text & " where LOANID='" & loanID & "' and PAYMENT_NO='" & payNo & "'", con)
        Else
            'cmd = New SqlCommand("update LOAN_REPAYMENT_SCHEDULE set DATE_PAID=GETDATE(),AMOUNT_PAID='" & txtRepayAmt.Text & "',INST_PRINCIPAL_BALANCE=" & txtRepayAmt.Text & "-PAYMENT where LOANID='" & loanID & "' and PAYMENT_NO='" & payNo & "'", con)
            cmd = New SqlCommand("update LOAN_REPAYMENT_SCHEDULE set DATE_PAID='" & datePaid & "',AMOUNT_PAID='" & txtRepayAmt.Text & "',INST_PRINCIPAL_BALANCE=" & txtRepayAmt.Text & "-PAYMENT where LOANID='" & loanID & "' and PAYMENT_NO='" & payNo & "'", con)
        End If
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        If cmd.ExecuteNonQuery Then
            Dim bbfwd = getBalBFwd(loanID)
            'insert into QUEST_TRANSACTIONS
            cmd = New SqlCommand("insert into QUEST_TRANSACTIONS (CUST_NO,LOANID,TRANS_DATE,TRANS_DESC,DEBIT,CREDIT,BAL_BFWD,BAL_CFWD) values ('" & hidCustNo.Value & "','" & loanID & "',GETDATE(),'Loan Repayment',0," & txtRepayAmt.Text & "," & bbfwd & "," & bbfwd & "-" & txtRepayAmt.Text & ")", con)
            cmd.ExecuteNonQuery()
            If isFullyPaid(loanID, payNo) Then
                updateFullyPaid(loanID, payNo)
                updateLoanRepaid(loanID)
            Else
            End If

            cmd = New SqlCommand("SaveAccountsTrxns", con)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@Type", "System Entry")
            cmd.Parameters.AddWithValue("@Category", "Repayment")
            'cmd.Parameters.AddWithValue("@Date", Today.Date.ToString)
            'cmd.Parameters.AddWithValue("@Ref", [Refrence])
            cmd.Parameters.AddWithValue("@Ref", loanID)
            cmd.Parameters.AddWithValue("@Desc", "Repayment")
            cmd.Parameters.AddWithValue("@Debit", 0.0)
            cmd.Parameters.AddWithValue("@Credit", txtRepayAmt.Text)
            cmd.Parameters.AddWithValue("@Account", "213/1") 'loan debtor
            cmd.Parameters.AddWithValue("@ContraAccount", "211/1") 'cash account
            cmd.Parameters.AddWithValue("@Status", 1)
            'cmd.Parameters.AddWithValue("@Other", [Loan Debtor Account Number])
            cmd.Parameters.AddWithValue("@Other", hidCustNo.Value)
            cmd.Parameters.AddWithValue("@BankAccID", "")
            cmd.Parameters.AddWithValue("@BankAccName", "")
            'cmd.Parameters.AddWithValue("@BatchRef", cmbBatchNo.SelectedItem.Text)
            cmd.Parameters.AddWithValue("@BatchRef", "")
            cmd.Parameters.AddWithValue("@TrxnDate", txtRepayDate.Text)

            Dim cmd1 = New SqlCommand("SaveAccountsTrxns", con)
            cmd1.CommandType = CommandType.StoredProcedure
            cmd1.Parameters.AddWithValue("@Type", "System Entry")
            cmd1.Parameters.AddWithValue("@Category", "Repayment")
            'cmd1.Parameters.AddWithValue("@Date", Today.Date.ToString)
            'cm1d.Parameters.AddWithValue("@Ref", [Refrence])
            cmd1.Parameters.AddWithValue("@Ref", loanID)
            cmd1.Parameters.AddWithValue("@Desc", "Repayment")
            cmd1.Parameters.AddWithValue("@Debit", txtRepayAmt.Text)
            cmd1.Parameters.AddWithValue("@Credit", 0.0)
            cmd1.Parameters.AddWithValue("@Account", "211/1")
            cmd1.Parameters.AddWithValue("@ContraAccount", "213/1")
            cmd1.Parameters.AddWithValue("@Status", 1)
            'cm1d.Parameters.AddWithValue("@Other", [Loan Debtor Account Number])
            cmd1.Parameters.AddWithValue("@Other", hidCustNo.Value)
            cmd1.Parameters.AddWithValue("@BankAccID", "")
            cmd1.Parameters.AddWithValue("@BankAccName", "")
            'cm1d.Parameters.AddWithValue("@BatchRef", cmbBatchNo.SelectedItem.Text)
            cmd1.Parameters.AddWithValue("@BatchRef", "")
            cmd1.Parameters.AddWithValue("@TrxnDate", txtRepayDate.Text)

            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            cmd.ExecuteNonQuery()
            cmd1.ExecuteNonQuery()
            con.Close()

            ClientScript.RegisterStartupScript(Me.GetType(), "Gritter", "<script type=""text/javascript"">$.gritter.add({title: 'Payment Successful!',text: 'The loan repayment has been captured successfully.',image: 'images/thumbs3.jpg'});</script>")
        Else
            ClientScript.RegisterStartupScript(Me.GetType(), "Gritter", "<script type=""text/javascript"">$.gritter.add({title: 'Error Adding Repayment!',text: 'There was an error capturing the loan repayment. Please try again.',image: 'images/error_button.png'});</script>")
        End If
        con.Close()
    End Sub

    Protected Sub btnSearchLoan_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearchLoan.Click
        createSchedule(txtLoanID.Text)
        getSchedule(txtLoanID.Text)
    End Sub

    Protected Sub btnSearchName_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearchName.Click
        Try
            'SecureBank.recordAction(btnSearchName.ID.ToString, "Searched by Name")
            'clearRepayParameters()
            cmd = New SqlCommand("select ID,SURNAME+' '+FORENAMES+' '+convert(varchar,CUSTOMER_NUMBER)+' '+convert(varchar,FIN_AMT) as DISPLAY from QUEST_APPLICATION where DISBURSED='1' AND SURNAME like '" & txtSearchName.Text & "%'", con)
            Dim ds As New DataSet
            Dim adp As New SqlDataAdapter
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "LOANS")
            If ds.Tables(0).Rows.Count > 0 Then
                lstLoans.DataSource = ds.Tables(0)
                lstLoans.DataTextField = "DISPLAY"
                lstLoans.DataValueField = "ID"
                lstLoans.Visible = True
            Else
                lstLoans.DataSource = Nothing
                lstLoans.Visible = False
                msgbox("Search name not found")
                txtLoanID.Text = ""
            End If
            lstLoans.DataBind()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub calcTotalRepayAmt(ByVal loanID As String)
        Try

        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Function calculateRepaymentTodate(ByVal loanID As String) As Double
        Try
            Dim amtPaid As Double
            amtPaid = 0
            cmd = New SqlCommand("select sum(isnull(PRINCIPAL,0)) as totalAmount from RECEIPT_SCHEDULE where LOANID='" & loanID & "'", con)
            closeConnection(con)
            con.Open()
            amtPaid = cmd.ExecuteScalar
            con.Close()
            Return amtPaid
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Function

    Protected Sub checkPenalty()
        Try
            ''for now only late payment

        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub clearAll()
        Try
            lblAddress.Text = ""
            lblLoanAmount.Text = ""
            lblName.Text = ""
            lblNumRepayments.Text = ""
            txtAmountPaid.Text = ""
            bdpPaymentDate.Text = ""
            txtLoanID.Text = ""
            txtReceiptNo.Text = ""
            panLoanDetails.Visible = False
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub closeConnection(ByVal conn As SqlConnection)
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Protected Sub createSchedule(ByVal loanID As String)
        Try
            'cmd = New SqlCommand("select * from RECEIPT_SCHEDULE where LOANID='" & loanID & "'", con)
            cmd = New SqlCommand("select * from LOAN_REPAYMENT_SCHEDULE where LOANID='" & loanID & "'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "DETAILS")
            If ds.Tables(0).Rows.Count > 0 Then
                ''schedule already in new table
            Else
                ''copy schedule to new table
                ''''''''''''''''''''''''''NO NEED TO DELETE NON-EXISTANT RECORD'''''''''''''''''''''''''''''''''''''
                'cmd = New SqlCommand("delete from LOAN_REPAYMENT_SCHEDULE WHERE LOANID='" & loanID & "'", con)
                'If con.State = ConnectionState.Open Then
                '    con.Close()
                'End If
                'con.Open()
                'cmd.ExecuteNonQuery()
                'con.Close()
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                cmd = New SqlCommand("insert into LOAN_REPAYMENT_SCHEDULE (LOANID,PAYMENT_NO,PAYMENT_DATE,PRINCIPAL,INTEREST,PAYMENT,CUMULATIVE_PRINCIPAL,CUMULATIVE_INTEREST,PRINCIPAL_BALANCE) select LOANID,PAYMENT_NO,PAYMENT_DATE,PRINCIPAL,INTEREST,PAYMENT,CUMULATIVE_PRINCIPAL,CUMULATIVE_INTEREST,PRINCIPAL_BALANCE from AMORTIZATION_SCHEDULE where LOANID='" & loanID & "'", con)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                If cmd.ExecuteNonQuery Then
                End If
                con.Close()
            End If
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub displayAmtDue(ByVal loanID As String)
        Try
            Dim paymtDue, intPaid, princiPaid As Double
            cmd = New SqlCommand("select isnull(sum(isnull(PAYMENT,0)),0) from LOAN_REPAYMENT_SCHEDULE where (FULLY_PAID<>1 or FULLY_PAID IS NULL) and loanid='" & loanID & "' and DATEDIFF(d, CONVERT(Date, PAYMENT_DATE, 103), CONVERT(Date, '" & Now.Date & "', 103))>0", con)
            'msgbox(cmd.CommandText)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            paymtDue = cmd.ExecuteScalar
            con.Close()

            Dim adp As SqlDataAdapter
            Dim ds As DataSet
            cmd = New SqlCommand("SELECT ISNULL(SUM(INTEREST),0) AS INTEREST, ISNULL(SUM(PRINCIPAL),0) AS PRINCIPAL FROM RECEIPT_SCHEDULE WHERE LOANID='" & loanID & "' AND SCHED_PAY_NO IN (SELECT PAYMENT_NO FROM LOAN_REPAYMENT_SCHEDULE WHERE LOANID='" & txtLoanID.Text & "' AND (FULLY_PAID<>1 OR FULLY_PAID IS NULL) AND DATEDIFF(d, CONVERT(Date, PAYMENT_DATE, 103), CONVERT(Date, '" & Now.Date & "', 103))>0)", con)
            adp = New SqlDataAdapter(cmd)
            ds = New DataSet
            adp.Fill(ds, "PAID")
            intPaid = ds.Tables(0).Rows(0).Item("INTEREST")
            princiPaid = ds.Tables(0).Rows(0).Item("PRINCIPAL")
            'lblAmountDue.Text = Math.Round(paymtDue - intPaid - princiPaid, 2) '.ToString.Format("###.##")
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Function getBalBFwd(loanID As String) As Double
        cmd = New SqlCommand("select ID,ISNULL(BAL_CFWD,0) as BAL from QUEST_TRANSACTIONS where LOANID='" & loanID & "' order by ID desc", con)
        Dim ds As New DataSet
        Dim adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "QT")
        If ds.Tables(0).Rows.Count > 0 Then
            Return ds.Tables(0).Rows(0).Item("BAL")
        Else
            Return 0
        End If
    End Function

    Protected Function getInstalment(LoanID As String) As Int16
        cmd = New SqlCommand("select MIN(PAYMENT_NO) from LOAN_REPAYMENT_SCHEDULE where LOANID='" & LoanID & "' and (FULLY_PAID=0 or FULLY_PAID IS NULL)", con)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        Dim payNo As Int16 = 0
        con.Open()
        payNo = cmd.ExecuteScalar
        con.Close()
        Return payNo
    End Function

    Protected Function getLoanAmount(ByVal loanID As String) As Double
        Try
            Dim amtPaid As Double
            amtPaid = 0
            cmd = New SqlCommand("select CLIENT_CREDITAPPLIED as totalAmount from Z_LOAN_SUBMISSION_DETAILS where LOAN_REQID='" & loanID & "'", con)
            closeConnection(con)
            con.Open()
            amtPaid = cmd.ExecuteScalar
            con.Close()
            Return amtPaid
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Function

    Protected Sub getSchedule(ByVal loanID As String)
        Try
            cmd = New SqlCommand("select * from QUEST_APPLICATION where ID='" & loanID & "' and DISBURSED=1", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "LOANS")
            Dim loanAmt As Double
            If ds.Tables(0).Rows.Count > 0 Then
                lblAddress.Text = ds.Tables(0).Rows(0).Item("ADDRESS")
                lblLoanAmount.Text = Math.Round(ds.Tables(0).Rows(0).Item("FIN_AMT"), 2)
                lblName.Text = ds.Tables(0).Rows(0).Item("SURNAME") & " " & ds.Tables(0).Rows(0).Item("FORENAMES")
                hidCustNo.Value = ds.Tables(0).Rows(0).Item("CUSTOMER_NUMBER")
                Try
                    lblNumRepayments.Text = FormatNumber(ds.Tables(0).Rows(0).Item("FIN_TENOR"), 0)
                    loanAmt = ds.Tables(0).Rows(0).Item("FIN_AMT")
                Catch ex As Exception
                    msgbox("Repayment Instructions not entered")
                End Try
                'cmd = New SqlCommand("select * from LOAN_REPAYMENT_SCHEDULE where LOANID='" & txtLoanID.Text & "' and FULLY_PAID=1", con)
                'cmd = New SqlCommand("select *,cast(PAYMENT as numeric(18,2)) as PAYMENT1,ISNULL(PAID,0) as PAID1,convert(varchar,PAY_DATE,105) as PAY_DATE1,convert(varchar,PAYMENT_DATE,105) as PAYMENT_DATE1 from AMORTIZATION_SCHEDULE where LOANID='" & txtLoanID.Text & "'", con)
                cmd = New SqlCommand("select *,cast(PAYMENT as numeric(18,2)) as PAYMENT1,ISNULL(FULLY_PAID,0) as PAID1,convert(varchar,DATE_PAID,105) as PAY_DATE1,convert(varchar,PAYMENT_DATE,105) as PAYMENT_DATE1,cast(AMOUNT_PAID as numeric(18,2)) as AMOUNT_PAID1,cast(INST_PRINCIPAL_BALANCE as numeric(18,2)) as INST_PRINCIPAL_BALANCE1 from LOAN_REPAYMENT_SCHEDULE where LOANID='" & txtLoanID.Text & "'", con)
                Dim ds1 As New DataSet
                Dim adp1 = New SqlDataAdapter(cmd)
                adp1.Fill(ds1, "REPAYMENT")
                If ds1.Tables(0).Rows.Count > 0 Then
                    grdRepaymt.DataSource = ds1.Tables(0)
                    grdRepaymt.DataBind()
                    hidLoanID.Value = loanID
                Else
                    'displayAmtDue(txtLoanID.Text)
                    grdRepaymt.DataSource = ds1.Tables(0)
                    grdRepaymt.DataBind()
                End If
                panLoanDetails.Visible = True
            Else
                clearAll()
                panLoanDetails.Visible = False
                msgbox("Loan not yet disbursed")
            End If
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub grdRepaymt_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grdRepaymt.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim chkView As CheckBox
            chkView = DirectCast(e.Row.FindControl("chkPaymtMade"), CheckBox)
            Dim lnk As LinkButton
            lnk = DirectCast(e.Row.FindControl("lnkCommit"), LinkButton)
            If chkView.Checked Then
                lnk.Enabled = False
                e.Row.BackColor = Drawing.Color.Azure
            Else
                lnk.Enabled = True
            End If
            'Dim modName = DirectCast(e.Row.FindControl("lblModuleName"), Label).Text
            'Dim modID = DirectCast(e.Row.FindControl("lblModuleID"), Label).Text
            'Dim userName = cmbSpecPermUser.SelectedValue.ToString
            'Dim roleName = getUserRole(userName)
            'chkView.Checked = getRolePermissions(roleName, modName)
            'If getRolePermissions(roleName, modName) Then
            '    chkView.Checked = True
            '    chkView.Enabled = False
            '    e.Row.BackColor = Drawing.Color.Azure
            'Else
            '    If getSpecialPermissions(userName, modID) Then
            '        chkView.Checked = True
            '        e.Row.BackColor = Drawing.Color.Cornsilk
            '    End If
            'End If
        End If
    End Sub

    Protected Function isFullyPaid(loanID As String, payNo As Int16) As Boolean
        cmd = New SqlCommand("select AMOUNT_PAID,PAYMENT from LOAN_REPAYMENT_SCHEDULE where LOANID='" & loanID & "' and PAYMENT_NO='" & payNo & "'", con)
        Dim ds As New DataSet
        Dim adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "LRS")
        Try
            If IsDBNull(ds.Tables(0).Rows(0).Item("AMOUNT_PAID")) Or ds.Tables(0).Rows(0).Item("AMOUNT_PAID") <= 0 Then
                Return False
            Else
                If ds.Tables(0).Rows(0).Item("AMOUNT_PAID") >= ds.Tables(0).Rows(0).Item("PAYMENT") <= 0 Then
                    Return True
                Else
                    Return False
                End If
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Protected Function isPartiallyPaid(loanID As String, payNo As Int16) As Boolean
        cmd = New SqlCommand("select AMOUNT_PAID from LOAN_REPAYMENT_SCHEDULE where LOANID='" & loanID & "' and PAYMENT_NO='" & payNo & "'", con)
        Dim ds As New DataSet
        Dim adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "LRS")
        Try
            If IsDBNull(ds.Tables(0).Rows(0).Item("AMOUNT_PAID")) Or ds.Tables(0).Rows(0).Item("AMOUNT_PAID") <= 0 Then
                isPartiallyPaid = False
            Else
                isPartiallyPaid = True
            End If
        Catch ex As Exception
            isPartiallyPaid = False
        End Try
    End Function

    Protected Sub lnkCommit_Click(ByVal sender As Object, ByVal e As EventArgs)
        Try
            'ClientScript.RegisterStartupScript(Me.GetType(), "HideLabel", "<script type=""text/javascript"">showRepaymentPopup()</script>")
            'Dim btn As LinkButton = TryCast(sender, LinkButton)

            'If btn Is Nothing Then
            '    Return
            'End If

            'Dim gvr As GridViewRow = TryCast(btn.NamingContainer, GridViewRow)

            'Dim lblLoanID As Label = TryCast(gvr.FindControl("lblLoanId"), Label)
            'Dim lblPayNo As Label = TryCast(gvr.FindControl("lblPayNo"), Label)

            'cmd = New SqlCommand("update AMORTIZATION_SCHEDULE set PAID=1,PAY_DATE=GETDATE(),PAY_CAPTURE_BY='" & Session("UserID") & "',PAY_CAPTURE_DATE=GETDATE() where LOANID='" & lblLoanID.Text & "' and PAYMENT_NO='" & lblPayNo.Text & "'", con)
            'If con.State = ConnectionState.Open Then
            '    con.Close()
            'End If
            'con.Open()
            'cmd.ExecuteNonQuery()
            'getSchedule(txtLoanID.Text)
            'con.Close()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub lstLoans_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstLoans.SelectedIndexChanged
        Try
            Dim loanID = lstLoans.SelectedValue
            txtLoanID.Text = loanID
            btnSearchLoan_Click(sender, New EventArgs)
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True
        con = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
        If Not IsPostBack Then

        End If
    End Sub
    Protected Sub updateFullyPaid(loanID As String, payNo As Int16)
        cmd = New SqlCommand("update LOAN_REPAYMENT_SCHEDULE set FULLY_PAID=1 where LOANID='" & loanID & "' and PAYMENT_NO='" & payNo & "'", con)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
        cmd = New SqlCommand("update AMORTIZATION_SCHEDULE set PAID=1,PAY_DATE=GETDATE(),PAY_CAPTURE_BY='" & Session("UserID") & "',PAY_CAPTURE_DATE=GETDATE() where LOANID='" & loanID & "' and PAYMENT_NO='" & payNo & "'", con)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        cmd.ExecuteNonQuery()
        getSchedule(txtLoanID.Text)
        con.Close()
    End Sub

    Protected Sub updateLoanRepaid(loanID As String)
        cmd = New SqlCommand("select distinct ISNULL(FULLY_PAID,0) from LOAN_REPAYMENT_SCHEDULE where LOANID='" & loanID & "'", con)
        Dim ds As New DataSet
        Dim adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "LRS")
        If ds.Tables(0).Rows.Count = 1 Then
            If ds.Tables(0).Rows(0).Item(0).ToString = "1" Then
                cmd = New SqlCommand("update QUEST_APPLICATION set STATUS='REPAID' where ID='" & loanID & "'", con)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End If
        End If
    End Sub
End Class