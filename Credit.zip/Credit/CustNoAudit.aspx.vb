﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Credit_CustNoAudit
    Inherits System.Web.UI.Page
    Dim cmd As SqlCommand
    Dim con As New SqlConnection
    Dim connection As String

    Public Sub msgbox(ByVal strMessage As String)

        'finishes server processing, returns to client.
        Dim strScript As String = "<script language=JavaScript>"
        strScript += "window.alert(""" & strMessage & """);"
        strScript += "</script>"
        Dim lbl As New System.Web.UI.WebControls.Label
        lbl.Text = strScript
        Page.Controls.Add(lbl)
    End Sub

    Protected Sub btnSearchECNo_Click(sender As Object, e As EventArgs) Handles btnSearchECNo.Click
        Try
            cmd = New SqlCommand("select ID,SURNAME+' '+FORENAMES+' *** '+ECNO+CD+' *** '+CUSTOMER_NUMBER+' *** '+ADDRESS as DISPLAY from CUSTOMER_DETAILS where ECNO='" & txtECNo.Text & "' or ECNO+CD='" & txtECNo.Text & "'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "LRS")
            If ds.Tables(0).Rows.Count > 0 Then
                lstCust.Visible = True
                lstCust.DataSource = ds.Tables(0)
                lstCust.DataTextField = "DISPLAY"
                lstCust.DataValueField = "ID"
            Else
                lstCust.DataSource = Nothing
            End If
            lstCust.DataBind()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub btnSearchName_Click(sender As Object, e As EventArgs) Handles btnSearchName.Click
        Try
            cmd = New SqlCommand("select ID,SURNAME+' '+FORENAMES+' *** '+ECNO+CD+' *** '+CUSTOMER_NUMBER+' *** '+ADDRESS as DISPLAY from CUSTOMER_DETAILS where SURNAME+' '+FORENAMES like '" & txtSearchName.Text & "%'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "LRS")
            If ds.Tables(0).Rows.Count > 0 Then
                lstCust.Visible = True
                lstCust.DataSource = ds.Tables(0)
                lstCust.DataTextField = "DISPLAY"
                lstCust.DataValueField = "ID"
            Else
                lstCust.DataSource = Nothing
            End If
            lstCust.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnUpdateCustNo_Click(sender As Object, e As EventArgs) Handles btnUpdateCustNo.Click
        Try
            If lstCust.SelectedIndex = -1 Then
                msgbox("Select customer to update")
                Exit Sub
            ElseIf Trim(txtQBAccNo.Text) = "" Then
                msgbox("Enter account number")
                Exit Sub
            ElseIf Trim(txtECNo.Text) = "" Then
                msgbox("Enter EC number")
                Exit Sub
            End If
            Dim ec As String = txtECNo.Text.Substring(0, 7)
            Dim cd As String = txtECNo.Text.Substring(7, 1)
            cmd = New SqlCommand("update_account_no", con)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@id", lstCust.SelectedValue)
            cmd.Parameters.AddWithValue("@qb_acc", txtQBAccNo.Text)
            cmd.Parameters.AddWithValue("@ec_no", ec)
            cmd.Parameters.AddWithValue("@cd", cd)
            If con.State <> ConnectionState.Closed Then
                con.Close()
            End If
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            msgbox("Account Number Updated")
            txtECNo.Text = ""
            txtQBAccNo.Text = ""
            txtSearchName.Text = ""
            lstCust.DataSource = Nothing
            lstCust.DataBind()
            lstCust.Visible = False
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub chkUpdate_CheckedChanged(sender As Object, e As EventArgs) Handles chkUpdate.CheckedChanged
        If chkUpdate.Checked Then
            lblQBAccNo.Visible = True
            txtQBAccNo.Visible = True
            btnUpdateCustNo.Visible = True
        Else
            lblQBAccNo.Visible = False
            txtQBAccNo.Visible = False
            btnUpdateCustNo.Visible = False
        End If
    End Sub

    Protected Sub lstCust_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstCust.SelectedIndexChanged

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True
        con = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
        If Not IsPostBack Then

        End If
    End Sub
End Class