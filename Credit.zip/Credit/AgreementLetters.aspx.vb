﻿Imports System
Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient
Imports CreditManager

Partial Class Credit_AgreementLetters
    Inherits System.Web.UI.Page
    Public Shared firstPayDate, paymentDate As Date
    Public Shared globLoanID As Double = 0
    Public Shared intRate, monthlyPrincipal, loanAmount, paymentPeriod, finalMonthlyPayment, interest As Double
    Public Shared isApproval As Double = 0
    Shared adp As New SqlDataAdapter
    Shared cmd As SqlCommand
    Shared con As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
    Shared isFarmer As String

    Public Sub clearAmortization(ByVal loanID As Double)
        Try
            cmd = New SqlCommand("select * from amortization_schedule where LOANID='" & loanID & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "AMORT")
            If ds.Tables(0).Rows.Count > 0 Then
                cmd = New SqlCommand("delete from amortization_schedule where LOANID='" & loanID & "'", con)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            Else

            End If
        Catch ex As Exception

        End Try
    End Sub

    Public Sub msgbox(ByVal strMessage As String)

        'finishes server processing, returns to client.
        Dim strScript As String = "<script language=JavaScript>"
        strScript += "window.alert(""" & strMessage & """);"
        strScript += "</script>"
        Dim lbl As New System.Web.UI.WebControls.Label
        lbl.Text = strScript
        Page.Controls.Add(lbl)
    End Sub

    Protected Sub amortizeStraight(ByVal loanID As String)
        clearAmortization(loanID)
        Dim cumPrincipal, cumInterest, cumAdmin As Double
        cmd = New SqlCommand("select *,convert(varchar,FIN_REPAY_DATE,106) as FIN_REPAY_DATE1 from QUEST_APPLICATION where ID='" & loanID & "'", con)
        Dim ds As New DataSet
        adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "LOANS")
        If ds.Tables(0).Rows.Count > 0 Then
            'Declare variables
            Dim intYears As Integer
            Dim dblMonthlyPayment As Double
            Dim dblRate As Double
            Dim dblAdmin As Double
            Dim intNumOfPayments As Integer
            Dim dblPrincipal As Double
            Dim dblConvertInterest As Double
            Dim dblConvertAdmin As Double
            'convert to monthly interest
            Dim intPmt As Integer = 1 'initialize integer
            Dim decDeductBalance As Decimal
            Dim interestPaid As Decimal
            Dim AdminPaid As Decimal
            Dim decNewBalance As Decimal
            Dim dblTotalPayments As Double
            Dim dblInterestToDecimal As Double 'convert interest % to decimal
            Dim dblAdminToDecimal As Double 'convert interest % to decimal
            'Dim table As DataTable = new DataTable("ParentTable")
            Dim tblAmort As DataTable = New DataTable("AmortizationTable")

            dblPrincipal = ds.Tables(0).Rows(0).Item("FIN_AMT")
            dblRate = ds.Tables(0).Rows(0).Item("FIN_INT_RATE")
            dblAdmin = ds.Tables(0).Rows(0).Item("FIN_ADMIN")
            firstPayDate = CDate(ds.Tables(0).Rows(0).Item("FIN_REPAY_DATE1")) '.ToShortDateString()
            intYears = ds.Tables(0).Rows(0).Item("FIN_TENOR")
            dblInterestToDecimal = dblRate / 100 'interest % to decimal form
            dblAdminToDecimal = dblAdmin '/ 100 'interest % to decimal form

            '2. calculate interest
            dblConvertInterest = dblInterestToDecimal ' / 12
            dblConvertAdmin = dblAdminToDecimal / intYears  ' / 12

            intNumOfPayments = intYears
            dblConvertAdmin = dblAdmin / intNumOfPayments

            'dblMonthlyPayment = (dblPrincipal * (dblConvertInterest) / (1 - (1 + (dblConvertInterest)) ^ -intNumOfPayments)) + dblConvertAdmin 'end monthtly payment
            dblMonthlyPayment = dblPrincipal * dblConvertInterest + dblConvertAdmin

            dblTotalPayments = (intNumOfPayments * dblMonthlyPayment) + dblPrincipal 'total amount of payments

            decNewBalance = dblPrincipal 'initialize principal balance
            'paymentDate = firstPayDate
            paymentDate = convertWeekendToFriday(firstPayDate)

            Do While intPmt <= intNumOfPayments
                If intPmt <> intNumOfPayments Then
                    interestPaid = decNewBalance * dblConvertInterest
                    AdminPaid = dblConvertAdmin
                    decDeductBalance = dblMonthlyPayment - interestPaid - AdminPaid
                    decNewBalance = decNewBalance - 0 ' decDeductBalance
                    cumPrincipal = 0 ' cumPrincipal + decDeductBalance
                    cumInterest = cumInterest + interestPaid
                    cumAdmin = cumAdmin + AdminPaid

                    cmd = New SqlCommand("insert into AMORTIZATION_SCHEDULE(LOANID,PAYMENT_NO,PAYMENT_DATE,PRINCIPAL,INTEREST,ADMIN_CHARGE,CUMULATIVE_PRINCIPAL,CUMULATIVE_INTEREST,PRINCIPAL_BALANCE,PAYMENT,CUMULATIVE_ADMIN) values ('" & loanID & "','" & intPmt & "','" & DateFormat.getSaveDate(paymentDate) & "','" & decDeductBalance & "','" & interestPaid & "','" & AdminPaid & "','" & cumPrincipal & "','" & cumInterest & "','" & decNewBalance & "','" & dblMonthlyPayment & "','" & cumAdmin & "')", con)
                    If con.State = ConnectionState.Open Then
                        con.Close()
                    End If
                    con.Open()
                    cmd.ExecuteNonQuery()
                    con.Close()

                    'paymentDate = DateAdd(DateInterval.Month, 1, paymentDate).ToShortDateString()
                    paymentDate = convertWeekendToFriday(DateAdd(DateInterval.Month, 1, paymentDate).ToShortDateString())
                    intPmt += 1
                Else
                    interestPaid = decNewBalance * dblConvertInterest
                    AdminPaid = dblConvertAdmin
                    'decDeductBalance = dblMonthlyPayment - interestPaid - AdminPaid
                    decNewBalance = decNewBalance - dblPrincipal
                    cumPrincipal = cumPrincipal + dblPrincipal
                    cumInterest = cumInterest + interestPaid
                    cumAdmin = cumAdmin + AdminPaid

                    cmd = New SqlCommand("insert into AMORTIZATION_SCHEDULE(LOANID,PAYMENT_NO,PAYMENT_DATE,PRINCIPAL,INTEREST,ADMIN_CHARGE,CUMULATIVE_PRINCIPAL,CUMULATIVE_INTEREST,PRINCIPAL_BALANCE,PAYMENT,CUMULATIVE_ADMIN) values ('" & loanID & "','" & intPmt & "','" & DateFormat.getSaveDate(paymentDate) & "','" & decDeductBalance & "','" & interestPaid & "','" & AdminPaid & "','" & cumPrincipal & "','" & cumInterest & "','" & decNewBalance & "','" & dblMonthlyPayment & "','" & cumAdmin & "')", con)
                    If con.State = ConnectionState.Open Then
                        con.Close()
                    End If
                    con.Open()
                    cmd.ExecuteNonQuery()
                    con.Close()

                    'paymentDate = DateAdd(DateInterval.Month, 1, paymentDate).ToShortDateString()
                    paymentDate = convertWeekendToFriday(DateAdd(DateInterval.Month, 1, paymentDate).ToShortDateString())
                    intPmt += 1
                End If
            Loop
        End If
    End Sub

    Protected Sub btnSaveCreditParameters_Click(sender As Object, e As EventArgs) Handles btnSaveCreditParameters.Click

        'cmd = New SqlCommand("update QUEST_APPLICATION set [REPAYMENT_OPTION]='" & rdbRepayOption.SelectedValue & "',[REPAYMENT_PERIOD]='" & txtRepayPeriod.Text & "',[INTEREST_RATE]='" & convertToSaveFormat(txtIntRate.Text) & "',[FIRST_REPAYMENT_DATE]='" & DateFormat.getSaveDate(bdp1stPayDate.SelectedDate.ToShortDateString) & "' where ID='" & txtLoanID.Text & "'", con)
        cmd = New SqlCommand("update QUEST_APPLICATION set [FIN_REPAY_OPT]='" & rdbRepayOption.SelectedValue & "',[FIN_TENOR]='" & txtRepayPeriod.Text & "',[FIN_INT_RATE]='" & txtIntRate.Text & "',[FIN_ADMIN]='" & txtAdminCharge.Text & "',[FIN_REPAY_DATE]='" & txt1stPayDate.Text & "' where ID='" & ViewState("globLoanID") & "'", con)
        'msgbox(cmd.CommandText)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        Try
            cmd.ExecuteNonQuery()
            'msgbox("Repayment instructions saved")
            createAmortizationOptions(ViewState("globLoanID"))
            'Response.Redirect("AgreementLetters.aspx?ID=" & ViewState("globLoanID") & "&pop=1", False)
        Catch ex As Exception
            ErrorLogging.WriteLogFile(Session("UserId"), "AgreementLetters", ex.Message)
            CreditManager.notify("Error creating amortization schedule", "error")
            'Response.Redirect("AgreementLetters.aspx?ID=" & ViewState("globLoanID") & "&pop=0", False)
            'ClientScript.RegisterStartupScript(Me.GetType(), "Gritter", "<script type=""text/javascript"">$.gritter.add({title: 'Error saving instruction!',text: 'The amortization instructions could not be saved. Please make sure all parameters are entered correctly with the right format and try again.',image: 'images/error_button.png'});</script>")
        Finally
            con.Close()
        End Try
    End Sub

    Protected Sub btnSearchLoanID_Click(sender As Object, e As EventArgs) Handles btnSearchLoanID.Click
        Try
            If Trim(Session("SessionID")) = "" Or IsDBNull(Session("SessionID")) Then
                Response.Redirect("~/logout.aspx")
            ElseIf Trim(txtLoanID.Text) = "" Or Not IsNumeric(txtLoanID.Text) Then
                notify("Enter a valid loan ID", "error")
            Else
                'check if is amortized
                'notify(isAmortized(txtLoanID.Text), "error")
                'If isLoanOfficer() Then
                'notify("You cannot print agreement letters while logged in as loan officer!", "error")
                'Else
                ViewState("globLoanID") = txtLoanID.Text
                If isAmortized(txtLoanID.Text) = 0 Then
                    notify("Requested Loan ID not found", "error")
                ElseIf isAmortized(txtLoanID.Text) = 2 Then
                    loadAgreements()
                ElseIf isAmortized(txtLoanID.Text) = 1 Then
                    notify("This loan application has not yet been amortized. Create amortization schedule first.", "warning")
                    ClientScript.RegisterStartupScript(Me.GetType(), "showAmortization", "<script type=""text/javascript"">showAmortization();</script>")
                End If
                'End If
                'SecureBank.recordAction(btnSearchLoanID.ID.ToString, "Searched by Loan ID")
            End If
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub btnSearchName_Click(sender As Object, e As EventArgs) Handles btnSearchName.Click
        Try
            'SecureBank.recordAction(btnSearchName.ID.ToString, "Searched by Name")
            clearAgreements()
            cmd = New SqlCommand("select ID,SURNAME+' '+FORENAMES+' --- '+convert(varchar,CUSTOMER_NUMBER)+' --- '+ADDRESS+' --- '+convert(varchar,format(FIN_AMT,'c')) as DISPLAY from QUEST_APPLICATION where SURNAME like '" & txtSearchName.Text & "%' and [STATUS]<>'REJECTED'", con)
            Dim ds As New DataSet
            Dim adp As New SqlDataAdapter
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "LOANS")
            If ds.Tables(0).Rows.Count > 0 Then
                lstLoans.DataSource = ds.Tables(0)
                lstLoans.DataTextField = "DISPLAY"
                lstLoans.DataValueField = "ID"
                lstLoans.Visible = True
            Else
                lstLoans.DataSource = Nothing
                lstLoans.Visible = False
                'msgbox("Search name not found")
                ClientScript.RegisterStartupScript(Me.GetType(), "Gritter", "<script type=""text/javascript"">$.gritter.add({title: 'Name not found!',text: 'There is no record which matches the entered name.',image: 'images/error_button.png'});</script>")
                txtLoanID.Text = ""
            End If
            lstLoans.DataBind()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub clearAgreements()
        repAgreements.DataSource = Nothing
        repAgreements.DataBind()
    End Sub

    Protected Function convertWeekendToFriday(payDate As Date) As Date
        While payDate.DayOfWeek = DayOfWeek.Saturday Or payDate.DayOfWeek = DayOfWeek.Sunday Or isHoliday(payDate)
            payDate = payDate.AddDays(-1)
        End While
        Return payDate
    End Function

    Protected Sub createAmortizationOptions(ByVal loanID As String)
        Try
            cmd = New SqlCommand("select * from QUEST_APPLICATION where ID='" & loanID & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "LOANS")
            If ds.Tables(0).Rows.Count > 0 Then
                'If ds.Tables(0).Rows(0).Item("FIN_REPAY_OPT") = "Interest" Then
                '    'amortizeSimple(loanID)
                '    cmd = New SqlCommand("sp_amortize_simple_daily", con)
                '    cmd.CommandType = CommandType.StoredProcedure
                '    cmd.Parameters.AddWithValue("@loanID", loanID)
                'ElseIf ds.Tables(0).Rows(0).Item("FIN_REPAY_OPT") = "Balance" Then
                '    'amortizeNormal(loanID)
                '    cmd = New SqlCommand("sp_amortize_normal_daily", con)
                '    cmd.CommandType = CommandType.StoredProcedure
                '    cmd.Parameters.AddWithValue("@loanID", loanID)
                'ElseIf isFarmer = "1" Then
                '    amortizeStraight(loanID)
                'Else
                'amortizeNormal(loanID)
                cmd = New SqlCommand("sp_amortize_normal_daily", con)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@loanID", loanID)
                'End If
                If con.State <> ConnectionState.Closed Then
                    con.Close()
                End If
                con.Open()
                If cmd.ExecuteNonQuery() Then
                    CreditManager.notify("Amortization created", "success")
                End If
                con.Close()
            End If
        Catch ex As Exception
            'amortizeNormal(loanID)
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- createAmortizationOptions()", ex.ToString)
        End Try
    End Sub

    Protected Function isAmortized(loanID As String) As Integer
        Dim cmdApp = New SqlCommand("select * from QUEST_APPLICATION where ID='" & loanID & "'", con)
        Dim dsApp As New DataSet
        adp = New SqlDataAdapter(cmdApp)
        adp.Fill(dsApp, "qa")
        If dsApp.Tables(0).Rows.Count > 0 Then
            cmd = New SqlCommand("select * from AMORTIZATION_SCHEDULE where LOANID='" & loanID & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "armo")
            If ds.Tables(0).Rows.Count > 0 Then
                Return 2
            Else
                Return 1
            End If
        Else
            Return 0
        End If

    End Function

    Protected Function isHoliday(payDate As Date) As Boolean
        cmd = New SqlCommand("select ID from HOLIDAYS where HOLIDAY_DATE='" & payDate & "'", con)
        Dim ds As New DataSet
        adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "holiday")
        If ds.Tables(0).Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Protected Function isLoanOfficer() As Boolean
        'cmd = New SqlCommand("select * from AMORTIZATION_SCHEDULE where LOANID='" & userID & "'", con)
        'Dim ds As New DataSet
        'adp = New SqlDataAdapter(cmd)
        'adp.Fill(ds, "armo")
        'If ds.Tables(0).Rows.Count > 0 Then
        '    Return True
        'Else
        '    Return False
        'End If
        If Session("ROLE") = "4041" Then
            Return True
        Else
            Return False
        End If
    End Function

    Protected Sub loadAgreements()
        Try
            cmd = New SqlCommand("select isnull([SUB_INDIVIDUAL],'') as [SUB_INDIVIDUAL],[FIN_AMT],[FIN_TENOR],[FIN_INT_RATE],[FIN_ADMIN],[FIN_REPAY_DATE],[FIN_REPAY_OPT],[CUSTOMER_TYPE],[CUSTOMER_NUMBER],[MD_ID],ISNULL(ASSET_NAME,'') as [ASSET_NAME] from QUEST_APPLICATION where ID='" & txtLoanID.Text & "' and [STATUS]<>'REJECTED'", con)
            'msgbox(cmd.CommandText)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "CREDIT")
            repAgreements.DataSource = Nothing
            repAgreements.DataBind()
            If ds.Tables(0).Rows.Count > 0 Then
                Try
                    Dim dt As New DataTable
                    dt.Columns.Add("navURL")
                    dt.Columns.Add("lnkText")
                    'If IsDBNull(ds.Tables(0).Rows(0).Item("MD_ID")) Then
                    '    msgbox("This application has not yet been approved")
                    'Else
                    If Trim(ds.Tables(0).Rows(0).Item("ASSET_NAME")) <> "" Then
                        'dt.Rows.Add("rptAcknowledgement.aspx?id=" & txtLoanID.Text & "&asset=1", "Acknowledgement of Debt")
                        dt.Rows.Add("rptAssetFinancing.aspx?id=" & txtLoanID.Text & "&asset=1", "Acknowledgement of Debt")

                    ElseIf ds.Tables(0).Rows(0).Item("CUSTOMER_TYPE") = "Group" Then
                        dt.Rows.Add("rptFormLetter.aspx?id=" & txtLoanID.Text & "&typ=grp&cust=" & ds.Tables(0).Rows(0).Item("CUSTOMER_NUMBER") & "", "Form Letter")
                        dt.Rows.Add("rptAcknowledgement.aspx?id=" & txtLoanID.Text & "&typ=grp&cust=" & ds.Tables(0).Rows(0).Item("CUSTOMER_NUMBER") & "", "Acknowledgement of Debt")
                    Else
                        If ds.Tables(0).Rows(0).Item("SUB_INDIVIDUAL") = "SSB" Then
                            'dt.Rows.Add("SSBSalaryDeduction.aspx?id=" & txtLoanID.Text & "", "SSB Deduction Form")
                            dt.Rows.Add("rptFormLetter.aspx?id=" & txtLoanID.Text & "", "Form Letter")
                            dt.Rows.Add("rptAcknowledgeSSB.aspx?id=" & txtLoanID.Text & "", "Acknowledgement of Debt")
                        Else
                            dt.Rows.Add("rptFormLetter.aspx?id=" & txtLoanID.Text & "", "Form Letter")
                            dt.Rows.Add("rptAcknowledgement.aspx?id=" & txtLoanID.Text & "", "Acknowledgement of Debt")
                        End If
                    End If
                    repAgreements.DataSource = dt
                    repAgreements.DataBind()
                    'End If
                Catch ex As Exception
                    msgbox(ex.Message)
                End Try
            Else
                'ClientScript.RegisterStartupScript(Me.GetType(), "Gritter", "<script type=""text/javascript"">$.gritter.add({title: 'Loan ID not found!',text: 'There is no record which matches the entered Loan ID.',image: 'images/error_button.png'});</script>")
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub loadRepayParameters()
        Try
            Dim settInt As String = ""
            Dim repayOpt As String = ""
            Dim repayPer, intRate, adminCharge As Double
            Dim firstPayDate As String = ""
            cmd = New SqlCommand("select [FIN_AMT],[FIN_TENOR],[FIN_INT_RATE],[FIN_ADMIN],convert(varchar(30),[FIN_REPAY_DATE],113) as [FIN_REPAY_DATE],[FIN_REPAY_OPT],[CUSTOMER_TYPE] from QUEST_APPLICATION where ID='" & ViewState("globLoanID") & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "CREDIT")
            If ds.Tables(0).Rows.Count > 0 Then
                Try
                    repayPer = ds.Tables(0).Rows(0).Item("FIN_TENOR")
                    intRate = ds.Tables(0).Rows(0).Item("FIN_INT_RATE")
                    firstPayDate = ds.Tables(0).Rows(0).Item("FIN_REPAY_DATE")
                    adminCharge = ds.Tables(0).Rows(0).Item("FIN_ADMIN")
                    If ds.Tables(0).Rows(0).Item("CUSTOMER_TYPE") = "Farmer" Then
                        isFarmer = "1"
                    End If
                Catch ex As Exception
                    'msgbox(ex.Message)
                End Try
            Else
                'ClientScript.RegisterStartupScript(Me.GetType(), "Gritter", "<script type=""text/javascript"">$.gritter.add({title: 'Loan ID not found!',text: 'There is no record which matches the entered Loan ID.',image: 'images/error_button.png'});</script>")
            End If
            txtRepayPeriod.Text = repayPer
            txtIntRate.Text = intRate
            txtAdminCharge.Text = adminCharge
            txt1stPayDate.Text = firstPayDate
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub lstLoans_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstLoans.SelectedIndexChanged
        Try
            Dim loanID = lstLoans.SelectedValue
            txtLoanID.Text = loanID
            ViewState("globLoanID") = loanID
            loadRepayParameters()
            btnSearchLoanID_Click(sender, New EventArgs)
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True
        If Not IsPostBack Then
            If Trim(Request.QueryString("ID")) = "" Then
            Else
                'If Request.QueryString("pop") = "1" Then
                '    ClientScript.RegisterStartupScript(Me.GetType(), "amortizationSuccess", "<script type=""text/javascript"">amortizationSuccess();</script>")
                'ElseIf Request.QueryString("pop") = "0" Then
                '    ClientScript.RegisterStartupScript(Me.GetType(), "amortizationError", "<script type=""text/javascript"">amortizationError();</script>")
                'End If
                ViewState("globLoanID") = Request.QueryString("ID")
                isApproval = Request.QueryString("App")
                txtLoanID.Text = ViewState("globLoanID")
                If isApproval Then
                    lblReturnApproval.Text = "<a href='ApplicationApproval.aspx?id=" & ViewState("globLoanID") & "'>Return to Loan Approval</a>"
                End If
                loadAgreements()
                'btnSearchLoanID_Click(sender, New EventArgs)
            End If
        End If
    End Sub
End Class