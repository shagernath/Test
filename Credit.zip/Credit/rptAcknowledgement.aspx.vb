﻿Imports CrystalDecisions.CrystalReports.Engine

Partial Class Credit_rptAcknowledgement
    Inherits System.Web.UI.Page
    Dim cryRpt As ReportDocument = New ReportDocument()

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Session("UserID") = String.Empty Then
                'not logged in redirect to login page
                Response.Redirect("~/Login.aspx", False)
                Exit Sub
            End If
            'Dim DecQuery As New BankEncryption64

            'Dim query = DecQuery.Decrypt(Request.QueryString("qry").Replace(" ", "+"), "lovely12345")
            Dim lnID = Request.QueryString("ID")

            Dim kk As String = ""
            If Request.QueryString("asset") = "1" Then
                kk = Server.MapPath("rptAssetFinancing.rpt")
                cryRpt.Load(kk)
                'cryRpt.SetDatabaseLogon("sa", "")
                'cryRpt.SetParameterValue(0, query)
                cryRpt.SetParameterValue(0, lnID)

            ElseIf Request.QueryString("typ") = "grp" Then
                Dim cust = Request.QueryString("cust")
                kk = Server.MapPath("rptAcknowledgementGrp.rpt")
                cryRpt.Load(kk)
                cryRpt.SetParameterValue("loanID", lnID)
                cryRpt.SetParameterValue("custno", cust)
            Else
                kk = Server.MapPath("rptAcknowledgement.rpt")
                cryRpt.Load(kk)
                'cryRpt.SetDatabaseLogon("sa", "")
                'cryRpt.SetParameterValue(0, query)
                cryRpt.SetParameterValue(0, lnID)
            End If
            CrystalReportViewer1.ReportSource = cryRpt
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Unload
        cryRpt.Close()
        cryRpt.Dispose()
        GC.Collect()
    End Sub
End Class