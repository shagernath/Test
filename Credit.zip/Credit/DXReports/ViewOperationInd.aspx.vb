﻿Partial Class Credit_DXReports_ViewOperationInd
    Inherits System.Web.UI.Page

End Class