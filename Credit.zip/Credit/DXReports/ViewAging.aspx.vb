﻿Partial Class Credit_DXReports_ViewAging
    Inherits System.Web.UI.Page

End Class