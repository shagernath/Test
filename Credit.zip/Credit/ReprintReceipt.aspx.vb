﻿Partial Class Credit_ReprintReceipt
    Inherits System.Web.UI.Page

End Class