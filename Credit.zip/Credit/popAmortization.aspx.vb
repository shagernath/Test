﻿Imports System
Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient
Imports BankString

Partial Class Credit_popAmortization
    Inherits System.Web.UI.Page
    Public Shared firstPayDate, paymentDate As Date
    Public Shared globLoanID As Double = 0
    Public Shared intRate, monthlyPrincipal, loanAmount, paymentPeriod, finalMonthlyPayment, interest As Double
    Public Shared isApproval As Double = 0
    Shared actionTime As Date
    Shared adp As New SqlDataAdapter
    Shared cmd As SqlCommand
    Shared con As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
    Shared IPAdd, machName, browser, url, isFarmer As String
    Public Sub clearAmortization(ByVal loanID As Double)
        Try
            cmd = New SqlCommand("select * from amortization_schedule where LOANID='" & loanID & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "AMORT")
            If ds.Tables(0).Rows.Count > 0 Then
                cmd = New SqlCommand("delete from amortization_schedule where LOANID='" & loanID & "'", con)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            Else

            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub amortizeNormal(ByVal loanID As String)
        clearAmortization(loanID)
        Dim cumPrincipal, cumInterest, cumAdmin As Double
        cmd = New SqlCommand("select * from QUEST_APPLICATION where ID='" & loanID & "'", con)
        Dim ds As New DataSet
        adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "LOANS")
        If ds.Tables(0).Rows.Count > 0 Then
            'Declare variables
            Dim intYears As Integer
            Dim dblMonthlyPayment As Double
            Dim dblRate As Double
            Dim dblAdmin As Double
            Dim intNumOfPayments As Integer
            Dim dblPrincipal As Double
            Dim dblConvertInterest As Double
            Dim dblConvertAdmin As Double
            'convert to monthly interest
            Dim intPmt As Integer = 1 'initialize integer
            Dim decDeductBalance As Decimal
            Dim interestPaid As Decimal
            Dim AdminPaid As Decimal
            Dim decNewBalance As Decimal
            Dim dblTotalPayments As Double
            Dim dblInterestToDecimal As Double 'convert interest % to decimal
            Dim dblAdminToDecimal As Double 'convert interest % to decimal
            'Dim table As DataTable = new DataTable("ParentTable")
            Dim tblAmort As DataTable = New DataTable("AmortizationTable")

            'dblPrincipal = ds.Tables(0).Rows(0).Item("CLIENT_CREDITAPPLIED")
            'dblRate = ds.Tables(0).Rows(0).Item("INTEREST_RATE")
            'firstPayDate = ds.Tables(0).Rows(0).Item("FIRST_REPAYMENT_DATE") '.ToShortDateString()
            'intYears = ds.Tables(0).Rows(0).Item("REPAYMENT_PERIOD")
            dblPrincipal = ds.Tables(0).Rows(0).Item("FIN_AMT")
            dblRate = ds.Tables(0).Rows(0).Item("FIN_INT_RATE")
            dblAdmin = ds.Tables(0).Rows(0).Item("FIN_ADMIN")
            firstPayDate = ds.Tables(0).Rows(0).Item("FIN_REPAY_DATE") '.ToShortDateString()
            intYears = ds.Tables(0).Rows(0).Item("FIN_TENOR")
            'intMonths = ds.Tables(0).Rows(0).Item("FIN_TENOR")

            ''get user input
            'dblPrincipal = Val(txtPrincipal.Text)
            'dblRate = Val(txtInterest.Text)

            'intYears = Val(txtYears.Text)

            ''''''''''''''''''process monthly payment lines 36 - 41'''''''''''''''''
            '***********************************************************************
            '1. convert the interest rate to decimal form                          *
            '2. Calculate the interest ( i / 12 )                                  *
            '3. Calculate the total number of loan payments (n * 12)               *
            '4. Calculate monthly payment using formula:                           *
            '   M = P * i / ( 1 - ( 1 + i ) ^ -n)                                  *
            '***********************************************************************
            '1. convert interest rate to decimal form
            dblInterestToDecimal = dblRate / 100 'interest % to decimal form
            dblAdminToDecimal = dblAdmin '/ 100 'interest % to decimal form

            '2. calculate interest
            dblConvertInterest = dblInterestToDecimal ' / 12
            dblConvertAdmin = dblAdminToDecimal / intYears  ' / 12

            '3. calculate the total number of payments (n * 12)
            ''change intNumOfPayments to months
            ''''''''''''''''''''''''''''''''''''
            'intNumOfPayments = intYears * 12
            intNumOfPayments = intYears
            dblConvertAdmin = dblAdmin / intNumOfPayments
            '4. Calculate monthly payment using formula
            'dblMonthlyPayment = dblPrincipal * dblConvertInterest / (1 - (1 + dblConvertInterest) ^ -intNumOfPayments) 'end monthtly payment
            'dblMonthlyPayment = dblPrincipal * (dblConvertInterest + dblConvertAdmin) / (1 - (1 + (dblConvertInterest + dblConvertAdmin)) ^ -intNumOfPayments) 'end monthtly payment

            dblMonthlyPayment = (dblPrincipal * (dblConvertInterest) / (1 - (1 + (dblConvertInterest)) ^ -intNumOfPayments)) + dblConvertAdmin 'end monthtly payment
            'dblMonthlyPayment = Math.Round(dblMonthlyPayment, 2)

            'output monthly payment to user
            'lblMonthly.Text = "Monthly Payment: " & String.Format("{0:C}", dblMonthlyPayment)
            dblTotalPayments = intNumOfPayments * dblMonthlyPayment 'total amount of payments
            'lblTotal.Text = "Total Payment: " & String.Format("{0:C}", dblTotalPayments)
            decNewBalance = dblPrincipal 'initialize principle balance
            'paymentDate = firstPayDate
            paymentDate = convertWeekendToFriday(firstPayDate)

            Do While intPmt <= intNumOfPayments
                interestPaid = decNewBalance * dblConvertInterest
                AdminPaid = dblConvertAdmin
                'decDeductBalance = dblMonthlyPayment - interestPaid
                decDeductBalance = dblMonthlyPayment - interestPaid - AdminPaid
                decNewBalance = decNewBalance - decDeductBalance
                cumPrincipal = cumPrincipal + decDeductBalance
                cumInterest = cumInterest + interestPaid
                cumAdmin = cumAdmin + AdminPaid

                'cmd = New SqlCommand("insert into AMORTIZATION_SCHEDULE(LOANID,PAYMENT_NO,PAYMENT_DATE,PRINCIPAL,INTEREST,CUMULATIVE_PRINCIPAL,CUMULATIVE_INTEREST,PRINCIPAL_BALANCE,PAYMENT) values ('" & loanID & "','" & intPmt & "','" & DateFormat.getSaveDate(paymentDate) & "','" & convertToSaveFormat(decDeductBalance) & "','" & convertToSaveFormat(interestPaid) & "','" & convertToSaveFormat(cumPrincipal) & "','" & convertToSaveFormat(cumInterest) & "','" & convertToSaveFormat(decNewBalance) & "','" & convertToSaveFormat(dblMonthlyPayment) & "')", con)
                cmd = New SqlCommand("insert into AMORTIZATION_SCHEDULE(LOANID,PAYMENT_NO,PAYMENT_DATE,PRINCIPAL,INTEREST,ADMIN_CHARGE,CUMULATIVE_PRINCIPAL,CUMULATIVE_INTEREST,PRINCIPAL_BALANCE,PAYMENT,CUMULATIVE_ADMIN) values ('" & loanID & "','" & intPmt & "','" & DateFormat.getSaveDate(paymentDate) & "','" & decDeductBalance & "','" & interestPaid & "','" & AdminPaid & "','" & cumPrincipal & "','" & cumInterest & "','" & decNewBalance & "','" & dblMonthlyPayment & "','" & cumAdmin & "')", con)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                'msgbox(cmd.CommandText)
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()

                'paymentDate = DateAdd(DateInterval.Month, 1, paymentDate).ToShortDateString()
                paymentDate = convertWeekendToFriday(DateAdd(DateInterval.Month, 1, paymentDate).ToShortDateString())
                'tblAmort.Rows.Add(tRow)
                intPmt += 1
            Loop
        End If
    End Sub

    Protected Sub amortizeSimple(ByVal loanID As String)
        clearAmortization(loanID)
        Dim cumPrincipal, principalBalance, cumInterest, cumAdmin As Double
        cmd = New SqlCommand("select * from QUEST_APPLICATION where ID='" & loanID & "'", con)
        Dim ds As New DataSet
        adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "LOANS")
        If ds.Tables(0).Rows.Count > 0 Then
            'Declare variables
            'Dim intYears As Integer
            Dim intMonths As Integer
            Dim dblMonthlyPayment As Double
            Dim dblRate As Double
            Dim dblAdmin As Double
            Dim intNumOfPayments As Integer
            Dim dblPrincipal As Double
            Dim dblConvertInterest As Double
            Dim dblConvertAdmin As Double
            'convert to monthly interest
            Dim intPmt As Integer = 1 'initialize integer
            Dim decDeductBalance As Decimal
            Dim interestPaid As Decimal
            Dim adminPaid As Decimal
            Dim decNewBalance As Decimal
            Dim dblTotalPayments As Double
            Dim dblInterestToDecimal As Double 'convert interest % to decimal
            Dim dblAdminToDecimal As Double 'convert admin charge % to decimal
            'Dim table As DataTable = new DataTable("ParentTable")
            Dim tblAmort As DataTable = New DataTable("AmortizationTable")

            dblPrincipal = ds.Tables(0).Rows(0).Item("FIN_AMT")
            dblRate = ds.Tables(0).Rows(0).Item("FIN_INT_RATE")
            firstPayDate = ds.Tables(0).Rows(0).Item("FIN_REPAY_DATE") '.ToShortDateString()
            'intYears = ds.Tables(0).Rows(0).Item("FIN_TENOR")
            intMonths = ds.Tables(0).Rows(0).Item("FIN_TENOR")
            dblAdmin = ds.Tables(0).Rows(0).Item("FIN_ADMIN")

            'Dim totalInterest = (dblPrincipal / dblRate) * intMonths
            'Dim totalAdmin = (dblPrincipal / dblAdmin) * intMonths
            Dim totalInterest = (dblPrincipal * (dblRate / 100)) * intMonths
            Dim totalAdmin = dblAdmin '(dblPrincipal * (dblAdmin / 100)) * intMonths
            'Dim totalPayment = dblPrincipal + totalInterest
            Dim totalPayment = dblPrincipal + totalInterest + totalAdmin
            interestPaid = totalInterest / intMonths
            adminPaid = totalAdmin / intMonths
            ''get user input
            'dblPrincipal = Val(txtPrincipal.Text)
            'dblRate = Val(txtInterest.Text)

            'intYears = Val(txtYears.Text)

            ''''''''''''''''''process monthly payment lines 36 - 41'''''''''''''''''
            '***********************************************************************
            '1. convert the interest rate to decimal form                          *
            '2. Calculate the interest ( i / 12 )                                  *
            '3. Calculate the total number of loan payments (n * 12)               *
            '4. Calculate monthly payment using formula:                           *
            '   M = P * i / ( 1 - ( 1 + i ) ^ -n)                                  *
            '***********************************************************************
            '1. convert interest rate to decimal form
            dblInterestToDecimal = dblRate / 100 'interest % to decimal form
            dblAdminToDecimal = adminPaid ' dblAdmin / 100 'interest % to decimal form

            '2. calculate interest
            'dblConvertInterest = dblInterestToDecimal / 12
            'per month
            dblConvertInterest = dblInterestToDecimal
            dblConvertAdmin = dblAdminToDecimal

            '3. calculate the total number of payments (n * 12)
            ''change intNumOfPayments to months
            ''''''''''''''''''''''''''''''''''''
            'intNumOfPayments = intYears * 12
            intNumOfPayments = intMonths

            '4. Calculate monthly payment using formula
            dblMonthlyPayment = totalPayment / intMonths
            'dblMonthlyPayment = Math.Round(dblMonthlyPayment, 2)

            'output monthly payment to user
            'lblMonthly.Text = "Monthly Payment: " & String.Format("{0:C}", dblMonthlyPayment)
            dblTotalPayments = intNumOfPayments * dblMonthlyPayment 'total amount of payments
            'lblTotal.Text = "Total Payment: " & String.Format("{0:C}", dblTotalPayments)
            decNewBalance = dblPrincipal 'initialize principle balance
            'paymentDate = firstPayDate
            paymentDate = convertWeekendToFriday(firstPayDate)

            Do While intPmt <= intNumOfPayments
                'interestPaid = decNewBalance * dblConvertInterest
                'decDeductBalance = dblMonthlyPayment - interestPaid
                decDeductBalance = dblMonthlyPayment - interestPaid - adminPaid
                decNewBalance = decNewBalance - decDeductBalance
                cumPrincipal = cumPrincipal + decDeductBalance
                'cumInterest = cumInterest + interestPaid
                cumInterest = cumInterest + interestPaid
                cumAdmin = cumAdmin + adminPaid

                cmd = New SqlCommand("insert into AMORTIZATION_SCHEDULE(LOANID,PAYMENT_NO,PAYMENT_DATE,PRINCIPAL,INTEREST,ADMIN_CHARGE,CUMULATIVE_PRINCIPAL,CUMULATIVE_INTEREST,PRINCIPAL_BALANCE,PAYMENT,CUMULATIVE_ADMIN) values ('" & loanID & "','" & intPmt & "','" & DateFormat.getSaveDate(paymentDate) & "','" & decDeductBalance & "','" & interestPaid & "','" & adminPaid & "','" & cumPrincipal & "','" & cumInterest & "','" & decNewBalance & "','" & dblMonthlyPayment & "','" & cumAdmin & "')", con)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                'msgbox(cmd.CommandText)
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()

                'paymentDate = DateAdd(DateInterval.Month, 1, paymentDate).ToShortDateString()
                paymentDate = convertWeekendToFriday(DateAdd(DateInterval.Month, 1, paymentDate).ToShortDateString())
                'tblAmort.Rows.Add(tRow)
                intPmt += 1
            Loop

        End If
    End Sub

    Protected Sub amortizeStraight(ByVal loanID As String)
        clearAmortization(loanID)
        Dim cumPrincipal, cumInterest, cumAdmin As Double
        cmd = New SqlCommand("select * from QUEST_APPLICATION where ID='" & loanID & "'", con)
        Dim ds As New DataSet
        adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "LOANS")
        If ds.Tables(0).Rows.Count > 0 Then
            'Declare variables
            Dim intYears As Integer
            Dim dblMonthlyPayment As Double
            Dim dblRate As Double
            Dim dblAdmin As Double
            Dim intNumOfPayments As Integer
            Dim dblPrincipal As Double
            Dim dblConvertInterest As Double
            Dim dblConvertAdmin As Double
            'convert to monthly interest
            Dim intPmt As Integer = 1 'initialize integer
            Dim decDeductBalance As Decimal
            Dim interestPaid As Decimal
            Dim AdminPaid As Decimal
            Dim decNewBalance As Decimal
            Dim dblTotalPayments As Double
            Dim dblInterestToDecimal As Double 'convert interest % to decimal
            Dim dblAdminToDecimal As Double 'convert interest % to decimal
            'Dim table As DataTable = new DataTable("ParentTable")
            Dim tblAmort As DataTable = New DataTable("AmortizationTable")

            dblPrincipal = ds.Tables(0).Rows(0).Item("FIN_AMT")
            dblRate = ds.Tables(0).Rows(0).Item("FIN_INT_RATE")
            dblAdmin = ds.Tables(0).Rows(0).Item("FIN_ADMIN")
            firstPayDate = ds.Tables(0).Rows(0).Item("FIN_REPAY_DATE") '.ToShortDateString()
            intYears = ds.Tables(0).Rows(0).Item("FIN_TENOR")
            dblInterestToDecimal = dblRate / 100 'interest % to decimal form
            dblAdminToDecimal = dblAdmin '/ 100 'interest % to decimal form

            '2. calculate interest
            dblConvertInterest = dblInterestToDecimal ' / 12
            dblConvertAdmin = dblAdminToDecimal / intYears  ' / 12

            intNumOfPayments = intYears
            dblConvertAdmin = dblAdmin / intNumOfPayments

            'dblMonthlyPayment = (dblPrincipal * (dblConvertInterest) / (1 - (1 + (dblConvertInterest)) ^ -intNumOfPayments)) + dblConvertAdmin 'end monthtly payment
            dblMonthlyPayment = dblPrincipal * dblConvertInterest + dblConvertAdmin

            dblTotalPayments = (intNumOfPayments * dblMonthlyPayment) + dblPrincipal 'total amount of payments

            decNewBalance = dblPrincipal 'initialize principal balance
            'paymentDate = firstPayDate
            paymentDate = convertWeekendToFriday(firstPayDate)

            Do While intPmt <= intNumOfPayments
                If intPmt <> intNumOfPayments Then
                    interestPaid = decNewBalance * dblConvertInterest
                    AdminPaid = dblConvertAdmin
                    decDeductBalance = dblMonthlyPayment - interestPaid - AdminPaid
                    decNewBalance = decNewBalance - 0 ' decDeductBalance
                    cumPrincipal = 0 ' cumPrincipal + decDeductBalance
                    cumInterest = cumInterest + interestPaid
                    cumAdmin = cumAdmin + AdminPaid

                    cmd = New SqlCommand("insert into AMORTIZATION_SCHEDULE(LOANID,PAYMENT_NO,PAYMENT_DATE,PRINCIPAL,INTEREST,ADMIN_CHARGE,CUMULATIVE_PRINCIPAL,CUMULATIVE_INTEREST,PRINCIPAL_BALANCE,PAYMENT,CUMULATIVE_ADMIN) values ('" & loanID & "','" & intPmt & "','" & DateFormat.getSaveDate(paymentDate) & "','" & decDeductBalance & "','" & interestPaid & "','" & AdminPaid & "','" & cumPrincipal & "','" & cumInterest & "','" & decNewBalance & "','" & dblMonthlyPayment & "','" & cumAdmin & "')", con)
                    If con.State = ConnectionState.Open Then
                        con.Close()
                    End If
                    con.Open()
                    cmd.ExecuteNonQuery()
                    con.Close()

                    'paymentDate = DateAdd(DateInterval.Month, 1, paymentDate).ToShortDateString()
                    paymentDate = convertWeekendToFriday(DateAdd(DateInterval.Month, 1, paymentDate).ToShortDateString())
                    intPmt += 1
                Else
                    interestPaid = decNewBalance * dblConvertInterest
                    AdminPaid = dblConvertAdmin
                    'decDeductBalance = dblMonthlyPayment - interestPaid - AdminPaid
                    decNewBalance = decNewBalance - dblPrincipal
                    cumPrincipal = cumPrincipal + dblPrincipal
                    cumInterest = cumInterest + interestPaid
                    cumAdmin = cumAdmin + AdminPaid

                    cmd = New SqlCommand("insert into AMORTIZATION_SCHEDULE(LOANID,PAYMENT_NO,PAYMENT_DATE,PRINCIPAL,INTEREST,ADMIN_CHARGE,CUMULATIVE_PRINCIPAL,CUMULATIVE_INTEREST,PRINCIPAL_BALANCE,PAYMENT,CUMULATIVE_ADMIN) values ('" & loanID & "','" & intPmt & "','" & DateFormat.getSaveDate(paymentDate) & "','" & decDeductBalance & "','" & interestPaid & "','" & AdminPaid & "','" & cumPrincipal & "','" & cumInterest & "','" & decNewBalance & "','" & dblMonthlyPayment & "','" & cumAdmin & "')", con)
                    If con.State = ConnectionState.Open Then
                        con.Close()
                    End If
                    con.Open()
                    cmd.ExecuteNonQuery()
                    con.Close()

                    'paymentDate = DateAdd(DateInterval.Month, 1, paymentDate).ToShortDateString()
                    paymentDate = convertWeekendToFriday(DateAdd(DateInterval.Month, 1, paymentDate).ToShortDateString())
                    intPmt += 1
                End If
            Loop
        End If
    End Sub

    Protected Sub btnSaveCreditParameters_Click(sender As Object, e As EventArgs) Handles btnSaveCreditParameters.Click

        'cmd = New SqlCommand("update QUEST_APPLICATION set [REPAYMENT_OPTION]='" & rdbRepayOption.SelectedValue & "',[REPAYMENT_PERIOD]='" & txtRepayPeriod.Text & "',[INTEREST_RATE]='" & convertToSaveFormat(txtIntRate.Text) & "',[FIRST_REPAYMENT_DATE]='" & DateFormat.getSaveDate(bdp1stPayDate.SelectedDate.ToShortDateString) & "' where ID='" & txtLoanID.Text & "'", con)
        cmd = New SqlCommand("update QUEST_APPLICATION set [FIN_TENOR]='" & txtRepayPeriod.Text & "',[FIN_INT_RATE]='" & txtIntRate.Text & "',[FIN_ADMIN]='" & txtAdminCharge.Text & "',[FIN_REPAY_DATE]='" & txt1stPayDate.Text & "' where ID='" & globLoanID & "'", con)
        'msgbox(cmd.CommandText)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        Try
            cmd.ExecuteNonQuery()
            'msgbox("Repayment instructions saved")
            createAmortizationOptions(globLoanID)
            Response.Redirect("AgreementLetters.aspx?ID=" & globLoanID & "&pop=1", False)
        Catch ex As Exception
            'msgbox("Error saving instructions")
            Response.Redirect("AgreementLetters.aspx?ID=" & globLoanID & "&pop=0", False)
            ClientScript.RegisterStartupScript(Me.GetType(), "Gritter", "<script type=""text/javascript"">$.gritter.add({title: 'Error saving instruction!',text: 'The amortization instructions could not be saved. Please make sure all parameters are entered correctly with the right format and try again.',image: 'images/error_button.png'});</script>")
        Finally
            con.Close()
        End Try
    End Sub

    Protected Function convertWeekendToFriday(payDate As Date) As Date
        While payDate.DayOfWeek = DayOfWeek.Saturday Or payDate.DayOfWeek = DayOfWeek.Sunday Or isHoliday(payDate)
            payDate = payDate.AddDays(-1)
        End While
        Return payDate
    End Function

    Protected Sub createAmortizationOptions(ByVal loanID As String)
        Try
            cmd = New SqlCommand("select * from QUEST_APPLICATION where ID='" & loanID & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "LOANS")
            Dim repOpt As String = ""
            Dim intSett As String = ""
            If ds.Tables(0).Rows.Count > 0 Then
                If ds.Tables(0).Rows(0).Item("FIN_REPAY_OPT") = "Interest" Then
                    amortizeSimple(loanID)
                    'cmd = New SqlCommand("sp_amortize_simple_daily", con)
                    'cmd.CommandType = CommandType.StoredProcedure
                    'cmd.Parameters.AddWithValue("@loanID", loanID)
                ElseIf ds.Tables(0).Rows(0).Item("FIN_REPAY_OPT") = "Balance" Then
                    amortizeNormal(loanID)
                    'cmd = New SqlCommand("sp_amortize_normal_daily", con)
                    'cmd.CommandType = CommandType.StoredProcedure
                    'cmd.Parameters.AddWithValue("@loanID", loanID)
                ElseIf isFarmer = "1" Then
                    amortizeStraight(loanID)
                Else
                    amortizeNormal(loanID)
                    'cmd = New SqlCommand("sp_amortize_normal_daily", con)
                    'cmd.CommandType = CommandType.StoredProcedure
                    'cmd.Parameters.AddWithValue("@loanID", loanID)
                End If
                'If con.State <> ConnectionState.Closed Then
                '    con.Close()
                'End If
                'con.Open()
                'cmd.ExecuteNonQuery()
                'con.Close()
            End If
        Catch ex As Exception
            amortizeNormal(loanID)
        End Try
    End Sub

    Protected Function isHoliday(payDate As Date) As Boolean
        cmd = New SqlCommand("select ID from HOLIDAYS where HOLIDAY_DATE='" & payDate & "'", con)
        Dim ds As New DataSet
        adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "holiday")
        If ds.Tables(0).Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Protected Sub loadRepayParameters()
        Try
            Dim settInt As String = ""
            Dim repayOpt As String = ""
            Dim repayPer, intRate, adminCharge As Double
            Dim firstPayDate As String = ""
            cmd = New SqlCommand("select [FIN_AMT],[FIN_TENOR],[FIN_INT_RATE],[FIN_ADMIN],convert(varchar(30),[FIN_REPAY_DATE],113) as [FIN_REPAY_DATE],[FIN_REPAY_OPT],[CUSTOMER_TYPE] from QUEST_APPLICATION where ID='" & globLoanID & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "CREDIT")
            If ds.Tables(0).Rows.Count > 0 Then
                Try
                    repayPer = ds.Tables(0).Rows(0).Item("FIN_TENOR")
                    intRate = ds.Tables(0).Rows(0).Item("FIN_INT_RATE")
                    firstPayDate = ds.Tables(0).Rows(0).Item("FIN_REPAY_DATE")
                    adminCharge = ds.Tables(0).Rows(0).Item("FIN_ADMIN")
                    If ds.Tables(0).Rows(0).Item("CUSTOMER_TYPE") = "Farmer" Then
                        isFarmer = "1"
                    End If
                Catch ex As Exception
                    'msgbox(ex.Message)
                End Try
            Else
                'ClientScript.RegisterStartupScript(Me.GetType(), "Gritter", "<script type=""text/javascript"">$.gritter.add({title: 'Loan ID not found!',text: 'There is no record which matches the entered Loan ID.',image: 'images/error_button.png'});</script>")
            End If
            txtRepayPeriod.Text = repayPer
            txtIntRate.Text = intRate
            txtAdminCharge.Text = adminCharge
            txt1stPayDate.Text = firstPayDate
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True
        If Not IsPostBack Then
            'txtRepayPeriod.Text = Request.QueryString("loanID")
            globLoanID = Request.QueryString("loanID")
            'txtLoanID.Text = globLoanID

            loadRepayParameters()
            'btnSearchLoanID_Click(sender, New EventArgs)
        End If
    End Sub
End Class