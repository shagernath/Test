﻿Imports System.Data
Imports System.Data.SqlClient
Imports ErrorLogging
Imports CreditManager

Partial Class Credit_ParaInternalControls
    Inherits System.Web.UI.Page

    Protected Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            If Trim(txtMaxExposure.Text) = "" Then
                notify("Enter maximum exposure", "error")
                txtMaxExposure.Focus()
            ElseIf Trim(txtMaxGrpMembers.Text) = "" Then
                notify("Enter maximum group members", "error")
                txtMaxGrpMembers.Focus()
            ElseIf Trim(txtMaxRunLoans.Text) = "" Then
                notify("Enter the maximum running loans", "error")
                txtMaxRunLoans.Focus()
            ElseIf Trim(txtMinGrpMembers.Text) = "" Then
                notify("Enter the minimum group members", "error")
                txtMinGrpMembers.Focus()
            ElseIf Trim(txtDebtorPrefix.Text) = "" Then
                notify("Enter the Debtor Account prefix", "error")
                txtDebtorPrefix.Focus()
            ElseIf Trim(txtDebtorSeparator.Text) = "" Then
                notify("Enter the Debtor Account separator", "error")
                txtDebtorSeparator.Focus()
            ElseIf rdbDebtorSuffixOption.SelectedIndex = -1 Then
                notify("Select the Debtor Account suffix option", "error")
                rdbDebtorSuffixOption.Focus()
            ElseIf Trim(txtSuffixLength.Text) = "" Or Not IsNumeric(txtSuffixLength.Text) Then
                notify("Enter numeric value for Suffix length", "error")
                txtSuffixLength.Focus()
            ElseIf rdbDebtorSuffixOption.SelectedValue = "Auto" And Not IsNumeric(txtSeed.Text) Then
                notify("Enter the start value for auto-increment account number", "error")
                txtSeed.Focus()
            Else
                Using con As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                    If isSaved() Then
                        Using cmd = New SqlCommand("update ParaInternalControls set MinGrpMembers=@MinGrpMembers,MaxGrpMembers=@MaxGrpMembers,MaxExposure=@MaxExposure,MaxNoLoans=@MaxNoLoans,ClientMoreThanOneGroup=@ClientMoreThanOneGroup,PrePopulateGuarantor=@PrePopulateGuarantor,AccountPrefix=@AccountPrefix,AccountSeparator=@AccountSeparator,AccountSuffixOption=@AccountSuffixOption,SuffixLength=@SuffixLength,AccountSeed=@AccountSeed", con)
                            cmd.Parameters.AddWithValue("@MinGrpMembers", txtMinGrpMembers.Text)
                            cmd.Parameters.AddWithValue("@MaxGrpMembers", txtMaxGrpMembers.Text)
                            cmd.Parameters.AddWithValue("@MaxExposure", txtMaxExposure.Text)
                            cmd.Parameters.AddWithValue("@MaxNoLoans", txtMaxRunLoans.Text)
                            cmd.Parameters.AddWithValue("@ClientMoreThanOneGroup", chkClientMoreThanOneGroup.Checked)
                            cmd.Parameters.AddWithValue("@PrePopulateGuarantor", chkPrePopulateGuarantor.Checked)
                            cmd.Parameters.AddWithValue("@AccountPrefix", txtDebtorPrefix.Text)
                            cmd.Parameters.AddWithValue("@AccountSeparator", txtDebtorSeparator.Text)
                            cmd.Parameters.AddWithValue("@AccountSuffixOption", rdbDebtorSuffixOption.SelectedValue)
                            cmd.Parameters.AddWithValue("@SuffixLength", txtSuffixLength.Text)
                            cmd.Parameters.AddWithValue("@AccountSeed", IIf(rdbDebtorSuffixOption.SelectedValue = "Auto", txtSeed.Text, DBNull.Value))
                            con.Open()
                            If cmd.ExecuteNonQuery() Then
                                notify("Controls saved", "success")
                            Else
                                notify("Error saving controls", "error")
                            End If
                            con.Close()
                        End Using
                    Else
                        Using cmd = New SqlCommand("insert into ParaInternalControls (MinGrpMembers,MaxGrpMembers,MaxExposure,MaxNoLoans,ClientMoreThanOneGroup,PrePopulateGuarantor,AccountPrefix,AccountSeparator,AccountSuffixOption,SuffixLength,AccountSeed) values (@MinGrpMembers,@MaxGrpMembers,@MaxExposure,@MaxNoLoans,@ClientMoreThanOneGroup,@PrePopulateGuarantor,@AccountPrefix,@AccountSeparator,@AccountSuffixOption,@SuffixLength,@AccountSeed)", con)
                            cmd.Parameters.AddWithValue("@MinGrpMembers", txtMinGrpMembers.Text)
                            cmd.Parameters.AddWithValue("@MaxGrpMembers", txtMaxGrpMembers.Text)
                            cmd.Parameters.AddWithValue("@MaxExposure", txtMaxExposure.Text)
                            cmd.Parameters.AddWithValue("@MaxNoLoans", txtMaxRunLoans.Text)
                            cmd.Parameters.AddWithValue("@ClientMoreThanOneGroup", chkClientMoreThanOneGroup.Checked)
                            cmd.Parameters.AddWithValue("@PrePopulateGuarantor", chkPrePopulateGuarantor.Checked)
                            cmd.Parameters.AddWithValue("@AccountPrefix", txtDebtorPrefix.Text)
                            cmd.Parameters.AddWithValue("@AccountSeparator", txtDebtorSeparator.Text)
                            cmd.Parameters.AddWithValue("@AccountSuffixOption", rdbDebtorSuffixOption.SelectedValue)
                            cmd.Parameters.AddWithValue("@SuffixLength", txtSuffixLength.Text)
                            cmd.Parameters.AddWithValue("@AccountSeed", IIf(rdbDebtorSuffixOption.SelectedValue = "Auto", txtSeed.Text, DBNull.Value))
                            con.Open()
                            If cmd.ExecuteNonQuery() Then
                                notify("Controls saved", "success")
                            Else
                                notify("Error saving stage", "error")
                            End If
                            con.Close()
                        End Using
                    End If
                End Using
            End If
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- btnSave_Click()", ex.ToString)
        End Try
    End Sub

    Protected Sub getInternalControls()
        Try
            Using con As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("select * from ParaInternalControls", con)
                    Dim ds As New DataSet
                    Using adp = New SqlDataAdapter(cmd)
                        adp.Fill(ds)
                    End Using
                    If ds.Tables(0).Rows.Count > 0 Then
                        Dim dr = ds.Tables(0).Rows(0)
                        txtMaxRunLoans.Text = dr("MaxNoLoans")
                        txtMinGrpMembers.Text = dr("MinGrpMembers")
                        txtMaxGrpMembers.Text = dr("MaxGrpMembers")
                        Try
                            txtMaxExposure.Text = FormatNumber(dr("MaxExposure"), 2)
                        Catch ex As Exception
                            txtMaxExposure.Text = ""
                        End Try
                        Try
                            chkClientMoreThanOneGroup.Checked = dr("ClientMoreThanOneGroup")
                        Catch ex As Exception
                            chkClientMoreThanOneGroup.Checked = False
                        End Try
                        Try
                            chkPrePopulateGuarantor.Checked = dr("PrePopulateGuarantor")
                        Catch ex As Exception
                            chkPrePopulateGuarantor.Checked = False
                        End Try
                        Try
                            txtDebtorPrefix.Text = dr("AccountPrefix")
                        Catch ex As Exception
                            txtDebtorPrefix.Text = ""
                        End Try
                        Try
                            txtDebtorSeparator.Text = dr("AccountSeparator")
                        Catch ex As Exception
                            txtDebtorSeparator.Text = ""
                        End Try
                        Try
                            rdbDebtorSuffixOption.SelectedValue = dr("AccountSuffixOption")
                        Catch ex As Exception
                            rdbDebtorSuffixOption.ClearSelection()
                        End Try
                        showSeed()
                        Try
                            txtSuffixLength.Text = dr("SuffixLength")
                        Catch ex As Exception
                            txtSuffixLength.Text = ""
                        End Try
                        Try
                            txtSeed.Text = dr("AccountSeed")
                        Catch ex As Exception
                            txtSeed.Text = ""
                        End Try
                    End If
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- getInternalControls()", ex.ToString)
        End Try
    End Sub

    Protected Function isSaved() As Boolean
        Try
            Using con As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("select * from ParaInternalControls", con)
                    Dim ds As New DataSet
                    Using adp = New SqlDataAdapter(cmd)
                        adp.Fill(ds)
                    End Using
                    If ds.Tables(0).Rows.Count > 0 Then
                        Return True
                    Else
                        Return False
                    End If
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- isSaved()", ex.ToString)
            Return False
        End Try
    End Function
    Protected Sub rdbDebtorSuffixOption_SelectedIndexChanged(sender As Object, e As EventArgs) Handles rdbDebtorSuffixOption.SelectedIndexChanged
        showSeed()
    End Sub

    Protected Sub showSeed()
        If rdbDebtorSuffixOption.SelectedValue = "Auto" Then
            txtSeed.Visible = True
            lblSeed.Visible = True
        Else
            txtSeed.Visible = False
            lblSeed.Visible = False
        End If
    End Sub

    Private Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True
        If Not IsPostBack Then
            getInternalControls()
        End If
    End Sub
End Class