﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class CaptureRepaymentNew
    Inherits System.Web.UI.Page
    Dim cmd As SqlCommand
    Dim con As New SqlConnection
    Dim connection As String

    Shared payDate, schedDate As Date 'date payment was made
    Shared daysDiffnce, amtDiffnce, loanAmount, payAmount, schedAmount As Double 'number of days between due date and actual payment day
    Shared totalAmountPaid As Double
    Shared nettPayment As Double ''the nett amount paid after considering previous paymt differences
    Shared prevDfnce As Double ''payment difference of previous record
    Shared principalBalance, schedInterest, schedPrincipal As Double
    Shared runningPaymtTotal, dsCount, schedPayNo As Double
    'Shared runningTotal As Double
    Shared receiptNo As String
    Shared dsDetails As New DataSet
    Shared dsSchedule As New DataSet
    Shared paidLoanID, paidReceiptNo As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True
        con = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
        If Not IsPostBack Then

        End If
    End Sub

    Protected Sub clearAll()
        Try
            lblAddress.Text = ""
            lblAmountDue.Text = ""
            lblLoanAmount.Text = ""
            lblName.Text = ""
            lblNumRepayments.Text = ""
            lblPaymentsMade.Text = ""
            lblPrincipalBalance.Text = ""
            txtAmountPaid.Text = ""
            bdpPaymentDate.Clear()
            txtLoanID.Text = ""
            txtReceiptNo.Text = ""
            panLoanDetails.Visible = False
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub btnSearchLoan_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearchLoan.Click
        Try
            cmd = New SqlCommand("select * from QUEST_APPLICATION where ID='" & txtLoanID.Text & "' and DISBURSED=1", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "LOANS")
            Dim loanAmt As Double
            If ds.Tables(0).Rows.Count > 0 Then
                lblAddress.Text = ds.Tables(0).Rows(0).Item("ADDRESS")
                lblLoanAmount.Text = Math.Round(ds.Tables(0).Rows(0).Item("FIN_AMT"), 2)
                lblName.Text = ds.Tables(0).Rows(0).Item("SURNAME") & " " & ds.Tables(0).Rows(0).Item("FORENAMES")
                Try
                    lblNumRepayments.Text = ds.Tables(0).Rows(0).Item("FIN_TENOR")
                    loanAmt = ds.Tables(0).Rows(0).Item("FIN_AMT")
                Catch ex As Exception
                    msgbox("Repayment Instructions not entered")
                End Try
                cmd = New SqlCommand("select * from LOAN_REPAYMENT_SCHEDULE where LOANID='" & txtLoanID.Text & "' and FULLY_PAID=1", con)
                Dim ds1 As New DataSet
                Dim adp1 = New SqlDataAdapter(cmd)
                adp1.Fill(ds1, "REPAYMENT")
                If ds1.Tables(0).Rows.Count > 0 Then
                    Dim count = ds1.Tables(0).Rows.Count
                    'lblAmountDue.Text = ds1.Tables(0).Rows(count - 1).Item("AMOUNT_PAID")
                    lblPaymentsMade.Text = count
                    'lblPrincipalBalance.Text = ds1.Tables(0).Rows(count - 1).Item("PRINCIPAL_BALANCE")

                    Dim prinPaid As Double
                    cmd = New SqlCommand("select isnull(sum(PRINCIPAL),0) as totPrincipal from RECEIPT_SCHEDULE where loanid='" & txtLoanID.Text & "'", con)
                    If con.State = ConnectionState.Open Then
                        con.Close()
                    End If
                    con.Open()
                    prinPaid = cmd.ExecuteScalar
                    con.Close()
                    lblPrincipalBalance.Text = loanAmt - prinPaid

                    'Dim paymtDue, intPaid, princiPaid As Double
                    'cmd = New SqlCommand("select isnull(sum(isnull(PAYMENT,0)),0) from LOAN_REPAYMENT_SCHEDULE where (FULLY_PAID<>1 or FULLY_PAID IS NULL) and loanid='" & txtLoanID.Text & "' and DATEDIFF(d, CONVERT(Date, PAYMENT_DATE, 103), CONVERT(Date, '" & Now.Date & "', 103))>0", con)
                    ''msgbox(cmd.CommandText)
                    'If con.State = ConnectionState.Open Then
                    '    con.Close()
                    'End If
                    'con.Open()
                    'paymtDue = cmd.ExecuteScalar
                    'con.Close()

                    'cmd = New SqlCommand("SELECT ISNULL(SUM(INTEREST),0) AS INTEREST, ISNULL(SUM(PRINCIPAL),0) AS PRINCIPAL FROM RECEIPT_SCHEDULE WHERE LOANID='" & txtLoanID.Text & "' AND SCHED_PAY_NO IN (SELECT PAYMENT_NO FROM LOAN_REPAYMENT_SCHEDULE WHERE LOANID='" & txtLoanID.Text & "' AND (FULLY_PAID<>1 OR FULLY_PAID IS NULL) AND DATEDIFF(d, CONVERT(Date, PAYMENT_DATE, 103), CONVERT(Date, '" & Now.Date & "', 103))>0)", con)
                    'adp = New SqlDataAdapter(cmd)
                    'ds = New DataSet
                    'adp.Fill(ds, "PAID")
                    'intPaid = ds.Tables(0).Rows(0).Item("INTEREST")
                    'princiPaid = ds.Tables(0).Rows(0).Item("PRINCIPAL")
                    'lblAmountDue.Text = Math.Round(paymtDue - intPaid - princiPaid, 2)

                    displayAmtDue(txtLoanID.Text)
                Else
                    lblPaymentsMade.Text = 0
                    lblPrincipalBalance.Text = loanAmt

                    displayAmtDue(txtLoanID.Text)
                End If
                panLoanDetails.Visible = True
            Else
                clearAll()
                panLoanDetails.Visible = False
                msgbox("Loan not yet disbursed")
            End If
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub displayAmtDue(ByVal loanID As String)
        Try
            Dim paymtDue, intPaid, princiPaid As Double
            cmd = New SqlCommand("select isnull(sum(isnull(PAYMENT,0)),0) from LOAN_REPAYMENT_SCHEDULE where (FULLY_PAID<>1 or FULLY_PAID IS NULL) and loanid='" & loanID & "' and DATEDIFF(d, CONVERT(Date, PAYMENT_DATE, 103), CONVERT(Date, '" & Now.Date & "', 103))>0", con)
            'msgbox(cmd.CommandText)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            paymtDue = cmd.ExecuteScalar
            con.Close()

            Dim adp As SqlDataAdapter
            Dim ds As DataSet
            cmd = New SqlCommand("SELECT ISNULL(SUM(INTEREST),0) AS INTEREST, ISNULL(SUM(PRINCIPAL),0) AS PRINCIPAL FROM RECEIPT_SCHEDULE WHERE LOANID='" & loanID & "' AND SCHED_PAY_NO IN (SELECT PAYMENT_NO FROM LOAN_REPAYMENT_SCHEDULE WHERE LOANID='" & txtLoanID.Text & "' AND (FULLY_PAID<>1 OR FULLY_PAID IS NULL) AND DATEDIFF(d, CONVERT(Date, PAYMENT_DATE, 103), CONVERT(Date, '" & Now.Date & "', 103))>0)", con)
            adp = New SqlDataAdapter(cmd)
            ds = New DataSet
            adp.Fill(ds, "PAID")
            intPaid = ds.Tables(0).Rows(0).Item("INTEREST")
            princiPaid = ds.Tables(0).Rows(0).Item("PRINCIPAL")
            lblAmountDue.Text = Math.Round(paymtDue - intPaid - princiPaid, 2) '.ToString.Format("###.##")
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub calcTotalRepayAmt(ByVal loanID As String)
        Try

        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub btnSavePayment_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSavePayment.Click
        Try
            paidLoanID = txtLoanID.Text
            paidReceiptNo = txtReceiptNo.Text
            'initializeAll()
            'msgbox(runningPaymtTotal)
            createSchedule(txtLoanID.Text)
            runningPaymtTotal = txtAmountPaid.Text ''initial amount for this payment
            receiptNo = txtReceiptNo.Text ''receipt number, used throughout
            payDate = bdpPaymentDate.SelectedDate.ToShortDateString
            payAmount = txtAmountPaid.Text

            'cmd = New SqlCommand("insert into LOAN_REPAYMENT_DETAILS ([LOANID],[PAID_DATE],[AMOUNT_PAID]) values ('" & txtLoanID.Text & "','" & bdpPaymentDate.SelectedDate & "','" & txtAmountPaid.Text & "')", con)
            cmd = New SqlCommand("insert into RECEIVED_REPAYMENTS ([LOANID],[RECEIVED_DATE],[AMOUNT],[RECEIVED_BY],[RECEIPT_NO],[CAPT_DATE]) values ('" & txtLoanID.Text & "','" & convertToSaveDate(payDate) & "','" & convertToSaveFormat(txtAmountPaid.Text) & "','" & Session("UserID") & "','" & txtReceiptNo.Text.Trim & "',GETDATE())", con)
            'msgbox(cmd.CommandText)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            If cmd.ExecuteNonQuery() Then
                'calculateRemainingPayment(txtLoanID.Text)
                'properSaveFunction(txtLoanID.Text)
                getSchedule(txtLoanID.Text)
                'Exit Sub
                msgbox("Saved successfully")
                loadPanRepayDetails()
                panRepayDetails.Visible = True
                clearAll()
            Else
                msgbox("Error saving payment")
            End If
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub createSchedule(ByVal loanID As String)
        Try
            cmd = New SqlCommand("select * from RECEIPT_SCHEDULE where LOANID='" & loanID & "'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "DETAILS")
            If ds.Tables(0).Rows.Count > 0 Then
                ''schedule already in new table
            Else
                ''copy schedule to new table
                cmd = New SqlCommand("delete from LOAN_REPAYMENT_SCHEDULE WHERE LOANID='" & loanID & "'", con)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                cmd = New SqlCommand("insert into LOAN_REPAYMENT_SCHEDULE (LOANID,PAYMENT_NO,PAYMENT_DATE,PRINCIPAL,INTEREST,PAYMENT,CUMULATIVE_PRINCIPAL,CUMULATIVE_INTEREST,PRINCIPAL_BALANCE) select LOANID,PAYMENT_NO,PAYMENT_DATE,PRINCIPAL,INTEREST,PAYMENT,CUMULATIVE_PRINCIPAL,CUMULATIVE_INTEREST,PRINCIPAL_BALANCE from AMORTIZATION_SCHEDULE where LOANID='" & loanID & "'", con)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                If cmd.ExecuteNonQuery Then
                End If
                con.Close()
            End If
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Public Sub msgbox(ByVal strMessage As String)

        'finishes server processing, returns to client.
        Dim strScript As String = "<script language=JavaScript>"
        strScript += "window.alert(""" & strMessage & """);"
        strScript += "</script>"
        Dim lbl As New System.Web.UI.WebControls.Label
        lbl.Text = strScript
        Page.Controls.Add(lbl)
    End Sub

    Protected Sub checkPenalty()
        Try
            ''for now only late payment

        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub closeConnection(ByVal conn As SqlConnection)
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Public Shared Function convertToSaveFormat(ByVal dbl As String) As String
        If dbl.ToString.Contains(",") Then
            dbl = dbl.ToString.Replace(",", ".")
        End If
        Return dbl
    End Function

    Protected Function getLoanAmount(ByVal loanID As String) As Double
        Try
            Dim amtPaid As Double
            amtPaid = 0
            cmd = New SqlCommand("select CLIENT_CREDITAPPLIED as totalAmount from Z_LOAN_SUBMISSION_DETAILS where LOAN_REQID='" & loanID & "'", con)
            closeConnection(con)
            con.Open()
            amtPaid = cmd.ExecuteScalar
            con.Close()
            Return amtPaid
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Function

    Protected Function calculateRepaymentTodate(ByVal loanID As String) As Double
        Try
            Dim amtPaid As Double
            amtPaid = 0
            cmd = New SqlCommand("select sum(isnull(PRINCIPAL,0)) as totalAmount from RECEIPT_SCHEDULE where LOANID='" & loanID & "'", con)
            closeConnection(con)
            con.Open()
            amtPaid = cmd.ExecuteScalar
            con.Close()
            Return amtPaid
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Function

    Protected Sub getSchedule(ByVal loanID As String)
        Try
            prevDfnce = 0

            loanAmount = getLoanAmount(loanID)
            totalAmountPaid = calculateRepaymentTodate(loanID)
            principalBalance = Math.Round(loanAmount - totalAmountPaid, 2) ''WRONG FORMULA, shld be principal paid

            dsSchedule.Tables.Clear()
            cmd = New SqlCommand("select * from LOAN_REPAYMENT_SCHEDULE where LOANID='" & loanID & "' and (FULLY_PAID<>'True' or FULLY_PAID is NULL) order by ID", con)
            'Dim ds1 As New DataSet
            Dim adp1 = New SqlDataAdapter(cmd)
            adp1.Fill(dsSchedule, "SCHEDULE")
            'msgbox(ds1.Tables(0).Rows.Count)
            If dsSchedule.Tables(0).Rows.Count > 0 Then
                Dim span As New TimeSpan
                Try

                    schedDate = CDate(dsSchedule.Tables(0).Rows(0).Item("PAYMENT_DATE")).ToShortDateString
                    schedAmount = dsSchedule.Tables(0).Rows(0).Item("PAYMENT")
                    schedInterest = dsSchedule.Tables(0).Rows(0).Item("INTEREST")
                    schedPrincipal = dsSchedule.Tables(0).Rows(0).Item("PRINCIPAL")
                    schedPayNo = dsSchedule.Tables(0).Rows(0).Item("PAYMENT_NO")
                    span = schedDate.Subtract(payDate)
                    ''negative value is overdue payment
                    daysDiffnce = span.Days

                    'amtDiffnce = Math.Round(payAmount - schedAmount, 2)
                    amtDiffnce = Math.Round(payAmount - schedAmount + prevDfnce, 2)
                    'msgbox(payAmount - schedAmount)
                Catch ex As Exception
                    msgbox(ex.Message)
                End Try

                Dim penalty, interest, principal As Double
                ''to have if statement here, to check for type of penalty if any
                ''modify hasPenalty() function to flow with new plan
                Dim penaltyToPay As Double
                penalty = calculateLPPenalty()
                penaltyToPay = penalty
                'msgbox(penaltyToPay)
                cmd = New SqlCommand("select sum(isnull(INSTALMENT_BALANCE,0)) as remainder from RECEIPT_SCHEDULE where LOANID='" & loanID & "'", con)
                closeConnection(con)
                con.Open()
                'runningPaymtTotal = Math.Round(runningPaymtTotal + cmd.ExecuteScalar, 2)

                If runningPaymtTotal > penaltyToPay Then
                    runningPaymtTotal = Math.Round(runningPaymtTotal + penaltyToPay, 2)
                Else
                    penaltyToPay = runningPaymtTotal
                    runningPaymtTotal = 0
                End If
                Dim penBalance As Double
                ''get penalty balance
                cmd = New SqlCommand("select isnull(PENALTY_BALANCE,0) FROM LOAN_PENALTY where LOANID='" & loanID & "'", con)
                closeConnection(con)
                con.Open()
                penBalance = cmd.ExecuteScalar()
                con.Close()

                interest = interestToPay()
                principal = principalToPay()

                amtDiffnce = amtDiffnce + penalty
                penBalance = penBalance + penalty

                'cmd = New SqlCommand("update LOAN_REPAYMENT_DETAILS set DATE_DIFFERENCE='" & daysDiffnce & "',PRINCIPAL_BALANCE='" & convertToSaveFormat(principalBalance) & "',PAYMENT_DIFFERENCE='" & convertToSaveFormat(amtDiffnce) & "',PENALTY='" & convertToSaveFormat(penalty) & "',PENALTY_BALANCE='" & convertToSaveFormat(penBalance) & "',PRINCIPAL_PAID=isnull(PRINCIPAL_PAID,0)+'" & convertToSaveFormat(principal) & "',INTEREST_PAID=isnull(INTEREST_PAID,0)+'" & convertToSaveFormat(interest) & "',PENALTY_PAID=isnull(PENALTY_PAID,0)+'" & convertToSaveFormat(penaltyToPay) & "' where ID='" & dsDetails.Tables(0).Rows(dsCount - 1).Item("ID") & "'", con)

                penBalance = penBalance - penaltyToPay
                cmd = New SqlCommand("insert into LOAN_PENALTY(LOANID,START_DATE,END_DATE,AMOUNT_DUE,AMOUNT_PAID,DAYS_DIFFERENCE,PENALTY_BALANCE) values ('" & loanID & "','" & convertToSaveDate(schedDate) & "','" & convertToSaveDate(payDate) & "','" & convertToSaveFormat(penalty) & "','" & convertToSaveFormat(penaltyToPay) & "','" & daysDiffnce & "','" & convertToSaveFormat(penBalance) & "')", con)
                closeConnection(con)
                'msgbox(daysDiffnce)
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                'msgbox("kkkkkkkkkkkkkkkkkkkkkkkkkkkkkk")
                principalBalance = principalBalance - principal
                Dim instBalance As Double
                instBalance = schedAmount - interest - principal
                instBalance = payAmount - (principal + interest - penalty) ''subtract negative to have addition
                cmd = New SqlCommand("insert into RECEIPT_SCHEDULE (LOANID,RECEIPT_NO,SCHED_PAY_NO,PRINCIPAL,INTEREST,PENALTY,PRINCIPAL_BALANCE,INSTALMENT_BALANCE) values ('" & loanID & "','" & receiptNo & "','" & convertToSaveFormat(schedPayNo) & "','" & convertToSaveFormat(principal) & "','" & convertToSaveFormat(interest) & "','" & convertToSaveFormat(penalty) & "','" & convertToSaveFormat(principalBalance) & "','" & convertToSaveFormat(instBalance) & "')", con)
                closeConnection(con)
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                ''set fully_paid=1
                'msgbox(dsSchedule.Tables(0).Rows(0).Item("ID"))
                cmd = New SqlCommand("update LOAN_REPAYMENT_SCHEDULE set FULLY_PAID=1 where ID='" & dsSchedule.Tables(0).Rows(0).Item("ID") & "'-- and PAYMENT_NO='" & schedPayNo & "'", con)
                'msgbox(runningPaymtTotal)
                If runningPaymtTotal > 0 Then
                    closeConnection(con)
                    con.Open()
                    cmd.ExecuteNonQuery()
                    con.Close()
                    'schedPayNo = schedAmount + 1
                    checkFullPayment(loanID, schedPayNo)

                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub checkFullPayment(ByVal loanID As String, ByVal payNo As Double)
        cmd = New SqlCommand("select sum(isnull(PRINCIPAL,0)) as sumPrincipal from RECEIPT_SCHEDULE where LOANID='" & loanID & "' and SCHED_PAY_NO='" & payNo & "'", con)
        Dim principalPaid As Double
        closeConnection(con)
        con.Open()
        Try
            principalPaid = cmd.ExecuteScalar
        Catch ex As Exception
            If IsDBNull(principalPaid) Then
                principalPaid = 0
            End If
        End Try

        con.Close()
        'msgbox(schedPrincipal)
        If principalPaid > schedPrincipal Then
            cmd = New SqlCommand("update LOAN_REPAYMENT_SCHEDULE set FULLY_PAID=1 where ID='" & dsSchedule.Tables(0).Rows(0).Item("ID") & "'", con)
            'msgbox(amtDiffnce)
            'If amtDiffnce >= 0 Then
            closeConnection(con)
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            getSchedule(loanID)
            'End If
        End If
    End Sub

    Public Shared Function convertToSaveDate(ByVal dbl As String) As String
        If dbl.ToString.Contains(".") Then
            dbl = dbl.ToString.Replace(".", "/")
        End If
        Return dbl
    End Function

    Protected Function interestToPay() As Double
        Try
            Dim interest As Double
            If runningPaymtTotal > schedInterest Then
                interest = schedInterest
                runningPaymtTotal = Math.Round(runningPaymtTotal - schedInterest, 2)
            ElseIf runningPaymtTotal <= schedInterest Then
                interest = runningPaymtTotal
                runningPaymtTotal = 0
            End If
            Return Math.Round(interest, 2)
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Function

    Protected Function principalToPay() As Double
        Try
            Dim principal As Double
            If runningPaymtTotal > schedPrincipal Then
                principal = schedPrincipal
                runningPaymtTotal = Math.Round(runningPaymtTotal - schedPrincipal, 2)
            ElseIf runningPaymtTotal <= schedPrincipal Then
                principal = runningPaymtTotal
                runningPaymtTotal = 0
            End If
            Return Math.Round(principal, 2)
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Function

    Protected Function calculateLPPenalty() As Double ''strictly for late payments only
        Try
            If daysDiffnce >= 0 Then
                Return 0
            Else
                Dim penRate As Double
                Dim penalty As Double
                penalty = 0
                'cmd = New SqlCommand("select PENALTY_RATE from PARA_LOAN_PENALTY where PENALTY_NAME='" & penName & "'", con)
                cmd = New SqlCommand("select PENALTY_RATE from PARA_LOAN_PENALTY where PENALTY_NAME='Late Payment'", con)
                Try
                    closeConnection(con)
                    con.Open()
                    penRate = cmd.ExecuteScalar
                    con.Close()
                Catch ex As Exception

                End Try
                ''different calculations for different penalties???
                'If penName = "Late Payment" Then
                ''Use number of days to calulate actual penalty due
                ''assuming penalty rate is given as a percentage per annum (%/yr)
                penRate = penRate / 100
                penalty = (principalBalance * penRate * daysDiffnce) / 365
                penalty = Math.Round(penalty, 2)
                Return penalty
                '    Else
                '    Return 0
                'End If

            End If
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Function

    Protected Sub loadPanRepayDetails()
        Try
            ''''CURRENT PAYMENT DETAILS
            lblPaymtDate.Text = bdpPaymentDate.SelectedDate
            lblTotAmtPaid.Text = txtAmountPaid.Text
            ''''BALANCE BROUGHT FORWARD
            cmd = New SqlCommand("select * from RECEIPT_SCHEDULE where LOANID='" & paidLoanID & "' and receipt_no='" & paidReceiptNo & "'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "Schedule")
            If ds.Tables(0).Rows.Count > 0 Then
                lblPaymtDate.Text = bdpPaymentDate.SelectedDate
                lblTotAmtPaid.Text = txtAmountPaid.Text
                'lblBalBFwd.Text=
                'lblInstFulPaid.Text=
                lblPenaltyCharged.Text = ds.Tables(0).Rows(0).Item("PENALTY")
                lblInterestPaid.Text = ds.Tables(0).Rows(0).Item("INTEREST")
                lblPrincipalPaid.Text = ds.Tables(0).Rows(0).Item("PRINCIPAL")
                lblPriBalAfterPaymt.Text = ds.Tables(0).Rows(0).Item("PRINCIPAL_BALANCE")
                lblBalCarriedFwd.Text = ds.Tables(0).Rows(0).Item("INSTALMENT_BALANCE")
            End If
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub btnSearchName_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearchName.Click
        Try
            'SecureBank.recordAction(btnSearchName.ID.ToString, "Searched by Name")
            'clearRepayParameters()
            cmd = New SqlCommand("select ID,SURNAME+' '+FORENAMES+' '+convert(varchar,CUSTOMER_NUMBER)+' '+convert(varchar,FIN_AMT) as DISPLAY from QUEST_APPLICATION where DISBURSED='1' AND SURNAME like '" & txtSearchName.Text & "%'", con)
            Dim ds As New DataSet
            Dim adp As New SqlDataAdapter
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "LOANS")
            If ds.Tables(0).Rows.Count > 0 Then
                lstLoans.DataSource = ds.Tables(0)
                lstLoans.DataTextField = "DISPLAY"
                lstLoans.DataValueField = "ID"
                lstLoans.Visible = True
            Else
                lstLoans.DataSource = Nothing
                lstLoans.Visible = False
                msgbox("Search name not found")
                txtLoanID.Text = ""
            End If
            lstLoans.DataBind()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub lstLoans_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstLoans.SelectedIndexChanged
        Try
            Dim loanID = lstLoans.SelectedValue
            txtLoanID.Text = loanID
            btnSearchLoan_Click(sender, New EventArgs)
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub
End Class
