﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Net
Imports Mailhelper
Imports CreditManager
Imports ErrorLogging

Partial Class Credit_ApplicationForm
    Inherits System.Web.UI.Page
    Dim adp As SqlDataAdapter
    Dim cmd As SqlCommand
    Dim con As New SqlConnection
    Dim connection As String

    Public Sub fillType()
        Try
            ddlAssets.Items.Clear()
            Dim ds As New DataSet
            cmd = New SqlCommand("Select Name as details,* from Quest_Assets", con)
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "Assets")
            ddlAssets.Items.Add("")
            ddlAssets.DataSource = ds.Tables(0)
            ddlAssets.DataValueField = "Selling_Price"
            ddlAssets.DataTextField = "details"
            ddlAssets.DataBind()
            ddlAssets.Items.Insert(0, "--SELECT--")
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Public Function InsertUpdateData(ByVal cmd As SqlCommand) As Boolean
        Dim strConnString As String = System.Configuration.ConfigurationManager.ConnectionStrings("conString").ConnectionString()
        Dim con As New SqlConnection(strConnString)
        cmd.CommandType = CommandType.Text
        cmd.Connection = con
        Try
            con.Open()
            cmd.ExecuteNonQuery()
            Return True
        Catch ex As Exception
            Response.Write(ex.Message)
            Return False
        Finally
            con.Close()
            con.Dispose()
        End Try
    End Function

    Public Sub msgbox(ByVal strMessage As String)

        'finishes server processing, returns to client.
        Dim strScript As String = "<script language=JavaScript>"
        strScript += "window.alert(""" & strMessage & """);"
        strScript += "</script>"
        Dim lbl As New System.Web.UI.WebControls.Label
        lbl.Text = strScript
        Page.Controls.Add(lbl)
    End Sub

    Protected Function amortizationAlreadyCreated(loanID As String) As Boolean
        cmd = New SqlCommand("select * from AMORTIZATION_SCHEDULE where LOANID='" & loanID & "'", con)
        Dim ds As New DataSet
        adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "AMO")
        If ds.Tables(0).Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Protected Sub applicantTypeSelector(appType As String)
        cmbBankAppType.ClearSelection()
        cmbBranchAppType.ClearSelection()
        cmbPDAAppType.ClearSelection()
        txtECNo.Text = ""
        txtECNoCD.Text = ""
        txtOtherAppType.Text = ""
        If appType = "SSB" Then
            lblEmpCode.Visible = True
            txtECNo.Visible = True
            txtECNoCD.Visible = True
            SSBVisible()
            divAppTypeBanker.Visible = False
            divAppTypeOther.Visible = False
            divAppTypePDA.Visible = False
        ElseIf appType = "Bankers" Then
            lblEmpCode.Visible = False
            txtECNo.Visible = False
            txtECNoCD.Visible = False
            divAppTypeBanker.Visible = True
            divAppTypeOther.Visible = False
            divAppTypePDA.Visible = False
            SSBInvisible()
        ElseIf appType = "PDAs" Then
            lblEmpCode.Visible = False
            txtECNo.Visible = False
            txtECNoCD.Visible = False
            divAppTypeBanker.Visible = False
            divAppTypeOther.Visible = False
            divAppTypePDA.Visible = True
            SSBInvisible()
        ElseIf appType = "Other" Then
            lblEmpCode.Visible = False
            txtECNo.Visible = False
            txtECNoCD.Visible = False
            divAppTypeBanker.Visible = False
            divAppTypeOther.Visible = True
            divAppTypePDA.Visible = False
            SSBInvisible()
        End If
    End Sub

    Protected Sub btnAddCollateral_Click(sender As Object, e As EventArgs) Handles btnAddCollateral.Click
        Try
            If Trim(txtCustNo.Text) = "" Then
                notify("Enter client customer number", "error")
                txtCustNo.Focus()
            ElseIf Trim(cmbCollateralType.SelectedItem.Text) = "" Then
                notify("Select the collateral type", "error")
                cmbCollateralType.Focus()
            ElseIf Trim(txtCollateralDesc.Text) = "" Then
                notify("Enter the collateral description", "error")
                txtCollateralDesc.Focus()
            ElseIf Trim(txtCollateralValue.Text) = "" Then
                notify("Enter the collateral value", "error")
                txtCollateralValue.Focus()
            Else
                Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                    Using cmd As New SqlCommand("insert into ClientCollateral (CustNo,LoanID,CollateralID,CollateralType,CollDesc,CollValue,CapturedBy,CaptureDate) values (@CustNo,@LoanID,@CollateralID,@CollateralType,@CollDesc,@CollValue,@CapturedBy,GETDATE())", con)
                        cmd.Parameters.AddWithValue("@CustNo", txtCustNo.Text)
                        cmd.Parameters.AddWithValue("@LoanID", 0)
                        cmd.Parameters.AddWithValue("@CollateralID", cmbCollateralType.SelectedValue)
                        cmd.Parameters.AddWithValue("@CollateralType", cmbCollateralType.SelectedItem.Text)
                        cmd.Parameters.AddWithValue("@CollDesc", txtCollateralDesc.Text)
                        cmd.Parameters.AddWithValue("@CollValue", txtCollateralValue.Text)
                        cmd.Parameters.AddWithValue("@CapturedBy", Session("UserId"))
                        con.Open()
                        If cmd.ExecuteNonQuery() Then
                            notify("Collateral saved", "success")
                            getClientCollateral(txtCustNo.Text)
                            cmbCollateralType.ClearSelection()
                            txtCollateralDesc.Text = ""
                            txtCollateralValue.Text = ""
                        Else
                            notify("Error saving collateral", "error")
                        End If
                        con.Close()
                    End Using
                End Using
            End If
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- btnAddCollateral_Click()", ex.ToString)
        End Try
    End Sub

    Protected Sub btnAddCollateralType_Click(sender As Object, e As EventArgs) Handles btnAddCollateralType.Click
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd As New SqlCommand("insert into CollateralTypes (CollateralName) values (@CollateralName)", con)
                    cmd.Parameters.AddWithValue("@CollateralName", txtCollateralType.Text)
                    con.Open()
                    If cmd.ExecuteNonQuery() Then
                        notify("Collateral type saved", "success")
                        loadCollateralTypes()
                        txtCollateralType.Text = ""
                    Else
                        notify("Error saving collateral type", "error")
                    End If
                    con.Close()
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- btnAddCollateralType_Click()", ex.ToString)
        End Try
    End Sub

    Protected Sub btnAddOtherLoan_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAddOtherLoan.Click
        Try
            Using cmd = New SqlCommand("insert into QUEST_OTHER_LOANS (CUSTOMER_NUMBER,OTHER_DESC,OTHER_ACCNO,OTHER_AMT) values ('" & txtCustNo.Text & "','" & BankString.removeSpecialCharacter(txtOtherDesc.Text) & "','" & txtOtherAccNo.Text & "','" & txtOtherAmt.Text & "')", con)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                If cmd.ExecuteNonQuery() Then
                    notify("Loan added successfully", "success")
                Else
                    notify("Error adding loan", "error")
                End If
                con.Close()
                txtOtherAccNo.Text = ""
                txtOtherAmt.Text = ""
                txtOtherDesc.Text = ""
                getOtherLoans()
            End Using
        Catch ex As Exception

        End Try
    End Sub

 

    Protected Sub btnGrpSubmitApp_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGrpSubmitApp.Click
        Try
            getNextApproval(1)
            'cmd = New SqlCommand("insert into QUEST_APPLICATION ([CUSTOMER_TYPE],[CUSTOMER_NUMBER],[SURNAME],[FORENAMES],[DOB],[IDNO],[ISSUE_DATE],[ADDRESS],[CITY],[PHONE_NO],[NATIONALITY],[GENDER],[BUS_TYPE],[BUS_PERIOD],[SOURCE1],[SOURCE2],[SOURCE3],[BORROWING1],[BORROWING2],[BORROWING3],[FIN_AMT],[FIN_TENOR],[FIN_PURPOSE],[FIN_INT_RATE],[CREATED_BY],[CREATED_DATE],[MODIFIED_BY],[MODIFIED_DATE],[STATUS],[SEND_TO],[LO_ID],[LAST_ID],[AMT_APPLIED]) values ('Group','" & txtCustNo.Text & "','" & BankString.removeSpecialCharacter(txtGrpName.Text) & "','" & BankString.removeSpecialCharacter(cmbGrpApplicantName.SelectedItem.Text) & "','" & DateFormat.getSaveDate(bdpGrpApplDOB.SelectedDate) & "','" & txtGrpApplID.Text & "','" & DateFormat.getSaveDate(bdpGrpApplIssueDate.SelectedDate) & "','" & BankString.removeSpecialCharacter(txtGrpApplCurrAdd.Text) & "','" & BankString.removeSpecialCharacter(txtGrpApplCity.Text) & "','" & txtGrpApplPhone.Text & "','" & BankString.removeSpecialCharacter(txtGrpApplNationality.Text) & "','" & rdbGrpApplGender.SelectedValue & "','" & BankString.removeSpecialCharacter(txtGrpApplLineBus.Text) & "','" & txtGrpApplPeriodBus.Text & "','" & BankString.removeSpecialCharacter(txtGrpApplSrcIncome1.Text) & "','" & BankString.removeSpecialCharacter(txtGrpApplSrcIncome2.Text) & "','" & BankString.removeSpecialCharacter(txtGrpApplSrcIncome3.Text) & "','" & BankString.removeSpecialCharacter(txtGrpApplBorrow1.Text) & "','" & BankString.removeSpecialCharacter(txtGrpApplBorrow2.Text) & "','" & BankString.removeSpecialCharacter(txtGrpApplBorrow3.Text) & "','" & txtGrpApplLoanAmt.Text & "','" & txtGrpApplRepayTenure.Text & "','" & BankString.removeSpecialCharacter(txtGrpApplPurpose.Text) & "','" & txtGrpApplInterest.Text & "','" & Session("UserID") & "',getdate(),'','','SUBMITTED','4042','" & Session("ID") & "','" & Session("ID") & "','" & txtGrpApplLoanAmt.Text & "')", con)
            cmd = New SqlCommand("insert into QUEST_APPLICATION ([CUSTOMER_TYPE],[CUSTOMER_NUMBER],[SURNAME],[FORENAMES],[IDNO],[ADDRESS],[CITY],[PHONE_NO],[NATIONALITY],[GENDER],[BUS_TYPE],[BUS_PERIOD],[SOURCE1],[SOURCE2],[SOURCE3],[BORROWING1],[BORROWING2],[BORROWING3],[FIN_AMT],[FIN_TENOR],[FIN_PURPOSE],[FIN_INT_RATE],[CREATED_BY],[CREATED_DATE],[MODIFIED_BY],[MODIFIED_DATE],[STATUS],[SEND_TO],[LO_ID],[LAST_ID],[AMT_APPLIED],[FIN_ADMIN],[BRANCH_CODE],[BRANCH_NAME],[ReadyToDisburse],[ApprovalNumber]) values ('Group','" & txtCustNo.Text & "','" & BankString.removeSpecialCharacter(txtGrpName.Text) & "','','','','','','','','" & BankString.removeSpecialCharacter(txtGrpApplLineBus.Text) & "','" & txtGrpApplPeriodBus.Text & "','" & BankString.removeSpecialCharacter(txtGrpApplSrcIncome1.Text) & "','" & BankString.removeSpecialCharacter(txtGrpApplSrcIncome2.Text) & "','" & BankString.removeSpecialCharacter(txtGrpApplSrcIncome3.Text) & "','" & BankString.removeSpecialCharacter(txtGrpApplBorrow1.Text) & "','" & BankString.removeSpecialCharacter(txtGrpApplBorrow2.Text) & "','" & BankString.removeSpecialCharacter(txtGrpApplBorrow3.Text) & "','" & txtGrpApplLoanAmt.Text & "','" & txtGrpApplRepayTenure.Text & "','" & BankString.removeSpecialCharacter(txtGrpApplPurpose.Text) & "','" & txtGrpApplInterest.Text & "','" & Session("UserID") & "',getdate(),'','','SUBMITTED','4042','" & Session("ID") & "','" & Session("ID") & "','" & txtGrpApplLoanAmt.Text & "','" & txtGrpAdminFee.Text & "','" & lblBranchCode.Text & "','" & BankString.removeSpecialCharacter(lblBranchName.Text) & "','" & ViewState("ReadyToDisburse") & "',1)", con)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            If cmd.ExecuteNonQuery() Then
                'msgbox("Application saved")
                ViewState("globLoanID") = getLastLoanID()
                Dim strEmail As String
                Dim SignatoryEMail As String
                'SignatoryEMail = Mailhelper.GetEMailID(ddl_SendTo.SelectedValue.ToString())
                'SignatoryEMail = Mailhelper.GetMultiBranchRoleEMailID(Session("BRANCHCODE"), "4042")
                SignatoryEMail = Mailhelper.GetMultipleEMailID("4042")

                strEmail = "<Strong>Dear Sir/Madam,</strong><br>You Have Received A New Loan Application Request. Details are as follows<br><br>"
                strEmail = strEmail & "<Table bgcolor='444444'><font forecolor='ffffff'>"
                strEmail = strEmail & "<tr bgcolor='999999'><td>Date:</td><td>" & Now & "</td></tr>"
                strEmail = strEmail & "<tr bgcolor='eeeeee'><td>Applicant Type:</td><td>" & rdbClientType.SelectedItem.Text & "</td></tr>"
                strEmail = strEmail & "<tr bgcolor='999999'><td>Branch:</td><td>" & lblBranchCode.Text.Trim() & " - " & lblBranchName.Text.Trim() & "</td></tr>"
                'strEmail = strEmail & "<tr bgcolor='999999'><td>Branch Name:</td><td>" & txt_BranchName.Text.Trim() & "</td></tr>"
                strEmail = strEmail & "<tr bgcolor='999999'><td>Client Name:</td><td>" & txtGrpName.Text & "</td></tr>"
                'strEmail = strEmail & "<tr bgcolor='999999'><td>Transaction Type:</td><td>" & ddl_TransactionTy.SelectedItem.Text.Trim() & "</td></tr>"
                strEmail = strEmail & "<tr bgcolor='999999'><td>Amount:</td><td>" & txtGrpApplLoanAmt.Text & "</td></tr>"
                strEmail = strEmail & "</font></Table>"
                strEmail = strEmail & "<br><Strong>Thanks & Regards,<br>IT Support Team</strong>"

                If SignatoryEMail = "" Then
                Else
                    Mailhelper.SendMailMessage("administrator", SignatoryEMail, "", "", "Escrow Credit Management - Loan Application Request", strEmail)
                End If
                saveGrpMemberAmts(txtCustNo.Text, ViewState("globLoanID"))
                saveInitiatorCommentGrp()
                clearGroup()
                Response.Write("<script>alert('Application successfully saved') ; location.href='ApplicationForm.aspx'</script>")
            End If
            con.Close()
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Protected Sub btnGrpTerminate_Click(sender As Object, e As EventArgs) Handles btnGrpTerminate.Click
        cmd = New SqlCommand("update QUEST_APPLICATION set STATUS='TERMINATED',LAST_ID='" & Session("ID") & "',MODIFIED_DATE=GETDATE(),MODIFIED_BY='" & Session("UserID") & "' where ID='" & ViewState("globLoanID") & "'", con)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        If cmd.ExecuteNonQuery() Then
            Response.Write("<script>alert('Loan successfully terminated') ; location.href='ApplicationForm.aspx'</script>")
        End If
        con.Close()
    End Sub

    Protected Sub btnIDNo_Click(sender As Object, e As EventArgs) Handles btnIDNo.Click
        Try
            'cmd = New SqlCommand("select * from CUSTOMER_DETAILS where IDNO='" & txtIDNo.Text & "'", con)
            cmd = New SqlCommand("select *,convert(varchar,DOB,106) as DOB1,convert(varchar,ISSUE_DATE,106) as ISSUE_DATE1 from CUSTOMER_DETAILS where REPLACE(replace(IDNO,'-',''),' ','') = REPLACE(replace('" & txtIDNo.Text & "','-',''),' ','')", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "CUSTOMER")
            If ds.Tables(0).Rows.Count > 0 Then
                getNamesDT(ds.Tables(0))
                Dim outs = getOutstandingLoans(txtCustNo.Text)
                If outs = 0 Then
                ElseIf outs = 1 Then
                    notify("This customer already has 1 loan currently running.", "warning")
                ElseIf outs >= 2 Then
                    'modal confirmation
                    ClientScript.RegisterStartupScript(Me.GetType(), "Confirmation", "<script type=""text/javascript"">showConfirmOtherLoans();</script>")
                End If
                rdbSubIndividual_SelectedIndexChanged(sender, New EventArgs)
            Else
                notify("This ID number does not exist in the system", "error")
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnSaveFarmer_Click(sender As Object, e As EventArgs) Handles btnSaveFarmer.Click
        Try
            Dim adminCharge As Double = 0
            Try
                adminCharge = txtFarmOtherCharge.Text
            Catch ex As Exception
                adminCharge = 0
            End Try
            'msgbox("tfcghvjbnm")
            Dim cmtxt = ""
            If btnSaveFarmer.Text = "Update Application" Then
                'cmd = New SqlCommand("update QUEST_APPLICATION set [ASSET_NAME]=NULLIF('" & ddlAssets.SelectedItem.Text & "',''),[CUSTOMER_TYPE]=NULLIF('" & rdbClientType.SelectedValue & "',''),[CUSTOMER_NUMBER]='" & txtCustNo.Text & "',[SURNAME]='" & BankString.removeSpecialCharacter(txtFarmNameOfGroup.Text) & "',[FORENAMES]='" & BankString.removeSpecialCharacter(txtFarmNameOfApplicant.Text) & "',[DOB]='" & txtFarmDOB.Text & "',[IDNO]='" & txtFarmIDNo.Text & "',[ISSUE_DATE]='" & txtFarmIssDate.Text & "',[ADDRESS]='" & BankString.removeSpecialCharacter(txtFarmCurrentAddress.Text) & "',[PHONE_NO]='" & txtFarmPhoneNo.Text & "',[GENDER]='" & rdbFarmGender.SelectedValue & "',[SPOUSE_NAME]='" & BankString.removeSpecialCharacter(txtFarmNameOfSpouse.Text) & "',[FIN_AMT]='" & txtFarmLoanAmtReqd.Text & "',[FIN_TENOR]='" & txtFarmTenure.Text & "',[FIN_INT_RATE]='" & txtFarmIntRate.Text & "',[FIN_SEC_OFFER]='" & BankString.removeSpecialCharacter(txtFinReqSecOffer.Text) & "',[FIN_REPAY_DATE]='" & txtFarmRepayDate.Text & "',[OTHER_AMT]='" & txtFarmOtherCharge.Text & "',[MODIFIED_BY]='" & Session("UserID") & "',[MODIFIED_DATE]=getdate(),[STATUS]='SUBMITTED',[SEND_TO]='4042',[BRANCH_CODE]='" & lblBranchCode.Text & "',[BRANCH_NAME]='" & BankString.removeSpecialCharacter(lblBranchName.Text) & "',[AMT_APPLIED]='" & txtFarmLoanAmtReqd.Text & "',[OTHER_CHARGES]='" & txtFarmOtherCharge.Text & "',[DISBURSE_OPTION]='" & rdbFarmDisburseOption.SelectedValue & "',LO_ID='" & Session("ID") & "',LAST_ID='" & Session("ID") & "', MONTH_EXPENSE='" & txtFarmMonthlyExpense.Text & "', MONTH_INCOME='" & txtFarmMonthlyIncome.Text & "', PREV_SALES='" & txtFarmPreviousSales.Text & "', CURR_ESTIMATE='" & txtFarmCurrentEstimate.Text & "', CROPS='" & txtFarmCropsGrown.Text & "', FARM_PERIOD='" & txtFarmPeriodFarming.Text & "', SPOUSE_ADDRESS='" & BankString.removeSpecialCharacter(txtFarmCurrAddressOfSpouse.Text) & "',FIN_ADMIN='" & adminCharge & "' where ID='" & ViewState("globLoanID") & "'", con)
                cmtxt = "update QUEST_APPLICATION set [CUSTOMER_TYPE]=NULLIF('" & rdbClientType.SelectedItem.Text & "',''),[CUSTOMER_NUMBER]='" & txtCustNo.Text & "',[SURNAME]='" & BankString.removeSpecialCharacter(txtFarmNameOfGroup.Text) & "',[FORENAMES]='" & BankString.removeSpecialCharacter(txtFarmNameOfApplicant.Text) & "',[DOB]='" & txtFarmDOB.Text & "',[IDNO]='" & txtFarmIDNo.Text & "',[ISSUE_DATE]='" & txtFarmIssDate.Text & "',[ADDRESS]='" & BankString.removeSpecialCharacter(txtFarmCurrentAddress.Text) & "',[PHONE_NO]='" & txtFarmPhoneNo.Text & "',[GENDER]='" & rdbFarmGender.SelectedValue & "',[SPOUSE_NAME]='" & BankString.removeSpecialCharacter(txtFarmNameOfSpouse.Text) & "',[FIN_AMT]='" & txtFarmLoanAmtReqd.Text & "',[FIN_TENOR]='" & txtFarmTenure.Text & "',[FIN_INT_RATE]='" & txtFarmIntRate.Text & "',[FIN_SEC_OFFER]='" & BankString.removeSpecialCharacter(txtFinReqSecOffer.Text) & "',[FIN_REPAY_DATE]='" & txtFarmRepayDate.Text & "',[OTHER_AMT]='" & txtFarmOtherCharge.Text & "',[MODIFIED_BY]='" & Session("UserID") & "',[MODIFIED_DATE]=getdate(),[STATUS]='SUBMITTED',[SEND_TO]='4042',[BRANCH_CODE]='" & lblBranchCode.Text & "',[BRANCH_NAME]='" & BankString.removeSpecialCharacter(lblBranchName.Text) & "',[AMT_APPLIED]='" & txtFarmLoanAmtReqd.Text & "',[OTHER_CHARGES]='" & txtFarmOtherCharge.Text & "',[DISBURSE_OPTION]='" & rdbFarmDisburseOption.SelectedValue & "',LO_ID='" & Session("ID") & "',LAST_ID='" & Session("ID") & "', MONTH_EXPENSE='" & txtFarmMonthlyExpense.Text & "', MONTH_INCOME='" & txtFarmMonthlyIncome.Text & "', PREV_SALES='" & txtFarmPreviousSales.Text & "', CURR_ESTIMATE='" & txtFarmCurrentEstimate.Text & "', CROPS='" & txtFarmCropsGrown.Text & "', FARM_PERIOD='" & txtFarmPeriodFarming.Text & "', SPOUSE_ADDRESS='" & BankString.removeSpecialCharacter(txtFarmCurrAddressOfSpouse.Text) & "',FIN_ADMIN='" & adminCharge & "' where ID='" & ViewState("globLoanID") & "'"
                'msgbox(cmd.CommandText)
            Else
                'cmd = New SqlCommand("insert into QUEST_APPLICATION ([ASSET_NAME],[CUSTOMER_TYPE],[CUSTOMER_NUMBER],[SURNAME],[FORENAMES],[DOB],[IDNO],[ISSUE_DATE],[ADDRESS],[PHONE_NO],[GENDER],[SPOUSE_NAME],[FIN_AMT],[FIN_TENOR],[FIN_INT_RATE],[FIN_REPAY_DATE],[APP1_APPROVED],[RECOMMENDED_AMT],[APP1_SIGNATURE],[APP2_APPROVED],[APPROVED_AMT],[APP2_SIGNATURE],[INSTALLMENT],[PERIOD],[CREATED_BY],[CREATED_DATE],[MODIFIED_BY],[MODIFIED_DATE],[STATUS],[SEND_TO],[BRANCH_CODE],[BRANCH_NAME],[AMT_APPLIED],[ECOCASH_NUMBER],[OTHER_CHARGES],[DISBURSE_OPTION],LO_ID,LAST_ID, MONTH_EXPENSE, MONTH_INCOME, PREV_SALES, CURR_ESTIMATE, CROPS, FARM_PERIOD, SPOUSE_ADDRESS,FIN_ADMIN) values (NULLIF('" & Trim(ddlAssets.SelectedItem.Text) & "',''),NULLIF('" & rdbClientType.SelectedValue & "',''),'" & txtCustNo.Text & "','" & BankString.removeSpecialCharacter(txtFarmNameOfGroup.Text) & "','" & BankString.removeSpecialCharacter(txtFarmNameOfApplicant.Text) & "','" & txtFarmDOB.Text & "','" & txtFarmIDNo.Text & "','" & txtFarmIssDate.Text & "','" & BankString.removeSpecialCharacter(txtFarmCurrentAddress.Text) & "','" & txtFarmPhoneNo.Text & "','" & rdbFarmGender.SelectedValue & "','" & BankString.removeSpecialCharacter(txtFarmNameOfSpouse.Text) & "','" & txtFarmLoanAmtReqd.Text & "','" & txtFarmTenure.Text & "','" & txtFarmIntRate.Text & "','" & txtFarmRepayDate.Text & "','','','','','','','','','" & Session("UserID") & "',getdate(),'','','SUBMITTED','4042','" & lblBranchCode.Text & "','" & BankString.removeSpecialCharacter(lblBranchName.Text) & "','" & txtFarmLoanAmtReqd.Text & "','','" & txtFarmOtherCharge.Text & "','" & rdbFarmDisburseOption.SelectedValue & "','" & Session("ID") & "','" & Session("ID") & "','" & txtFarmMonthlyExpense.Text & "','" & txtFarmMonthlyIncome.Text & "','" & txtFarmPreviousSales.Text & "','" & txtFarmCurrentEstimate.Text & "','" & txtFarmCropsGrown.Text & "','" & txtFarmPeriodFarming.Text & "','" & txtFarmCurrAddressOfSpouse.Text & "','" & adminCharge & "')", con)
                cmtxt = "insert into QUEST_APPLICATION ([CUSTOMER_TYPE],[CUSTOMER_NUMBER],[SURNAME],[FORENAMES],[DOB],[IDNO],[ISSUE_DATE],[ADDRESS],[PHONE_NO],[GENDER],[SPOUSE_NAME],[FIN_AMT],[FIN_TENOR],[FIN_INT_RATE],[FIN_REPAY_DATE],[APP1_APPROVED],[RECOMMENDED_AMT],[APP1_SIGNATURE],[APP2_APPROVED],[APPROVED_AMT],[APP2_SIGNATURE],[INSTALLMENT],[PERIOD],[CREATED_BY],[CREATED_DATE],[MODIFIED_BY],[MODIFIED_DATE],[STATUS],[SEND_TO],[BRANCH_CODE],[BRANCH_NAME],[AMT_APPLIED],[ECOCASH_NUMBER],[OTHER_CHARGES],[DISBURSE_OPTION],LO_ID,LAST_ID, MONTH_EXPENSE, MONTH_INCOME, PREV_SALES, CURR_ESTIMATE, CROPS, FARM_PERIOD, SPOUSE_ADDRESS,FIN_ADMIN) values (NULLIF('" & rdbClientType.SelectedItem.Text & "',''),'" & txtCustNo.Text & "','" & BankString.removeSpecialCharacter(txtFarmNameOfGroup.Text) & "','" & BankString.removeSpecialCharacter(txtFarmNameOfApplicant.Text) & "','" & txtFarmDOB.Text & "','" & txtFarmIDNo.Text & "','" & txtFarmIssDate.Text & "','" & BankString.removeSpecialCharacter(txtFarmCurrentAddress.Text) & "','" & txtFarmPhoneNo.Text & "','" & rdbFarmGender.SelectedValue & "','" & BankString.removeSpecialCharacter(txtFarmNameOfSpouse.Text) & "','" & txtFarmLoanAmtReqd.Text & "','" & txtFarmTenure.Text & "','" & txtFarmIntRate.Text & "','" & txtFarmRepayDate.Text & "','','','','','','','','','" & Session("UserID") & "',getdate(),'','','SUBMITTED','4042','" & lblBranchCode.Text & "','" & BankString.removeSpecialCharacter(lblBranchName.Text) & "','" & txtFarmLoanAmtReqd.Text & "','','" & txtFarmOtherCharge.Text & "','" & rdbFarmDisburseOption.SelectedValue & "','" & Session("ID") & "','" & Session("ID") & "','" & txtFarmMonthlyExpense.Text & "','" & txtFarmMonthlyIncome.Text & "','" & txtFarmPreviousSales.Text & "','" & txtFarmCurrentEstimate.Text & "','" & txtFarmCropsGrown.Text & "','" & txtFarmPeriodFarming.Text & "','" & txtFarmCurrAddressOfSpouse.Text & "','" & adminCharge & "')"
            End If
            'msgbox(cmtxt)
            'Exit Sub
            'msgbox(ddlAssets.SelectedItem.Text)
            cmd = New SqlCommand(cmtxt, con)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            'msgbox(cmd.CommandText)
            Try
                If cmd.ExecuteNonQuery() Then
                    updateDocLoanID(txtCustNo.Text)
                    saveInitiatorComment()
                    Dim strEmail As String
                    Dim SignatoryEMail As String
                    'Dim SignatoryEMail As String = Mailhelper.GetMultiBranchRoleEMailID(Session("BRANCHCODE"), "4042")

                    strEmail = "<Strong>Dear Sir/Madam,</strong><br>You Have Received A New Loan Application Request. Details are as follows<br><br>"
                    strEmail = strEmail & "<Table bgcolor='444444'><font forecolor='ffffff'>"
                    strEmail = strEmail & "<tr bgcolor='999999'><td>Date:</td><td>" & Now & "</td></tr>"
                    strEmail = strEmail & "<tr bgcolor='eeeeee'><td>Applicant Type:</td><td>" & rdbClientType.SelectedItem.Text & "</td></tr>"
                    strEmail = strEmail & "<tr bgcolor='999999'><td>Branch:</td><td>" & lblBranchCode.Text.Trim() & " - " & lblBranchName.Text.Trim() & "</td></tr>"
                    'strEmail = strEmail & "<tr bgcolor='999999'><td>Branch Name:</td><td>" & txt_BranchName.Text.Trim() & "</td></tr>"
                    strEmail = strEmail & "<tr bgcolor='999999'><td>Client Name:</td><td>" & txtGrpName.Text & "</td></tr>"
                    'strEmail = strEmail & "<tr bgcolor='999999'><td>Transaction Type:</td><td>" & ddl_TransactionTy.SelectedItem.Text.Trim() & "</td></tr>"
                    strEmail = strEmail & "<tr bgcolor='999999'><td>Amount:</td><td>" & txtFinReqAmt.Text & "</td></tr>"
                    strEmail = strEmail & "</font></Table>"
                    strEmail = strEmail & "<br/><Strong>Thanks & Regards,<br/>IT Support Team</strong>"
                    'If Trim(SignatoryEMail) = "" Then
                    SignatoryEMail = Mailhelper.GetMultipleEMailID("4042")
                    'End If
                    Mailhelper.SendMailMessage("administrator", SignatoryEMail, "", "", "Escrow Credit Management - Loan Application", strEmail)
                    clearAll()
                    lblTest.Text = ViewState("globLoanID")
                    'msgbox("Application saved. Loan ID is " & ViewState("globLoanID") & "")

                    ClientScript.RegisterStartupScript(Me.GetType(), "HideLabel", "<script type=""text/javascript"">showPopup()</script>")
                End If
            Catch ex As Exception
                WriteLogFile(ex.ToString)
            End Try
            con.Close()
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Protected Sub btnSearchCustNo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearchCustNo.Click
        clearAllExceptCustNo()
        If isValidCustID(txtCustNo.Text) Then
            Dim outs = getOutstandingLoans(txtCustNo.Text)

            If outs = 0 Then
            ElseIf outs = 1 Then
                CreditManager.notify("This customer already has 1 loan currently running.", "warning")
            ElseIf outs >= 2 Then
                'modal confirmation
                ClientScript.RegisterStartupScript(Me.GetType(), "Confirmation", "<script type=""text/javascript"">showConfirmOtherLoans();</script>")
            End If
            getNames(txtCustNo.Text)
            'loadProductType(cmbProductType)
            ' rdbSubIndividual_SelectedIndexChanged(sender, New EventArgs)
        Else
            notify("No record with this customer number was found.", "error")
        End If
    End Sub

    Protected Sub btnSearchSurname_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearchSurname.Click
        Try
            Using cmd = New SqlCommand("select CUSTOMER_NUMBER, isnull(SURNAME,'')+' '+isnull(FORENAMES,'')+' --- '+isnull(IDNO,'')+' --- '+isnull(ADDRESS,'') as display from CUSTOMER_DETAILS where isnull(SURNAME,'')+' '+isnull(FORENAMES,'')+' --- '+isnull(IDNO,'')+' --- '+isnull(ADDRESS,'') like '%" & txtSearchSurname.Text & "%'", con)
                Dim ds As New DataSet
                adp = New SqlDataAdapter(cmd)
                adp.Fill(ds, "cust")
                If ds.Tables(0).Rows.Count > 0 Then
                    lstSurname.Visible = True
                    lstSurname.DataSource = ds.Tables(0)
                    lstSurname.DataTextField = "display"
                    lstSurname.DataValueField = "CUSTOMER_NUMBER"
                Else
                    lstSurname.DataSource = Nothing
                    CreditManager.notify("The searched name was not found", "error")
                End If
                clearAll()
                lstSurname.DataBind()
            End Using
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        submitApplication()
    End Sub

    Protected Sub btnTerminate_Click(sender As Object, e As EventArgs) Handles btnTerminate.Click
        cmd = New SqlCommand("update QUEST_APPLICATION set STATUS='TERMINATED',LAST_ID='" & Session("ID") & "',MODIFIED_DATE=GETDATE(),MODIFIED_BY='" & Session("UserID") & "' where ID='" & ViewState("globLoanID") & "'", con)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        If cmd.ExecuteNonQuery() Then
            Response.Write("<script>alert('Loan successfully terminated') ; location.href='ApplicationForm.aspx'</script>")
        End If
        con.Close()
    End Sub

    Protected Sub btnUploadApp_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnUploadApp.Click
        Try
            Dim filePath As String = filAttachApp.PostedFile.FileName
            Dim filename As String = Path.GetFileName(filePath)
            Dim ext As String = Path.GetExtension(filename)
            Dim contenttype As String = String.Empty
            'Set the contenttype based on File Extension
            Select Case ext
                Case ".doc"
                    contenttype = "application/msword"
                    Exit Select
                Case ".docx"
                    contenttype = "application/msword"
                    Exit Select
                Case ".xls"
                    contenttype = "application/x-msexcel"
                    Exit Select
                Case ".xlsx"
                    contenttype = "application/x-msexcel"
                    Exit Select
                Case ".jpg"
                    contenttype = "image/jpg"
                    Exit Select
                Case ".png"
                    contenttype = "image/png"
                    Exit Select
                Case ".gif"
                    contenttype = "image/gif"
                    Exit Select
                Case ".pdf"
                    contenttype = "application/pdf"
                    Exit Select
            End Select

            If contenttype <> String.Empty Then
                Dim fs As Stream = filAttachApp.PostedFile.InputStream
                Dim br As New BinaryReader(fs)
                Dim bytes As Byte() = br.ReadBytes(fs.Length)

                'insert the file into database
                Dim strQuery As String = "insert into QUEST_DOCUMENTS" _
                & "(CUST_NO, LOAN_ID, DOC_DESC, DOC_DATA, DOC_TYPE, DOC_EXT, DOC_FILENAME)" _
                & " values (@CUST_NO, @LOAN_ID,@DOC_DESC, @DOC_DATA,@DOC_TYPE,@DOC_EXT, @DOC_FILENAME)"
                Dim cmd As New SqlCommand(strQuery)
                cmd.Parameters.Add("@CUST_NO", SqlDbType.VarChar).Value = txtCustNo.Text
                cmd.Parameters.Add("@LOAN_ID", SqlDbType.VarChar).Value = "" 'yet to be determined at this stage. Must be updated at form submit
                cmd.Parameters.Add("@DOC_FILENAME", SqlDbType.VarChar).Value = filename
                cmd.Parameters.Add("@DOC_DESC", SqlDbType.VarChar).Value = txtDocDesc.Text
                cmd.Parameters.Add("@DOC_EXT", SqlDbType.VarChar).Value = ext
                cmd.Parameters.Add("@DOC_TYPE", SqlDbType.VarChar).Value = contenttype
                cmd.Parameters.Add("@DOC_DATA", SqlDbType.Binary).Value = bytes
                If InsertUpdateData(cmd) Then
                    txtDocDesc.Text = ""
                    loadUploadedFiles(txtCustNo.Text)
                    notify("File uploaded successfully", "success")
                Else
                    notify("An error occurred while uploading the file", "error")
                End If
            Else
                notify("Select the file to upload", "error")
            End If
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Protected Sub chkTickSSB_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkTickSSB.CheckedChanged
        Try
            If chkTickSSB.Checked Then
                btnSubmit.Enabled = True
            Else
                btnSubmit.Enabled = False
            End If
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Protected Sub clearAll()
        Try
            txtAddress.Text = ""
            txtCustNo.Text = ""
            txtForenames.Text = ""
            txtPhoneNo.Text = ""
            txtSurname.Text = ""
            txtCity.Text = ""
            txtCurrEmployer.Text = ""
            txtEducationOther.Text = ""
            txtEmpAddress.Text = ""
            txtEmpCity.Text = ""
            txtEmpEmail.Text = ""
            txtEmpFax.Text = ""
            txtEmpHowLong.Text = ""
            txtEmpOtherIncome.Text = ""
            txtEmpPhone.Text = ""
            txtEmpPosition.Text = ""
            txtEmpSalary.Text = ""
            txtEmpSalaryNet.Text = ""
            txtHouseHowLong.Text = ""
            txtIDNo.Text = ""
            txtNationality.Text = ""
            txtNoChildren.Text = ""
            txtNoDependant.Text = ""
            txtPhoneNo.Text = ""
            txtPrevEmpAddress.Text = ""
            txtPrevEmpAnnualIncome.Text = ""
            txtPrevEmpCity.Text = ""
            txtPrevEmpEmail.Text = ""
            txtPrevEmpFax.Text = ""
            txtPrevEmpHowLong.Text = ""
            txtPrevEmployer.Text = ""
            txtPrevEmpPhone.Text = ""
            txtPrevEmpPosition.Text = ""
            txtPrevEmpSalary.Text = ""
            txtPrevEmpSalaryNet.Text = ""
            txtRent.Text = ""
            txtSpouse.Text = ""
            txtSpouseEmployer.Text = ""
            txtSpouseOccupation.Text = ""
            txtSpousePhone.Text = ""
            txtTradeRef1.Text = ""
            txtTradeRef2.Text = ""
            txtFinReqAccNo.Text = ""
            txtFinReqAmt.Text = ""
            txtFinReqBank.Text = ""
            txtFinReqBranchCode.Text = ""
            txtFinReqBranchName.Text = ""
            txtFinReqIntRate.Text = ""
            txtFinReqPurpose.Text = ""
            txtFinReqSecOffer.Text = ""
            txtFinReqSource.Text = ""
            txtFinReqTenor.Text = ""
            txtGuarCity.Text = ""
            txtGuarCurrAdd.Text = ""
            txtGuarCurrEmp.Text = ""
            txtGuarEmpAdd.Text = ""
            txtGuarEmpEmail.Text = ""
            txtGuarEmpFax.Text = ""
            txtGuarEmpIncome.Text = ""
            txtGuarEmpLength.Text = ""
            txtGuarEmpPhone.Text = ""
            txtGuarEmpPosition.Text = ""
            txtGuarEmpSalary.Text = ""
            txtGuarHomeLength.Text = ""
            txtGuarIDNo.Text = ""
            txtGuarMonthRent.Text = ""
            txtGuarName.Text = ""
            txtGuarNameRelative.Text = ""
            txtGuarPhone.Text = ""
            txtGuarRelAddress.Text = ""
            txtGuarRelCity.Text = ""
            txtGuarRelPhone.Text = ""
            txtGuarRelReltnship.Text = ""
            txtOtherAccNo.Text = ""
            txtOtherAmt.Text = ""
            txtOtherDesc.Text = ""
            txtQuesAgent.Text = ""
            txtQuesEmployee.Text = ""
            txtMinDept.Text = ""
            txtMinDeptNo.Text = ""
            txtECNo.Text = ""
            txtECNoCD.Text = ""
            txtInsuranceRate.Text = ""
            txtInterestRate.Text = ""
            txtAdminRate.Text = ""
            lblValAmount.Text = ""
            lblValInterest.Text = ""

            lblSurname.Text = "Surname"
            lblForenames.Text = "Forenames"
            lblForenames.Visible = True
            txtForenames.Visible = True
            rdbClientType.ClearSelection()
            rdbSubIndividual.ClearSelection()
            'rdbFinReqDisburseOption.ClearSelection()
            rdbGender.ClearSelection()
            rdbHouse.ClearSelection()
            rdbGuarHomeType.ClearSelection()
            rdbQuesHow.ClearSelection()
            cmbEducation.ClearSelection()
            cmbMaritalStatus.ClearSelection()
            bdpDOB.Text = ""
            bdpIssDate.Text = ""
            bdpGuarDOB.Text = ""
            bdpFinReqRepaymt.Text = ""
            cmbSector.ClearSelection()
            cmbProductType.ClearSelection()
            imgClientPhoto.ImageUrl = ""
            ViewState("NextRole") = "0"
            ViewState("ReadyToDisburse") = "0"
            ViewState("NextStageName") = ""
            ViewState("StageName") = ""
            txtBankAccountNo.Text = ""
            txtBankName.Text = ""
            txtBranchCode.Text = ""
            txtBranchName.Text = ""
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Protected Sub clearAllExceptCustNo()
        Try
            txtAddress.Text = ""
            txtForenames.Text = ""
            txtPhoneNo.Text = ""
            txtSurname.Text = ""
            txtCity.Text = ""
            txtCurrEmployer.Text = ""
            txtEducationOther.Text = ""
            txtEmpAddress.Text = ""
            txtEmpCity.Text = ""
            txtEmpEmail.Text = ""
            txtEmpFax.Text = ""
            txtEmpHowLong.Text = ""
            txtEmpOtherIncome.Text = ""
            txtEmpPhone.Text = ""
            txtEmpPosition.Text = ""
            txtEmpSalary.Text = ""
            txtEmpSalaryNet.Text = ""
            txtHouseHowLong.Text = ""
            txtIDNo.Text = ""
            txtNationality.Text = ""
            txtNoChildren.Text = ""
            txtNoDependant.Text = ""
            txtPhoneNo.Text = ""
            txtPrevEmpAddress.Text = ""
            txtPrevEmpAnnualIncome.Text = ""
            txtPrevEmpCity.Text = ""
            txtPrevEmpEmail.Text = ""
            txtPrevEmpFax.Text = ""
            txtPrevEmpHowLong.Text = ""
            txtPrevEmployer.Text = ""
            txtPrevEmpPhone.Text = ""
            txtPrevEmpPosition.Text = ""
            txtPrevEmpSalary.Text = ""
            txtPrevEmpSalaryNet.Text = ""
            txtRent.Text = ""
            txtSpouse.Text = ""
            txtSpouseEmployer.Text = ""
            txtSpouseOccupation.Text = ""
            txtSpousePhone.Text = ""
            txtTradeRef1.Text = ""
            txtTradeRef2.Text = ""
            txtFinReqAccNo.Text = ""
            txtFinReqAmt.Text = ""
            txtFinReqBank.Text = ""
            txtFinReqBranchCode.Text = ""
            txtFinReqBranchName.Text = ""
            txtFinReqIntRate.Text = ""
            txtFinReqPurpose.Text = ""
            txtFinReqSecOffer.Text = ""
            txtFinReqSource.Text = ""
            txtFinReqTenor.Text = ""
            txtGuarCity.Text = ""
            txtGuarCurrAdd.Text = ""
            txtGuarCurrEmp.Text = ""
            txtGuarEmpAdd.Text = ""
            txtGuarEmpEmail.Text = ""
            txtGuarEmpFax.Text = ""
            txtGuarEmpIncome.Text = ""
            txtGuarEmpLength.Text = ""
            txtGuarEmpPhone.Text = ""
            txtGuarEmpPosition.Text = ""
            txtGuarEmpSalary.Text = ""
            txtGuarHomeLength.Text = ""
            txtGuarIDNo.Text = ""
            txtGuarMonthRent.Text = ""
            txtGuarName.Text = ""
            txtGuarNameRelative.Text = ""
            txtGuarPhone.Text = ""
            txtGuarRelAddress.Text = ""
            txtGuarRelCity.Text = ""
            txtGuarRelPhone.Text = ""
            txtGuarRelReltnship.Text = ""
            txtOtherAccNo.Text = ""
            txtOtherAmt.Text = ""
            txtOtherDesc.Text = ""
            txtQuesAgent.Text = ""
            txtQuesEmployee.Text = ""
            txtMinDept.Text = ""
            txtMinDeptNo.Text = ""
            txtECNo.Text = ""
            txtECNoCD.Text = ""
            txtInsuranceRate.Text = ""
            txtInterestRate.Text = ""
            txtAdminRate.Text = ""

            lblSurname.Text = "Surname"
            lblForenames.Text = "Forenames"
            lblForenames.Visible = True
            txtForenames.Visible = True
            rdbClientType.ClearSelection()
            rdbSubIndividual.ClearSelection()
            rdbGender.ClearSelection()
            rdbHouse.ClearSelection()
            rdbGuarHomeType.ClearSelection()
            rdbQuesHow.ClearSelection()
            cmbEducation.ClearSelection()
            cmbMaritalStatus.ClearSelection()
            bdpDOB.Text = ""
            bdpIssDate.Text = ""
            bdpGuarDOB.Text = ""
            bdpFinReqRepaymt.Text = ""
            cmbSector.ClearSelection()
            cmbProductType.ClearSelection()
            imgClientPhoto.ImageUrl = ""
            ViewState("NextRole") = "0"
            ViewState("ReadyToDisburse") = "0"
            ViewState("NextStageName") = ""
            ViewState("StageName") = ""
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Protected Sub clearGroup()
        rdbClientType.ClearSelection()
        txtCustNo.Text = ""
        txtGrpName.Text = ""
        'cmbGrpApplicantName.ClearSelection()
        'bdpGrpApplDOB.Clear()
        'txtGrpApplID.Text = ""
        'bdpGrpApplIssueDate.Clear()
        'txtGrpApplCurrAdd.Text = ""
        'txtGrpApplCity.Text = ""
        'txtGrpApplPhone.Text = ""
        'txtGrpApplNationality.Text = ""
        'rdbGrpApplGender.ClearSelection()
        txtGrpApplLineBus.Text = ""
        txtGrpApplPeriodBus.Text = ""
        txtGrpApplSrcIncome1.Text = ""
        txtGrpApplSrcIncome2.Text = ""
        txtGrpApplSrcIncome3.Text = ""
        txtGrpApplBorrow1.Text = ""
        txtGrpApplBorrow2.Text = ""
        txtGrpApplBorrow3.Text = ""
        txtGrpApplLoanAmt.Text = ""
        txtGrpApplRepayTenure.Text = ""
        txtGrpApplPurpose.Text = ""
        chkGrpApplSigned.Checked = False
    End Sub

    Protected Sub clientTypeVisible()
        If rdbClientType.SelectedItem.Text = "Individual" Then
            panGroup.Visible = False
            panIndividual.Visible = True
            pnlFarmers.Visible = False
        ElseIf rdbClientType.SelectedItem.Text = "Business" Or rdbClientType.SelectedItem.Text = "Group" Then
            panGroup.Visible = True
            panIndividual.Visible = False
            pnlFarmers.Visible = False
        ElseIf rdbClientType.SelectedItem.Text = "Farmer" Then
            panGroup.Visible = False
            panIndividual.Visible = False
            pnlFarmers.Visible = True
        End If
    End Sub

    Protected Sub cmbBankAppType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbBankAppType.SelectedIndexChanged
        loadBranch(cmbBranchAppType, cmbBankAppType)
    End Sub

    Protected Sub cmbEducation_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbEducation.SelectedIndexChanged
        If cmbEducation.SelectedValue = "Other" Then
            txtEducationOther.Visible = True
        Else
            txtEducationOther.Visible = False
        End If
    End Sub

    Protected Sub cmbFinReqBank_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbFinReqBank.SelectedIndexChanged
        Try
            loadBranch(cmbFinReqBranch, cmbFinReqBank)
            txtFinReqBank.Text = cmbFinReqBank.SelectedItem.Text.ToString
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Protected Sub cmbFinReqBranch_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbFinReqBranch.SelectedIndexChanged
        Try
            txtFinReqBranchName.Text = cmbFinReqBranch.SelectedItem.Text
            txtFinReqBranchCode.Text = cmbFinReqBranch.SelectedValue
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddlAssets_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlAssets.SelectedIndexChanged
        txtFinReqAmt.Text = ddlAssets.SelectedValue
    End Sub

    Protected Sub ecocashInvisible()
        Try
            lblEcocashNumber.Visible = False
            txtEcocashNumber.Visible = False
            txtEcocashNumber.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ecocashVisible()
        Try
            lblEcocashNumber.Visible = True
            txtEcocashNumber.Visible = True
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub getAppDetails(ByVal loanID As String)
        Try
            cmd = New SqlCommand("select *,convert(varchar,DOB,106) as DOB1,convert(varchar,GUARANTOR_DOB,106) as GUARANTOR_DOB1,convert(varchar,ISSUE_DATE,106) as ISSUE_DATE1 from QUEST_APPLICATION where ID='" & loanID & "'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "APP")
            If ds.Tables(0).Rows.Count > 0 Then
                Try
                    If ds.Tables(0).Rows(0).Item("STATUS") = "REJECTED" Then
                        ViewState("prevUser") = ds.Tables(0).Rows(0).Item("LAST_ID")
                    Else
                        ViewState("prevUser") = ds.Tables(0).Rows(0).Item("LAST_ID")
                    End If
                Catch ex As Exception
                    ViewState("prevUser") = ""
                End Try
                txtCustNo.Text = ds.Tables(0).Rows(0).Item("CUSTOMER_NUMBER")
                txtSurname.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SURNAME"))
                txtForenames.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FORENAMES"))
                lblBranchCode.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("BRANCH_CODE"))
                lblBranchName.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("BRANCH_NAME"))
                txtAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ADDRESS"))
                'txtCreditLimit.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CREDIT_LIMIT"))
                txtPhoneNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PHONE_NO"))
                txtCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CITY"))
                txtCurrEmployer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMPLOYER"))
                txtEducationOther.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("EDUCATION"))
                txtEmpAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_ADD"))
                txtEmpCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_CITY"))
                txtEmpEmail.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_EMAIL"))
                txtEmpFax.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_FAX"))
                txtEmpHowLong.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_LENGTH")), 0)
                txtEmpOtherIncome.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_INCOME")), 2)
                txtEmpPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_PHONE"))
                txtEmpPosition.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_POSITION"))
                txtEmpSalary.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_SALARY")), 2)
                txtHouseHowLong.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("HOME_LENGTH")), 0)
                txtIDNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("IDNO"))
                txtNationality.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("NATIONALITY"))
                txtNoChildren.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("NO_CHILDREN"))
                txtNoDependant.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("NO_DEPENDANTS"))
                txtPrevEmpAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_ADD"))
                txtPrevEmpAnnualIncome.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_INCOME")), 2)
                txtPrevEmpCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_CITY"))
                txtPrevEmpEmail.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_EMAIL"))
                txtPrevEmpFax.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_FAX"))
                txtPrevEmpHowLong.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_LENGTH")), 0)
                txtPrevEmployer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMPLOYER"))
                txtPrevEmpPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_PHONE"))
                txtPrevEmpPosition.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_POSITION"))
                txtPrevEmpSalary.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_SALARY")), 2)
                txtRent.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("MONTHLY_RENT")), 2)
                txtSpouse.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_NAME"))
                txtSpouseEmployer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_EMPLOYER"))
                txtSpouseOccupation.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_OCCUPATION"))
                txtSpousePhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_PHONE"))
                txtTradeRef1.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("TRADE_REF1"))
                txtTradeRef2.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("TRADE_REF2"))
                txtGuarCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_CITY"))
                txtGuarCurrAdd.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_ADD"))
                txtGuarCurrEmp.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMPLOYER"))
                txtGuarEmpAdd.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_ADD"))
                txtGuarEmpEmail.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_EMAIL"))
                txtGuarEmpFax.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_FAX"))
                txtGuarEmpIncome.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_INCOME")), 2)
                txtGuarEmpLength.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_LENGTH")), 0)
                txtGuarEmpPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_PHONE"))
                txtGuarEmpPosition.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_POSTN"))
                txtGuarEmpSalary.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_SALARY")), 2)
                txtGuarHomeLength.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_HOME_LENGTH")), 0)
                txtGuarIDNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_IDNO"))
                txtGuarMonthRent.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_RENT")), 2)
                txtGuarName.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_NAME"))
                txtGuarNameRelative.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_NAME"))
                txtGuarPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_PHONE"))
                txtGuarRelAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_ADD"))
                txtGuarRelCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_CITY"))
                txtGuarRelPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_PHONE"))
                txtGuarRelReltnship.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_RELTNSHP"))
                txtFinReqAccNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_ACCNO"))
                txtFinReqAmt.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("AMT_APPLIED")), 2)
                'txtRecAmt.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_AMT")), 2)
                txtFinReqBank.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_BANK"))
                txtFinReqBranchCode.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_BRANCH_CODE"))
                txtFinReqBranchName.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_BRANCH"))
                txtFinReqIntRate.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_INT_RATE")), 2)
                txtFinReqPurpose.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_PURPOSE"))
                txtFinReqSecOffer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_SEC_OFFER"))
                txtFinReqSource.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_SRC_REPAYMT"))
                txtFinReqTenor.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_TENOR")), 0)
                txtOtherAccNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("OTHER_ACCNO"))
                txtOtherAmt.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("OTHER_AMT")), 2)
                txtOtherDesc.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("OTHER_DESC"))
                txtQuesAgent.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("QUES_AGENT"))
                txtQuesEmployee.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("QUES_EMPLOYEE"))
                
                txtInterestRate.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("INT_RATE"))
                txtInsuranceRate.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("INSURANCE_RATE"))
                txtAdminRate.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ADMIN_RATE"))

                loadOtherLoans()
                Try
                    rdbClientType.SelectedValue = ds.Tables(0).Rows(0).Item("CUSTOMER_TYPE_ID")
                    rdbGender.SelectedValue = ds.Tables(0).Rows(0).Item("GENDER")
                    rdbHouse.SelectedValue = ds.Tables(0).Rows(0).Item("HOME_TYPE")
                    rdbGuarHomeType.SelectedValue = ds.Tables(0).Rows(0).Item("GUARANTOR_HOME_TYPE")
                    rdbQuesHow.SelectedValue = ds.Tables(0).Rows(0).Item("QUES_HOW")
                    'rdbFinReqDisburseOption.SelectedValue = ds.Tables(0).Rows(0).Item("DISBURSE_OPTION")

                    cmbEducation.SelectedValue = ds.Tables(0).Rows(0).Item("EDUCATION")
                    cmbMaritalStatus.SelectedValue = ds.Tables(0).Rows(0).Item("MARITAL_STATUS")
                Catch ex As Exception

                End Try

                bdpDOB.Text = ds.Tables(0).Rows(0).Item("DOB1")
                bdpIssDate.Text = ds.Tables(0).Rows(0).Item("ISSUE_DATE1")
                bdpGuarDOB.Text = ds.Tables(0).Rows(0).Item("GUARANTOR_DOB1")
                If rdbClientType.SelectedItem.Text = "Individual" Then
                    Try
                        rdbSubIndividual.Visible = True
                        rdbSubIndividual.SelectedValue = ds.Tables(0).Rows(0).Item("SUB_INDIVIDUAL")
                    Catch ex As Exception

                    End Try
                    lblSurname.Text = "Surname"
                    lblForenames.Text = "Forenames"
                    lblForenames.Visible = True
                    txtForenames.Visible = True
                    If ViewState("PrePopulateGuarantor") Then
                        getGuarantorInfo(txtCustNo.Text)
                    End If
                ElseIf rdbClientType.SelectedItem.Text = "Business" Then
                    lblSurname.Text = "Name"
                    lblForenames.Visible = False
                    txtForenames.Visible = False
                    txtForenames.Text = ""
                End If
                If rdbSubIndividual.SelectedValue = "SSB" Then
                    txtMinDept.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("MIN_DEPT"))
                    txtMinDeptNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("MIN_DEPT_NO"))
                    txtECNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ECNO"))
                    txtECNoCD.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CD"))

                    lblMinDept.Visible = True
                    lblMinDeptNo.Visible = True
                    lblEmpCode.Visible = True
                    txtMinDept.Visible = True
                    txtMinDeptNo.Visible = True
                    txtECNo.Visible = True
                    txtECNoCD.Visible = True
                End If
                                txtEmpHowLong.Text=Convert.ToDateTime(ds.Tables(0).Rows(0).Item("DateOfEmployment")).ToString("d MMMM yyyy")
                'If rdbFinReqDisburseOption.SelectedValue = "Ecocash" Then
                '    lblEcocashNumber.Visible = True
                '    txtEcocashNumber.Visible = True
                '    txtEcocashNumber.Text = ds.Tables(0).Rows(0).Item("ECOCASH_NUMBER")
                'End If
              
            Else
            End If
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Protected Sub getAppHistory()
        Try
            cmd = New SqlCommand("select COMMENT_DATE as [DATE], USERID as [USER],CONVERT(DECIMAL(30,2),[RECOMMENDED_AMT]) as [RECOMMENDED AMOUNT],COMMENT from REQUEST_HISTORY where LOANID='" & Request.QueryString("id") & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "COMMENT")
            If ds.Tables(0).Rows.Count > 0 Then
                grdAppHistory.DataSource = ds.Tables(0)
            Else
                grdAppHistory.DataSource = Nothing
            End If
            grdAppHistory.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub getClientCollateral(custNo As String)
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd As New SqlCommand("select CollateralType as [Collateral Type],CollDesc as [Description],'ZMW' + ''+ CONVERT(varchar(12),CollValue, 1) as [Value] from ClientCollateral where CustNo='" & custNo & "' and LoanID=0", con)
                    Dim dt As New DataTable
                    Using adp = New SqlDataAdapter(cmd)
                        adp.Fill(dt)
                    End Using
                    bindGrid(dt, grdCollateral)
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- getClientCollateral()", ex.ToString)
        End Try
    End Sub

    Protected Sub getCreditParams(prod As String)
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd As New SqlCommand("Select * FROM [CreditProducts] where [id]='" & prod & "'", con)
                    Dim adp = New SqlDataAdapter(cmd)
                    Dim ds As New DataSet
                    adp.Fill(ds, "CP")
                    If ds.Tables(0).Rows.Count > 0 Then
                        Dim dr = ds.Tables(0).Rows(0)
                        lblValInterest.Text = "Minimum interest rate: " & dr("MinIntRate") & "%.  Maximum interest rate: " & dr("MaxIntRate") & "%"
                        ViewState("MinIntRate") = dr("MinIntRate")
                        ViewState("MaxIntRate") = dr("MaxIntRate")
                        hidMinInterest.Value = dr("MinIntRate")
                        hidMaxInterest.Value = dr("MaxIntRate")
                        lblValAmount.Text = "Minimum loan amount: " & dr("MinAmt") & ".  Maximum loan amount: " & dr("MaxAmt")
                        ViewState("MinAmt") = dr("MinAmt")
                        ViewState("MaxAmt") = dr("MaxAmt")
                        hidMinLoanAmount.Value = dr("MinAmt")
                        hidMaxLoanAmount.Value = dr("MaxAmt")
                        lblValTenure.Text = "Minimum loan tenure: " & FormatNumber(dr("MinimumTenure"), 0) & ".  Maximum loan tenure: " & FormatNumber(dr("MaximumTenure"), 0)
                        ViewState("MinimumTenure") = dr("MinimumTenure")
                        ViewState("MaximumTenure") = dr("MaximumTenure")
                        hidMinTenure.Value = dr("MinimumTenure")
                        hidMaxTenure.Value = dr("MaximumTenure")
                    Else
                        lblValInterest.Text = ""
                        lblValAmount.Text = ""
                        lblValTenure.Text = ""
                    End If
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- getCreditParams()", ex.ToString)
        End Try
    End Sub

    Protected Sub getCurrentExposure(custNo As String)
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd As New SqlCommand("Select isnull(sum(Debit-Credit),0) as Exposure FROM [Accounts_Transactions] where [Account]='" & custNo & "' or [Other]='" & custNo & "'", con)
                    Dim adp = New SqlDataAdapter(cmd)
                    Dim ds As New DataSet
                    adp.Fill(ds, "CP")
                    If ds.Tables(0).Rows.Count > 0 Then
                        Dim dr = ds.Tables(0).Rows(0)
                        lblCurrExposure.Text = "Current Exposure: " & FormatCurrency(dr("Exposure"))
                        ViewState("CurrentExposure") = dr("Exposure")
                        If CDbl(ViewState("MaxExposure")) < CDbl(ViewState("CurrentExposure")) Then
                            ClientScript.RegisterStartupScript(Me.GetType, "exposure", "<script type='text/javascript'>alert('Client has an exposure greater than the allowed maximum of " & FormatCurrency(ViewState("MaxExposure")) & "'); location.href = 'ApplicationForm.aspx'</script>")
                        Else
                            hidCurrentExposure.Value = dr("Exposure")
                            hidMaxExposure.Value = ViewState("MaxExposure")
                        End If
                    Else
                        lblCurrExposure.Text = ""
                    End If
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- getCreditParams()", ex.ToString)
        End Try
    End Sub

    Protected Sub getEcocashNumber()
        Try
            txtEcocashNumber.Text = txtPhoneNo.Text
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- getEcocashNumber()", ex.ToString)
        End Try
    End Sub

    Protected Function getEducation() As String
        If cmbEducation.SelectedValue = "Other" Then
            Return Trim("Other: " & BankString.removeSpecialCharacter(txtEducationOther.Text))
        Else
            Return cmbEducation.SelectedValue
        End If
    End Function

    Protected Function getFileName() As String
        Try
            Dim dir = Server.MapPath("~/Credit/Uploads/")
            Dim files As String() = Directory.GetFiles(dir, Session("ID") & "_AppForm*")
            If files Is Nothing Then
                Return ""
            Else
                Return files(0)
            End If
        Catch ex As Exception
            Return ""
        End Try
    End Function

    Protected Sub getGrpMemberAmts(cust As String)
        Dim cmd = New SqlCommand("select ID,NAME,IDNO from QUEST_GROUP_MEMBERS where CUSTOMER_NUMBER='" & cust & "'", con)
        Dim ds As New DataSet
        adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "QGM")
        If ds.Tables(0).Rows.Count > 0 Then
            repGrpMembers.DataSource = ds.Tables(0)
        Else
            repGrpMembers.DataSource = Nothing
        End If
        repGrpMembers.DataBind()
    End Sub

    Protected Sub getGrpMemberDetails(memberID As String)
        Dim cmd = New SqlCommand("select * from QUEST_GROUP_MEMBERS where ID='" & memberID & "'", con)
        Dim ds As New DataSet
        adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "QGM")
        If ds.Tables(0).Rows.Count > 0 Then
            'txtGrpApplicantName.Text = ds.Tables(0).Rows(0).Item("NAME")
            'txtGrpApplID.Text = ds.Tables(0).Rows(0).Item("IDNO")
        Else

        End If
    End Sub

    Protected Sub getGrpMemberExpenses()
        Try
            cmd = New SqlCommand("select ID,POSITION,NAME,IDNO,cast(RENT as numeric(18,2)) as RENT,cast(FOOD as numeric(18,2)) as FOOD,cast(FEES as numeric(18,2)) as FEES,cast(AIRTIME as numeric(18,2)) as AIRTIME,cast(MEDICAL as numeric(18,2)) as MEDICAL,cast(ELECTRICITY as numeric(18,2)) as ELECTRICITY,cast(WATER as numeric(18,2)) as WATER,cast(RATES as numeric(18,2)) as RATES,cast(CITY_OF_HRE as numeric(18,2)) as [CITY OF HARARE] from QUEST_GROUP_MEMBERS where CUSTOMER_NUMBER='" & txtCustNo.Text & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "QGM")
            If ds.Tables(0).Rows.Count > 0 Then
                grdGrpDeclExpense.DataSource = ds.Tables(0)
            Else
                grdGrpDeclExpense.DataSource = Nothing
            End If
            grdGrpDeclExpense.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub getGrpMembers()
        Try
            cmd = New SqlCommand("select ID,POSITION,NAME,IDNO from QUEST_GROUP_MEMBERS where CUSTOMER_NUMBER='" & txtCustNo.Text & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "QGM")
            If ds.Tables(0).Rows.Count > 0 Then
                grdGrpDeclMembers.DataSource = ds.Tables(0)
            Else
                grdGrpDeclMembers.DataSource = Nothing
            End If
            grdGrpDeclMembers.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub getGuarantorInfo(accNo As String)
        Try
            cmd = New SqlCommand("select *,convert(varchar,GUARANTOR_DOB,106) as GUARANTOR_DOB1 from QUEST_APPLICATION where [CUSTOMER_NUMBER]='" & accNo & "' order by id desc", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "APP")
            If ds.Tables(0).Rows.Count > 0 Then
                divGuarAlert.Visible = True
                txtGuarCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_CITY"))
                txtGuarCurrAdd.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_ADD"))
                txtGuarCurrEmp.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMPLOYER"))
                txtGuarEmpAdd.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_ADD"))
                txtGuarEmpEmail.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_EMAIL"))
                txtGuarEmpFax.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_FAX"))
                Try
                    txtGuarEmpIncome.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_INCOME")), 2)
                Catch ex As Exception
                    txtGuarEmpIncome.Text = ""
                End Try
                Try
                    txtGuarEmpLength.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_LENGTH")), 0)
                Catch ex As Exception
                    txtGuarEmpLength.Text = ""
                End Try
                txtGuarEmpPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_PHONE"))
                txtGuarEmpPosition.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_POSTN"))
                Try
                    txtGuarEmpSalary.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_SALARY")), 2)
                Catch ex As Exception
                    txtGuarEmpSalary.Text = ""
                End Try
                Try
                    txtGuarHomeLength.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_HOME_LENGTH")), 0)
                Catch ex As Exception
                    txtGuarHomeLength.Text = ""
                End Try
                txtGuarIDNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_IDNO"))
                Try
                    txtGuarMonthRent.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_RENT")), 2)
                Catch ex As Exception
                    txtGuarMonthRent.Text = ""
                End Try
                txtGuarName.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_NAME"))
                txtGuarNameRelative.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_NAME"))
                txtGuarPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_PHONE"))
                txtGuarRelAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_ADD"))
                txtGuarRelCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_CITY"))
                txtGuarRelPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_PHONE"))
                txtGuarRelReltnship.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_RELTNSHP"))
                Try
                    rdbGuarHomeType.SelectedValue = ds.Tables(0).Rows(0).Item("GUARANTOR_HOME_TYPE")
                Catch ex As Exception

                End Try

                bdpGuarDOB.Text = ds.Tables(0).Rows(0).Item("GUARANTOR_DOB1")
            Else
                divGuarAlert.Visible = False
                txtGuarCity.Text = ""
                txtGuarCurrAdd.Text = ""
                txtGuarCurrEmp.Text = ""
                txtGuarEmpAdd.Text = ""
                txtGuarEmpEmail.Text = ""
                txtGuarEmpFax.Text = ""
                txtGuarEmpIncome.Text = ""
                txtGuarEmpLength.Text = ""
                txtGuarEmpPhone.Text = ""
                txtGuarEmpPosition.Text = ""
                txtGuarEmpSalary.Text = ""
                txtGuarHomeLength.Text = ""
                txtGuarIDNo.Text = ""
                txtGuarMonthRent.Text = ""
                txtGuarName.Text = ""
                txtGuarNameRelative.Text = ""
                txtGuarPhone.Text = ""
                txtGuarRelAddress.Text = ""
                txtGuarRelCity.Text = ""
                txtGuarRelPhone.Text = ""
                txtGuarRelReltnship.Text = ""
            End If
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Protected Function getLastLoanID() As String
        cmd = New SqlCommand("select max(ID) from QUEST_APPLICATION", con)
        Dim loanID = ""
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        Try
            con.Open()
            loanID = cmd.ExecuteScalar
            con.Close()
        Catch ex As Exception
            loanID = "0"
        End Try
        Return loanID
    End Function

    Protected Sub getNames(ByVal custID As String)
        Try
            cmd = New SqlCommand("select *,convert(varchar,DOB,106) as DOB1,convert(varchar,ISSUE_DATE,106) as ISSUE_DATE1 from CUSTOMER_DETAILS where CUSTOMER_NUMBER='" & custID & "'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "CUSTOMER")
            If ds.Tables(0).Rows.Count > 0 Then
                If ds.Tables(0).Rows(0).Item("CUSTOMER_TYPE") = "Individual" Then
                    panGroup.Visible = False
                    panIndividual.Visible = True
                    pnlFarmers.Visible = False
                    Try
                        If Trim(BankString.isNullString(ds.Tables(0).Rows(0).Item("PhotoName"))) <> "" Then
                            imgClientPhoto.ImageUrl = "~/ClientPhotos/" & BankString.isNullString(ds.Tables(0).Rows(0).Item("PhotoName")) & ".jpg"
                        Else
                            imgClientPhoto.ImageUrl = ""
                        End If
                    Catch ex As Exception

                    End Try
                    txtCustNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CUSTOMER_NUMBER"))
                    txtSurname.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SURNAME"))
                    txtForenames.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FORENAMES"))
                    txtAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ADDRESS"))
                    txtPhoneNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PHONE_NO"))
                    txtCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CITY"))
                    txtCurrEmployer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMPLOYER"))
                    txtEducationOther.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("EDUCATION"))
                    txtEmpAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_ADD"))
                    txtEmpCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_CITY"))
                    txtEmpEmail.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_EMAIL"))
                    txtEmpFax.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_FAX"))
                    '///////////////////////////////////////////////////////////////load banking info
                    txtBankAccountNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("BankAccountNo"))
                    txtBankName.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("Bank"))
                    txtBranchCode.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("BranchCode"))
                    txtBranchName.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("BankBranch"))
                    '///////////////////////////////////////////////////////////////load banking info
                    Try
                        txtEmpHowLong.Text = FormatNumber(ds.Tables(0).Rows(0).Item("CURR_EMP_LENGTH"), 0)
                    Catch ex As Exception
                        txtEmpHowLong.Text = ""
                    End Try
                    Try
                        txtEmpOtherIncome.Text = FormatNumber(ds.Tables(0).Rows(0).Item("CURR_EMP_INCOME"), 2)
                    Catch ex As Exception
                        txtEmpOtherIncome.Text = ""
                    End Try

                    txtEmpPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_PHONE"))
                    txtEmpPosition.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_POSITION"))
                    Try
                        txtEmpSalary.Text = FormatNumber(ds.Tables(0).Rows(0).Item("CURR_EMP_SALARY"), 2)
                    Catch ex As Exception
                        txtEmpSalary.Text = ""
                    End Try
                    Try
                        getCurrentExposure(custID)
                    Catch ex As Exception
                    End Try
                    Try
                        txtEmpSalaryNet.Text = FormatNumber(ds.Tables(0).Rows(0).Item("CURR_EMP_NET"), 2)
                    Catch ex As Exception
                        txtEmpSalaryNet.Text = ""
                    End Try

                    Try
                        txtHouseHowLong.Text = FormatNumber(ds.Tables(0).Rows(0).Item("HOME_LENGTH"), 0)
                    Catch ex As Exception
                        txtHouseHowLong.Text = ""
                    End Try

                    txtIDNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("IDNO"))
                    txtNationality.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("NATIONALITY"))
                    txtNoChildren.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("NO_CHILDREN"))
                    txtNoDependant.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("NO_DEPENDANTS"))
                    txtPrevEmpAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_ADD"))
                    Try
                        txtPrevEmpAnnualIncome.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_INCOME")), 2)
                    Catch ex As Exception
                        txtPrevEmpAnnualIncome.Text = ""
                    End Try

                    txtPrevEmpCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_CITY"))
                    txtPrevEmpEmail.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_EMAIL"))
                    txtPrevEmpFax.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_FAX"))
                    Try
                        txtPrevEmpHowLong.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_LENGTH")), 0)
                    Catch ex As Exception
                        txtPrevEmpHowLong.Text = ""
                    End Try

                    txtPrevEmployer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMPLOYER"))
                    txtPrevEmpPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_PHONE"))
                    txtPrevEmpPosition.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_POSITION"))
                    Try
                        txtPrevEmpSalary.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_SALARY")), 2)
                    Catch ex As Exception
                        txtPrevEmpSalary.Text = ""
                    End Try

                    Try
                        txtPrevEmpSalaryNet.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_NET")), 2)
                    Catch ex As Exception
                        txtPrevEmpSalaryNet.Text = ""
                    End Try

                    'msgbox("clear")
                    Try
                        txtRent.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("MONTHLY_RENT")), 2)
                    Catch ex As Exception
                        txtRent.Text = ""
                    End Try

                    txtSpouse.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_NAME"))
                    txtSpouseEmployer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_EMPLOYER"))
                    txtSpouseOccupation.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_OCCUPATION"))
                    txtSpousePhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_PHONE"))
                    txtTradeRef1.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("TRADE_REF1"))
                    txtTradeRef2.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("TRADE_REF2"))
                    Try
                        rdbSubIndividual.SelectedValue = ds.Tables(0).Rows(0).Item("SUB_INDIVIDUAL")
                    Catch ex As Exception
                        rdbSubIndividual.ClearSelection()
                    End Try
                    rdbSubIndividual_SelectedIndexChanged(New Object, New EventArgs)
                    txtECNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ECNO"))
                    txtECNoCD.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CD"))

                    Try
                        cmbBankAppType.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("AppTypeBank"))
                    Catch ex As Exception
                        cmbBankAppType.ClearSelection()
                    End Try
                    Try
                        cmbBranchAppType.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("AppTypeBranch"))
                    Catch ex As Exception
                        cmbBranchAppType.ClearSelection()
                    End Try
                    Try
                        cmbPDAAppType.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("PDACode"))
                    Catch ex As Exception
                        cmbPDAAppType.ClearSelection()
                    End Try
                    Try
                        txtOtherAppType.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("AppTypeOtherDesc"))
                    Catch ex As Exception
                        txtOtherAppType.Text = ""
                    End Try

                    Try
                        rdbClientType.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("CUSTOMER_TYPE_ID"))
                    Catch ex As Exception
                        rdbClientType.ClearSelection()
                    End Try
                    Try
                        rdbGender.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("GENDER"))
                    Catch ex As Exception
                        rdbGender.ClearSelection()
                    End Try
                    Try
                        rdbHouse.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("HOME_TYPE"))
                    Catch ex As Exception
                        rdbHouse.ClearSelection()
                    End Try
                    Try
                        cmbEducation.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("EDUCATION"))
                    Catch ex As Exception
                        cmbEducation.ClearSelection()
                    End Try
                    Try
                        cmbMaritalStatus.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("MARITAL_STATUS"))
                    Catch ex As Exception
                        cmbMaritalStatus.ClearSelection()
                    End Try

                    Try
                        cmbSector.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("Sector"))
                    Catch ex As Exception
                        cmbSector.ClearSelection()
                    End Try
                    If BankString.isNullString(ds.Tables(0).Rows(0).Item("DOB1")) = "01 Jan 1900" Then
                        bdpDOB.Text = ""
                    Else
                        bdpDOB.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("DOB1"))
                    End If
                    If BankString.isNullString(ds.Tables(0).Rows(0).Item("ISSUE_DATE1")) = "01 Jan 1900" Then
                        bdpIssDate.Text = ""
                    Else
                        bdpIssDate.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ISSUE_DATE1"))
                    End If
                    Try
                        cmbArea.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("AREA"))
                    Catch ex As Exception
                        cmbArea.ClearSelection()
                    End Try
                    txtGuarNameRelative.Text=BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_NAME"))
                    txtGuarRelAddress.Text=BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_ADD"))
                    txtGuarRelPhone.Text=BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_PHONE"))
                    txtGuarRelCity.Text=BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_CITY"))
                    txtGuarRelReltnship.Text=BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_RELTNSHP"))
                        lblMinDept.Visible = False
                    lblMinDeptNo.Visible = False
                  
                    txtMinDept.Visible = False
                    txtMinDeptNo.Visible = False
      '              ,[GUARANTOR_REL_NAME]
      ',[]
      ',[GUARANTOR_REL_CITY]
      ',[GUARANTOR_REL_PHONE]
      ',[GUARANTOR_REL_RELTNSHP]
                    txtEmpHowLong.Text=Convert.ToDateTime(ds.Tables(0).Rows(0).Item("DateOfEmployment")).ToString("d MMMM yyyy")
                    If rdbClientType.SelectedItem.Text = "Individual" Then
                        lblSurname.Text = "Surname"
                        lblForenames.Text = "Forenames"
                        lblForenames.Visible = True
                        txtForenames.Visible = True
                        If ViewState("PrePopulateGuarantor") Then
                            getGuarantorInfo(custID)
                        End If
                    ElseIf rdbClientType.SelectedItem.Text = "Business" Then
                        lblSurname.Text = "Name"
                        lblForenames.Visible = False
                        txtForenames.Visible = False
                        txtForenames.Text = ""
                    End If
                ElseIf ds.Tables(0).Rows(0).Item("CUSTOMER_TYPE") = "Group" Or ds.Tables(0).Rows(0).Item("CUSTOMER_TYPE") = "Corporate" Then
                    panGroup.Visible = True
                    panIndividual.Visible = False
                    pnlFarmers.Visible = False
                    txtCustNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CUSTOMER_NUMBER"))
                    txtGrpName.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SURNAME"))
                    getGrpMembers()
                    getGrpMemberExpenses()
                    loadGrpApplicantNames()
                    getGrpMemberAmts(txtCustNo.Text)
                    rdbClientType.SelectedValue = ds.Tables(0).Rows(0).Item("CUSTOMER_TYPE_ID")
                ElseIf ds.Tables(0).Rows(0).Item("CUSTOMER_TYPE") = "Farmer" Then
                    panGroup.Visible = False
                    panIndividual.Visible = False
                    pnlFarmers.Visible = True
                    txtCustNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CUSTOMER_NUMBER"))
                    txtFarmNameOfGroup.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SURNAME"))
                    loadFarmerDetails(txtCustNo.Text)
                    rdbClientType.SelectedValue = ds.Tables(0).Rows(0).Item("CUSTOMER_TYPE_ID")
                End If
                getOtherLoans()
            Else
            End If
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Protected Sub getNamesDT(ByVal dtNames As DataTable)
        Try
            If dtNames.Rows.Count > 0 Then
                If dtNames.Rows(0).Item("CUSTOMER_TYPE") = "Individual" Then
                    panGroup.Visible = False
                    panIndividual.Visible = True
                    txtCustNo.Text = BankString.isNullString(dtNames.Rows(0).Item("CUSTOMER_NUMBER"))
                    txtSurname.Text = BankString.isNullString(dtNames.Rows(0).Item("SURNAME"))
                    txtForenames.Text = BankString.isNullString(dtNames.Rows(0).Item("FORENAMES"))
                    txtAddress.Text = BankString.isNullString(dtNames.Rows(0).Item("ADDRESS"))
                    'txtCreditLimit.Text = BankString.isNullString(dtnames.Rows(0).Item("CREDIT_LIMIT"))
                    txtPhoneNo.Text = BankString.isNullString(dtNames.Rows(0).Item("PHONE_NO"))
                    txtCity.Text = BankString.isNullString(dtNames.Rows(0).Item("CITY"))
                    txtCurrEmployer.Text = BankString.isNullString(dtNames.Rows(0).Item("CURR_EMPLOYER"))
                    txtEducationOther.Text = BankString.isNullString(dtNames.Rows(0).Item("EDUCATION"))
                    txtEmpAddress.Text = BankString.isNullString(dtNames.Rows(0).Item("CURR_EMP_ADD"))
                    txtEmpCity.Text = BankString.isNullString(dtNames.Rows(0).Item("CURR_EMP_CITY"))
                    txtEmpEmail.Text = BankString.isNullString(dtNames.Rows(0).Item("CURR_EMP_EMAIL"))
                    txtEmpFax.Text = BankString.isNullString(dtNames.Rows(0).Item("CURR_EMP_FAX"))
                    'msgbox(FormatNumber(dtnames.Rows(0).Item("CURR_EMP_LENGTH"), 0))
                    'txtEmpHowLong.Text = FormatNumber(BankString.isNullNumber(Replace(dtnames.Rows(0).Item("CURR_EMP_LENGTH"), ".", ",")), 0)
                    Try
                        txtEmpHowLong.Text = FormatNumber(dtNames.Rows(0).Item("CURR_EMP_LENGTH"), 0)
                    Catch ex As Exception
                        txtEmpHowLong.Text = ""
                    End Try

                    'txtEmpOtherIncome.Text = FormatNumber(BankString.isNullNumber(Replace(dtnames.Rows(0).Item("CURR_EMP_INCOME"), ".", ",")), 2)
                    Try
                        txtEmpOtherIncome.Text = FormatNumber(dtNames.Rows(0).Item("CURR_EMP_INCOME"), 2)
                    Catch ex As Exception
                        txtEmpOtherIncome.Text = ""
                    End Try

                    txtEmpPhone.Text = BankString.isNullString(dtNames.Rows(0).Item("CURR_EMP_PHONE"))
                    txtEmpPosition.Text = BankString.isNullString(dtNames.Rows(0).Item("CURR_EMP_POSITION"))
                    Try
                        txtEmpSalary.Text = FormatNumber(dtNames.Rows(0).Item("CURR_EMP_SALARY"), 2)
                    Catch ex As Exception
                        txtEmpSalary.Text = ""
                    End Try

                    Try
                        txtEmpSalaryNet.Text = FormatNumber(dtNames.Rows(0).Item("CURR_EMP_NET"), 2)
                    Catch ex As Exception
                        txtEmpSalaryNet.Text = ""
                    End Try

                    Try
                        txtHouseHowLong.Text = FormatNumber(dtNames.Rows(0).Item("HOME_LENGTH"), 0)
                    Catch ex As Exception
                        txtHouseHowLong.Text = ""
                    End Try

                    txtIDNo.Text = BankString.isNullString(dtNames.Rows(0).Item("IDNO"))
                    txtNationality.Text = BankString.isNullString(dtNames.Rows(0).Item("NATIONALITY"))
                    txtNoChildren.Text = BankString.isNullString(dtNames.Rows(0).Item("NO_CHILDREN"))
                    txtNoDependant.Text = BankString.isNullString(dtNames.Rows(0).Item("NO_DEPENDANTS"))
                    txtPrevEmpAddress.Text = BankString.isNullString(dtNames.Rows(0).Item("PREV_EMP_ADD"))
                    Try
                        txtPrevEmpAnnualIncome.Text = FormatNumber(BankString.isNullString(dtNames.Rows(0).Item("PREV_EMP_INCOME")), 2)
                    Catch ex As Exception
                        txtPrevEmpAnnualIncome.Text = ""
                    End Try

                    txtPrevEmpCity.Text = BankString.isNullString(dtNames.Rows(0).Item("PREV_EMP_CITY"))
                    txtPrevEmpEmail.Text = BankString.isNullString(dtNames.Rows(0).Item("PREV_EMP_EMAIL"))
                    txtPrevEmpFax.Text = BankString.isNullString(dtNames.Rows(0).Item("PREV_EMP_FAX"))
                    Try
                        txtPrevEmpHowLong.Text = FormatNumber(BankString.isNullString(dtNames.Rows(0).Item("PREV_EMP_LENGTH")), 0)
                    Catch ex As Exception
                        txtPrevEmpHowLong.Text = ""
                    End Try

                    txtPrevEmployer.Text = BankString.isNullString(dtNames.Rows(0).Item("PREV_EMPLOYER"))
                    txtPrevEmpPhone.Text = BankString.isNullString(dtNames.Rows(0).Item("PREV_EMP_PHONE"))
                    txtPrevEmpPosition.Text = BankString.isNullString(dtNames.Rows(0).Item("PREV_EMP_POSITION"))
                    Try
                        txtPrevEmpSalary.Text = FormatNumber(BankString.isNullString(dtNames.Rows(0).Item("PREV_EMP_SALARY")), 2)
                    Catch ex As Exception
                        txtPrevEmpSalary.Text = ""
                    End Try

                    Try
                        txtPrevEmpSalaryNet.Text = FormatNumber(BankString.isNullString(dtNames.Rows(0).Item("PREV_EMP_NET")), 2)
                    Catch ex As Exception
                        txtPrevEmpSalaryNet.Text = ""
                    End Try

                    'msgbox("clear")
                    Try
                        txtRent.Text = FormatNumber(BankString.isNullString(dtNames.Rows(0).Item("MONTHLY_RENT")), 2)
                    Catch ex As Exception
                        txtRent.Text = ""
                    End Try
                    txtSpouse.Text = BankString.isNullString(dtNames.Rows(0).Item("SPOUSE_NAME"))
                    txtSpouseEmployer.Text = BankString.isNullString(dtNames.Rows(0).Item("SPOUSE_EMPLOYER"))
                    txtSpouseOccupation.Text = BankString.isNullString(dtNames.Rows(0).Item("SPOUSE_OCCUPATION"))
                    txtSpousePhone.Text = BankString.isNullString(dtNames.Rows(0).Item("SPOUSE_PHONE"))
                    txtTradeRef1.Text = BankString.isNullString(dtNames.Rows(0).Item("TRADE_REF1"))
                    txtTradeRef2.Text = BankString.isNullString(dtNames.Rows(0).Item("TRADE_REF2"))
                    Try
                        rdbSubIndividual.SelectedValue = dtNames.Rows(0).Item("SUB_INDIVIDUAL")
                    Catch ex As Exception
                        rdbSubIndividual.ClearSelection()
                    End Try
                    rdbSubIndividual_SelectedIndexChanged(New Object, New EventArgs)
                    txtECNo.Text = BankString.isNullString(dtNames.Rows(0).Item("ECNO"))
                    txtECNoCD.Text = BankString.isNullString(dtNames.Rows(0).Item("CD"))

                    Try
                        cmbBankAppType.SelectedValue = BankString.isNullString(dtNames.Rows(0).Item("AppTypeBank"))
                    Catch ex As Exception
                        cmbBankAppType.ClearSelection()
                    End Try
                    Try
                        cmbBranchAppType.SelectedValue = BankString.isNullString(dtNames.Rows(0).Item("AppTypeBranch"))
                    Catch ex As Exception
                        cmbBranchAppType.ClearSelection()
                    End Try
                    Try
                        cmbPDAAppType.SelectedValue = BankString.isNullString(dtNames.Rows(0).Item("PDACode"))
                    Catch ex As Exception
                        cmbPDAAppType.ClearSelection()
                    End Try
                    Try
                        txtOtherAppType.Text = BankString.isNullString(dtNames.Rows(0).Item("AppTypeOtherDesc"))
                    Catch ex As Exception
                        txtOtherAppType.Text = ""
                    End Try

                    Try
                        rdbClientType.SelectedValue = BankString.isNullString(dtNames.Rows(0).Item("CUSTOMER_TYPE_ID"))
                    Catch ex As Exception
                        rdbClientType.ClearSelection()
                    End Try
                    Try
                        rdbGender.SelectedValue = BankString.isNullString(dtNames.Rows(0).Item("GENDER"))
                    Catch ex As Exception
                        rdbGender.ClearSelection()
                    End Try
                    Try
                        rdbHouse.SelectedValue = BankString.isNullString(dtNames.Rows(0).Item("HOME_TYPE"))
                    Catch ex As Exception
                        rdbHouse.ClearSelection()
                    End Try
                    Try
                        cmbEducation.SelectedValue = BankString.isNullString(dtNames.Rows(0).Item("EDUCATION"))
                    Catch ex As Exception
                        cmbEducation.ClearSelection()
                    End Try
                    Try
                        cmbMaritalStatus.SelectedValue = BankString.isNullString(dtNames.Rows(0).Item("MARITAL_STATUS"))
                    Catch ex As Exception
                        cmbMaritalStatus.ClearSelection()
                    End Try
                    Try
                        cmbSector.SelectedValue = BankString.isNullString(dtNames.Rows(0).Item("Sector"))
                    Catch ex As Exception
                        cmbSector.ClearSelection()
                    End Try
                    If BankString.isNullString(dtNames.Rows(0).Item("DOB1")) = "01 Jan 1900" Then
                        bdpDOB.Text = ""
                    Else
                        bdpDOB.Text = BankString.isNullString(dtNames.Rows(0).Item("DOB1"))
                    End If
                    If BankString.isNullString(dtNames.Rows(0).Item("ISSUE_DATE1")) = "01 Jan 1900" Then
                        bdpIssDate.Text = ""
                    Else
                        bdpIssDate.Text = BankString.isNullString(dtNames.Rows(0).Item("ISSUE_DATE1"))
                    End If
                    Try
                        cmbArea.SelectedValue = BankString.isNullString(dtNames.Rows(0).Item("AREA"))
                    Catch ex As Exception
                        cmbArea.ClearSelection()
                    End Try

                    If rdbClientType.SelectedItem.Text = "Individual" Then
                        lblSurname.Text = "Surname"
                        lblForenames.Text = "Forenames"
                        lblForenames.Visible = True
                        txtForenames.Visible = True
                        If ViewState("PrePopulateGuarantor") Then
                            getGuarantorInfo(txtCustNo.Text)
                        End If
                    ElseIf rdbClientType.SelectedItem.Text = "Business" Then
                        lblSurname.Text = "Name"
                        lblForenames.Visible = False
                        txtForenames.Visible = False
                        txtForenames.Text = ""
                    End If
                    '  lblSurname.Text = "FAFIDO"
                ElseIf dtNames.Rows(0).Item("CUSTOMER_TYPE") = "Group" Or dtNames.Rows(0).Item("CUSTOMER_TYPE") = "Corporate" Then
                    panGroup.Visible = True
                    panIndividual.Visible = False
                    txtCustNo.Text = BankString.isNullString(dtNames.Rows(0).Item("CUSTOMER_NUMBER"))
                    txtGrpName.Text = BankString.isNullString(dtNames.Rows(0).Item("SURNAME"))
                    getGrpMembers()
                    getGrpMemberExpenses()
                    loadGrpApplicantNames()
                    rdbClientType.SelectedValue = dtNames.Rows(0).Item("CUSTOMER_TYPE_ID")
                End If
                getOtherLoans()
            Else
            End If
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Protected Sub getNamesGroup(ByVal custID As String)
        Try
            cmd = New SqlCommand("select *,convert(varchar,DOB,106) as DOB1,convert(varchar,ISSUE_DATE,106) as ISSUE_DATE1 from CUSTOMER_DETAILS where CUSTOMER_NUMBER='" & custID & "'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "CUSTOMER")
            If ds.Tables(0).Rows.Count > 0 Then
                txtCustNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CUSTOMER_NUMBER"))
                txtSurname.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SURNAME"))
                txtForenames.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FORENAMES"))
                txtAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ADDRESS"))
                txtPhoneNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PHONE_NO"))
                txtCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CITY"))
                txtCurrEmployer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMPLOYER"))
                txtEducationOther.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("EDUCATION"))
                txtEmpAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_ADD"))
                txtEmpCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_CITY"))
                txtEmpEmail.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_EMAIL"))
                txtEmpFax.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_FAX"))
                txtEmpHowLong.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_LENGTH"))
                txtEmpOtherIncome.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_INCOME"))
                txtEmpPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_PHONE"))
                txtEmpPosition.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_POSITION"))
                txtEmpSalary.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_SALARY"))
                txtHouseHowLong.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("HOME_LENGTH"))
                txtIDNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("IDNO"))
                txtNationality.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("NATIONALITY"))
                txtNoChildren.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("NO_CHILDREN"))
                txtNoDependant.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("NO_DEPENDANTS"))
                txtPrevEmpAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_ADD"))
                txtPrevEmpAnnualIncome.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_INCOME"))
                txtPrevEmpCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_CITY"))
                txtPrevEmpEmail.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_EMAIL"))
                txtPrevEmpFax.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_FAX"))
                txtPrevEmpHowLong.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_LENGTH"))
                txtPrevEmployer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMPLOYER"))
                txtPrevEmpPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_PHONE"))
                txtPrevEmpPosition.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_POSITION"))
                txtPrevEmpSalary.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_SALARY"))
                txtRent.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("MONTHLY_RENT"))
                txtSpouse.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_NAME"))
                txtSpouseEmployer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_EMPLOYER"))
                txtSpouseOccupation.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_OCCUPATION"))
                txtSpousePhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_PHONE"))
                txtTradeRef1.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("TRADE_REF1"))
                txtTradeRef2.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("TRADE_REF2"))

                rdbClientType.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("CUSTOMER_TYPE_ID"))
                rdbGender.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("GENDER"))
                rdbHouse.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("HOME_TYPE"))
                cmbEducation.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("EDUCATION"))
                cmbMaritalStatus.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("MARITAL_STATUS"))

                bdpDOB.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("DOB1"))
                bdpIssDate.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ISSUE_DATE1"))
                If rdbClientType.SelectedItem.Text = "Individual" Then
                    lblSurname.Text = "Surname"
                    lblForenames.Text = "Forenames"
                    lblForenames.Visible = True
                    txtForenames.Visible = True
                ElseIf rdbClientType.SelectedItem.Text = "Business" Then
                    lblSurname.Text = "Name"
                    lblForenames.Visible = False
                    txtForenames.Visible = False
                    txtForenames.Text = ""
                End If
            Else
            End If
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Protected Sub getNextApproval(currLevel As Integer)
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("select * from [ParaApprovalStages] where [StageOrder]='" & currLevel & "'", con)
                    Dim ds As New DataSet
                    Dim adp = New SqlDataAdapter(cmd)
                    adp.Fill(ds, "PAS")
                    If ds.Tables(0).Rows.Count > 0 Then
                        Dim dr = ds.Tables(0).Rows(0)
                        ViewState("StageName") = dr("StageName")
                    End If
                End Using
                Using cmd = New SqlCommand("select * from [ParaApprovalStages] where [StageOrder]='" & currLevel + 1 & "'", con)
                    Dim ds As New DataSet
                    Dim adp = New SqlDataAdapter(cmd)
                    adp.Fill(ds, "PAS")
                    If ds.Tables(0).Rows.Count > 0 Then
                        Dim dr = ds.Tables(0).Rows(0)
                        ViewState("NextRole") = dr("RoleId")
                        ViewState("NextStageName") = dr("StageName")
                        If dr("StageAction") = "Disbursement" Then
                            ViewState("ReadyToDisburse") = "1"
                        Else
                            ViewState("ReadyToDisburse") = "0"
                        End If
                    Else
                        ViewState("NextRole") = "0"
                        ViewState("ReadyToDisburse") = "0"
                        ViewState("NextStageName") = ""
                    End If
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- getNextApproval()", ex.Message)
        End Try
    End Sub

    Protected Sub getOtherLoans()
        Try
            cmd = New SqlCommand("select ID,OTHER_DESC,OTHER_ACCNO,cast(OTHER_AMT as numeric(20,2)) as OTHER_AMT from QUEST_OTHER_LOANS where CUSTOMER_NUMBER='" & txtCustNo.Text & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "Other")
            If ds.Tables(0).Rows.Count > 0 Then
                grdOtherLoan.DataSource = ds.Tables(0)
            Else
                grdOtherLoan.DataSource = Nothing
            End If
            grdOtherLoan.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Function getOutstandingLoans(custNo As String) As Integer
        Using cmd = New SqlCommand("select ISNULL(count(ID), 0) as numLoan from QUEST_APPLICATION where (STATUS<>'REPAID') and (STATUS<>'REJECTED') and CUSTOMER_NUMBER='" & custNo & "' and DISBURSED=1", con)
            Dim outs As Integer = 0
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            outs = cmd.ExecuteScalar
            con.Close()
            Return outs
        End Using
    End Function

    Protected Sub getPDACompanies()
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("select * from para_pda", con)
                    Dim ds As New DataSet
                    Dim adp = New SqlDataAdapter(cmd)
                    adp.Fill(ds, "PDA")
                    loadCombo(ds.Tables(0), cmbPDAAppType, "PDAName", "PDACode")
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- getPDACompanies()", ex.Message)
        End Try
    End Sub

    Protected Sub getProductDefaults(productID As String)
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("select * from [CreditProducts] where id='" & productID & "'", con)
                    Dim ds As New DataSet
                    Using adp = New SqlDataAdapter(cmd)
                        adp.Fill(ds, "PDA")
                    End Using
                    If ds.Tables(0).Rows.Count > 0 Then
                        Dim dr = ds.Tables(0).Rows(0)
                        'rvFinReqAmt.MinimumValue = FormatNumber(dr("MinAmt"), 0).ToString.Replace(",", "")
                        'rvFinReqAmt.MaximumValue = FormatNumber(dr("MaxAmt"), 0).ToString.Replace(",", "")
                        'rvFinReqIntRate.MinimumValue = FormatNumber(dr("MinIntRate"), 2).ToString.Replace(",", "")
                        'rvFinReqIntRate.MaximumValue = FormatNumber(dr("MaxIntRate"), 2).ToString.Replace(",", "")
                        Try
                            txtFinReqIntRate.Text = dr("DefaultIntRate")
                        Catch ex As Exception
                            txtFinReqIntRate.Text = ""
                        End Try
                        Try
                            If dr("ProductFees") = "None" Then
                                lblAdminRate.Visible = False
                                txtAdminRate.Text = "0"
                                txtAdminRate.Visible = False
                            Else
                                lblAdminRate.Visible = True
                                txtAdminRate.Visible = True
                                Try
                                    lblAdminRate.Text = IIf(dr("ProductFeeCalc") = "Percentage", "Application Fees (%)", "Application Fees ($)")
                                Catch ex As Exception

                                End Try
                                Try
                                    txtAdminRate.Text = dr("ProductFeeAmtPerc")
                                Catch ex As Exception
                                    txtAdminRate.Text = ""
                                End Try
                            End If
                        Catch ex As Exception

                        End Try
                        Try
                            If dr("DefaultIntInterval") = "Daily" Then
                                lblInterestRate.Text = "Interest Rate (% per day)"
                            ElseIf dr("DefaultIntInterval") = "Weekly" Then
                                lblInterestRate.Text = "Interest Rate (% per week)"
                            ElseIf dr("DefaultIntInterval") = "Monthly" Then
                                lblInterestRate.Text = "Interest Rate (% per month)"
                            ElseIf dr("DefaultIntInterval") = "Annual" Then
                                lblInterestRate.Text = "Interest Rate (% per annum)"
                            ElseIf dr("DefaultIntInterval") = "Duration" Then
                                lblInterestRate.Text = "Interest Rate (%)"
                            Else
                                lblInterestRate.Text = "Interest Rate (%)"
                            End If
                        Catch ex As Exception

                        End Try
                        Try
                            txtRepaymentInterval.Text = dr("RepaymentIntervalNum")
                        Catch ex As Exception
                            txtRepaymentInterval.Text = ""
                        End Try

                        Try
                            cmbRepaymentInterval.SelectedValue = dr("RepaymentIntervalUnit")
                        Catch ex As Exception
                            cmbRepaymentInterval.ClearSelection()
                        End Try
                        Try
                            txtFinReqTenor.Text = FormatNumber(dr("DefaultTenure"), 0)
                        Catch ex As Exception
                            txtFinReqTenor.Text = ""
                        End Try
                    End If
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- getProductDefaults()", ex.ToString)
        End Try
    End Sub

    Protected Sub grdDocuments_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles grdDocuments.RowCommand
        If e.CommandName = "Select" Then
            Dim docID = e.CommandArgument
            'lblDetailID.Text = docID
            'btnModalPopup.Visible = True
            Dim strscript As String

            strscript = "<script language=JavaScript>"
            strscript += "window.open('viewDocument.aspx?id=" & docID & "');"
            strscript += "</script>"
            'ClientScript.RegisterStartupScript(Me.GetType(), "HideLabel", "<script type=""text/javascript"">setTimeout(""document.getElementById('" & lblAppUploadMsg.ClientID & "').style.display='none'"",5000)</script>")
            ClientScript.RegisterStartupScript(Me.GetType(), "newwin", strscript)

        End If
    End Sub

    Protected Sub grdDocuments_RowDeleting(sender As Object, e As GridViewDeleteEventArgs) Handles grdDocuments.RowDeleting
        Dim docUploadEditID = DirectCast(grdDocuments.Rows(e.RowIndex).FindControl("txtDocId"), TextBox).Text
        cmd = New SqlCommand("delete from QUEST_DOCUMENTS where ID='" & docUploadEditID & "'", con)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        If cmd.ExecuteNonQuery Then
            'lblAppUploadMsg.ForeColor = Drawing.Color.Green
            'lblAppUploadMsg.Text = "Document successfully deleted"
            notify("File has been deleted", "success")
        Else
            'lblAppUploadMsg.ForeColor = Drawing.Color.Red
            'lblAppUploadMsg.Text = "Error deleting document"
            notify("Error deleting file", "error")
        End If
        con.Close()
        loadUploadedFiles(txtCustNo.Text)
        ClientScript.RegisterStartupScript(Me.GetType(), "HideLabel", "<script type=""text/javascript"">setTimeout(""document.getElementById('" & lblAppUploadMsg.ClientID & "').style.display='none'"",5000)</script>")
    End Sub

    'Protected Sub cmbGrpApplicantName_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbGrpApplicantName.SelectedIndexChanged
    '    getGrpMemberDetails(cmbGrpApplicantName.SelectedValue)
    'End Sub


    Protected Sub grdOtherLoan_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles grdOtherLoan.RowCancelingEdit
        grdOtherLoan.EditIndex = -1
        getOtherLoans()
    End Sub

    Protected Sub grdOtherLoan_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grdOtherLoan.RowDeleting
        ViewState("otherEditID") = DirectCast(grdOtherLoan.Rows(e.RowIndex).FindControl("txtOtherId"), TextBox).Text
        cmd = New SqlCommand("delete from QUEST_OTHER_LOANS where ID='" & ViewState("otherEditID") & "'", con)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        If cmd.ExecuteNonQuery Then
            notify("Loan successfully deleted", "success")
        Else
            notify("Error deleting loan", "error")
        End If
        con.Close()
        getOtherLoans()
    End Sub

    Protected Sub grdOtherLoan_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles grdOtherLoan.RowEditing
        ViewState("otherEditID") = DirectCast(grdOtherLoan.Rows(e.NewEditIndex).FindControl("txtOtherId"), TextBox).Text
        grdOtherLoan.EditIndex = e.NewEditIndex
        getOtherLoans()
    End Sub

    Protected Sub grdOtherLoan_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles grdOtherLoan.RowUpdating
        If Trim(ViewState("otherEditID")) = "" Or IsDBNull(ViewState("otherEditID")) Then
            notify("No loan selected for update", "error")
            Exit Sub
        End If
        Dim othDesc As String = DirectCast(grdOtherLoan.Rows(e.RowIndex).FindControl("txtDescEdit"), TextBox).Text
        Dim othAccNo As String = DirectCast(grdOtherLoan.Rows(e.RowIndex).FindControl("txtAccNoEdit"), TextBox).Text
        Dim othAmt As String = DirectCast(grdOtherLoan.Rows(e.RowIndex).FindControl("txtAmtEdit"), TextBox).Text
        cmd = New SqlCommand("update QUEST_OTHER_LOANS set OTHER_DESC='" & BankString.removeSpecialCharacter(othDesc) & "',OTHER_ACCNO='" & othAccNo & "',OTHER_AMT='" & othAmt & "' where ID='" & ViewState("otherEditID") & "'", con)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        If cmd.ExecuteNonQuery Then
            notify("Loan successfully updated", "success")
        Else
            notify("Error updating loan", "error")
        End If
        con.Close()
        grdOtherLoan.EditIndex = -1
        getOtherLoans()
    End Sub

    Protected Function internalControlsSaved() As Boolean
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("select * from ParaInternalControls", con)
                    Dim ds As New DataSet
                    Dim adp = New SqlDataAdapter(cmd)
                    adp.Fill(ds, "PAS")
                    If ds.Tables(0).Rows.Count > 0 Then
                        Dim dr = ds.Tables(0).Rows(0)
                        ViewState("MaxExposure") = dr("MaxExposure")
                        ViewState("MaxNoLoans") = dr("MaxNoLoans")
                        ViewState("PrePopulateGuarantor") = dr("PrePopulateGuarantor")
                        Return True
                    Else
                        notify("You must first save Internal Controls before proceeding", "error")
                        Return False
                    End If
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- internalControlsSaved()", ex.ToString)
            notify("You must first save Internal Controls before proceeding", "error")
            Return False
        End Try
    End Function

    Protected Function isValidCustID(custID As String) As Boolean
        Try
            cmd = New SqlCommand("select ID from CUSTOMER_DETAILS where CUSTOMER_NUMBER='" & custID & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "CD")
            If ds.Tables(0).Rows.Count > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Protected Sub loadBank(cmbBank As DropDownList)
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd As New SqlCommand("select distinct bank, bank_name from para_bank order by bank", con)
                    Dim dss As New DataSet
                    Dim adp = New SqlDataAdapter(cmd)
                    adp.Fill(dss, "para_bank")
                    loadCombo(dss.Tables(0), cmbBank, "bank_name", "bank")
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- loadBank()", ex.Message)
        End Try
    End Sub

    Protected Sub loadBranch(cmbBranch As DropDownList, cmbBank As DropDownList)
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("SELECT bank, branch, branch_name FROM para_branch where bank='" & cmbBank.SelectedValue & "'", con)
                    Dim ds As New DataSet
                    Dim adp = New SqlDataAdapter(cmd)
                    adp.Fill(ds, "para_branch")
                    loadCombo(ds.Tables(0), cmbBranch, "branch_name", "branch")
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- loadBranch()", ex.Message)
        End Try
    End Sub

    Protected Sub loadClientTypes()
        Try
            Using cmd = New SqlCommand("select * from PARA_CLIENT_TYPES", con)
                Dim ds As New DataSet
                adp = New SqlDataAdapter(cmd)
                adp.Fill(ds, "Clients")
                loadCombo(ds.Tables(0), rdbClientType, "CLIENT_TYPE", "ID")
            End Using
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Protected Sub loadCollateralTypes()
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd As New SqlCommand("select * from CollateralTypes", con)
                    Dim dt As New DataTable
                    Using adp = New SqlDataAdapter(cmd)
                        adp.Fill(dt)
                    End Using
                    loadCombo(dt, cmbCollateralType, "CollateralName", "id")
                End Using
            End Using
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub loadGrpApplicantNames()
        'Try
        '    cmbGrpApplicantName.Items.Clear()
        '    cmbGrpApplicantName.Items.Add("")
        '    cmd = New SqlCommand("select * from QUEST_GROUP_MEMBERS where CUSTOMER_NUMBER='" & txtCustNo.Text & "'", con)
        '    Dim ds As New DataSet
        '    adp = New SqlDataAdapter(cmd)
        '    adp.Fill(ds, "QGM")
        '    If ds.Tables(0).Rows.Count > 0 Then
        '        cmbGrpApplicantName.DataSource = ds.Tables(0)
        '        cmbGrpApplicantName.DataTextField = "NAME"
        '        cmbGrpApplicantName.DataValueField = "ID"
        '    Else
        '        cmbGrpApplicantName.DataSource = Nothing
        '    End If
        '    cmbGrpApplicantName.DataBind()
        'Catch ex As Exception

        'End Try
    End Sub

    Protected Sub loadOtherLoans()
        Try
            cmd = New SqlCommand("select [OTHER_DESC] as [DESCRIPTION],[OTHER_ACCNO] as [ACCOUNT NUMBER],CONVERT(DECIMAL(30,2),[OTHER_AMT]) as [AMOUNT] from QUEST_OTHER_LOANS where CUSTOMER_NUMBER='" & txtCustNo.Text & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "Other")
            If ds.Tables(0).Rows.Count > 0 Then
                grdOtherLoan.DataSource = ds.Tables(0)
            Else
                grdOtherLoan.DataSource = Nothing
            End If
            grdOtherLoan.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub loadPurpose(ByVal cmbPurpose As DropDownList)
        Try
            cmd = New SqlCommand("select * from PARA_PURPOSE", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "purpose")
            CreditManager.loadCombo(ds.Tables(0), cmbPurpose, "PURPOSE", "PURPOSE")
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub loadUploadedFiles(custNo As String)
        Try
            cmd = New SqlCommand("select * from QUEST_DOCUMENTS where CUST_NO='" & custNo & "' and (LOAN_ID='' or LOAN_ID is NULL)", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "QD")
            If ds.Tables(0).Rows.Count > 0 Then
                grdDocuments.DataSource = ds.Tables(0)
            Else
                grdDocuments.DataSource = Nothing
            End If
            grdDocuments.DataBind()
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Protected Sub loadUploadedFilesRej(loanID As String)
        Try
            cmd = New SqlCommand("select * from QUEST_DOCUMENTS where LOAN_ID='" & loanID & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "QD")
            If ds.Tables(0).Rows.Count > 0 Then
                grdDocuments.DataSource = ds.Tables(0)
            Else
                grdDocuments.DataSource = Nothing
            End If
            grdDocuments.DataBind()
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub

    Protected Sub lstSurname_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstSurname.SelectedIndexChanged
        Try
            Dim custID = lstSurname.SelectedValue
            txtCustNo.Text = custID
            btnSearchCustNo_Click(sender, New EventArgs)
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Page.MaintainScrollPositionOnPostBack = True
            Page.ClientScript.RegisterOnSubmitStatement(Me.GetType, "val", "fnOnUpdateValidators();")
            con = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            If Not IsPostBack Then
                mltGrpApp.ActiveViewIndex = 0
                loadClientTypes()
                loadBank(cmbFinReqBank)
                loadBank(cmbBankAppType)
                writeBranch()
                loadPurpose(cmbFinReqPurpose)
                getPDACompanies()
                loadProductType(cmbProductType)
                loadSectors(cmbSector)
                loadCollateralTypes()
                If Not processFlowSaved() Then
                ElseIf Not internalControlsSaved() Then

                End If
                If Request.QueryString("rej") = 1 Then
                    ViewState("globLoanID") = Request.QueryString("id")
                    loadClientTypes()
                    getAppHistory()
                    getAppDetails(ViewState("globLoanID"))
                    writeSubmitButton(Session("ROLE"))
                    btnTerminate.Visible = True
                    lnkViewAppForm.NavigateUrl = "Amortization.aspx?ID=" & ViewState("globLoanID") & "&App=1"
                    lnkViewAppForm.Visible = True
                    lnkAppRating.NavigateUrl = "ApplicationRating.aspx?loanID=" & ViewState("globLoanID")
                    lnkAppRating.Visible = True
                    If amortizationAlreadyCreated(ViewState("globLoanID")) Then
                        lnkAmortizationSchedule.NavigateUrl = "rptAmortizationSchedule.aspx?loanID=" & ViewState("globLoanID")
                        lnkAmortizationSchedule.Visible = True
                    End If
                    loadUploadedFilesRej(ViewState("globLoanID"))
                End If
            End If
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- Page_Load()", ex.ToString)
        End Try
    End Sub
    Protected Function processFlowSaved() As Boolean
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("select * from ParaApprovalStages", con)
                    Dim ds As New DataSet
                    Dim adp = New SqlDataAdapter(cmd)
                    adp.Fill(ds, "PAS")
                    If ds.Tables(0).Rows.Count > 1 Then
                        Return True
                    Else
                        Return False
                    End If
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- processFlowSaved()", ex.ToString)
            Return False
        End Try
    End Function
    Protected Sub rdbClientType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbClientType.SelectedIndexChanged
        clientTypeVisible()
    End Sub

    Protected Sub rdbQuesHow_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbQuesHow.SelectedIndexChanged
        Try
            If rdbQuesHow.SelectedValue = "Employee" Then
                lblQuesEmployee.Text = "Our Employee"
            ElseIf rdbQuesHow.SelectedValue = "Agent" Then
                lblQuesEmployee.Text = "Agent Name"
            ElseIf rdbQuesHow.SelectedValue = "Friend" Then
                lblQuesEmployee.Text = "Friend Name"
            ElseIf rdbQuesHow.SelectedValue = "Media" Then
                lblQuesEmployee.Text = "Name"
            ElseIf rdbQuesHow.SelectedValue = "Others" Then
                lblQuesEmployee.Text = "Name"
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub rdbSubIndividual_SelectedIndexChanged(sender As Object, e As EventArgs) Handles rdbSubIndividual.SelectedIndexChanged
        applicantTypeSelector(rdbSubIndividual.SelectedValue)
    End Sub

    'Protected Sub rdbType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles rdbType.SelectedIndexChanged
    '    If rdbType.SelectedValue = "Cash" Then
    '        lblAsset.Visible = False
    '        ddlAssets.Visible = False
    '    ElseIf rdbType.SelectedValue = "Asset Financing" Then
    '        lblAsset.Visible = True
    '        ddlAssets.Visible = True
    '        fillType()
    '    End If
    'End Sub

    Protected Sub saveComment()
        Try
            'If Not (Trim(txtComment.Text) = "" Or Trim(txtRecAmt.Text) = "") Then
            cmd = New SqlCommand("insert into REQUEST_HISTORY (LOANID,COMMENT_DATE,USERID,COMMENT,RECOMMENDED_AMT) values('" & Request.QueryString("id") & "',GETDATE(),'" & Session("UserID") & "','" & BankString.removeSpecialCharacter(txtComment.Text) & "','" & txtRecAmt.Text & "')", con)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            'End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub saveGrpMemberAmts(cust As String, loanID As String)
        For Each member As RepeaterItem In repGrpMembers.Items
            Dim memberID As String = CType(member.FindControl("lblGrpMemberID"), Label).Text
            Dim memberName As String = CType(member.FindControl("lblGrpMemberName"), Label).Text
            Dim amt As String = CType(member.FindControl("txtGrpMemberAmt"), TextBox).Text
            Dim cmd1 As New SqlCommand("insert into [QUEST_GROUP_APPLICATION] ([CUST_NO],[LOAN_ID],[MEMBER_ID],[MEMBER_NAME],[AMOUNT]) values ('" & cust & "','" & loanID & "','" & memberID & "','" & memberName & "','" & amt & "')", con)
            If con.State <> ConnectionState.Closed Then
                con.Close()
            End If
            con.Open()
            cmd1.ExecuteNonQuery()
            con.Close()
        Next
    End Sub

    Protected Sub saveInitiatorComment()
        Try
            'If Not (Trim(txtComment.Text) = "" Or Trim(txtRecAmt.Text) = "") Then
            cmd = New SqlCommand("insert into REQUEST_HISTORY (LOANID,COMMENT_DATE,USERID,COMMENT,RECOMMENDED_AMT) values('" & ViewState("globLoanID") & "',GETDATE(),'" & Session("UserID") & "','" & BankString.removeSpecialCharacter(txtComment.Text) & "','" & txtFinReqAmt.Text.Replace(",", "") & "')", con)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            'End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub saveInitiatorCommentGrp()
        Try
            ViewState("globLoanID") = getLastLoanID()
            'If Not (Trim(txtComment.Text) = "" Or Trim(txtRecAmt.Text) = "") Then
            cmd = New SqlCommand("insert into REQUEST_HISTORY (LOANID,COMMENT_DATE,USERID,COMMENT,RECOMMENDED_AMT) values('" & ViewState("globLoanID") & "',GETDATE(),'" & Session("UserID") & "','','" & txtGrpApplLoanAmt.Text & "')", con)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            'End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub SSBInvisible()
        Try
            lblMinDept.Visible = False
            lblMinDeptNo.Visible = False
            txtMinDept.Visible = False
            txtMinDeptNo.Visible = False
            lblEmpCode.Visible = False
            txtECNo.Visible = False
            txtECNoCD.Visible = False
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub SSBVisible()
        Try
            lblMinDept.Visible = True
            lblMinDeptNo.Visible = True
            txtMinDept.Visible = True
            txtMinDeptNo.Visible = True
            lblEmpCode.Visible = True
            txtECNo.Visible = True
            txtECNoCD.Visible = True
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub submitApplication()
        Try
            'msgbox(cmbPDAAppType.SelectedValue)
            'If rdbType.SelectedIndex = -1 Then
            '    CreditManager.notify("Select financing type", "error")
            'Else
            'msgbox("Interest rate: " & CDbl(txtFinReqIntRate.Text) & " Maximum: " & CDbl(ViewState("MaxIntRate")) & " Minimum: " & CDbl(ViewState("MinIntRate")))
            If CDbl(txtFinReqIntRate.Text) > CDbl(ViewState("MaxIntRate")) Then
                notify("Interest rate greater than the maximum allowed for this product", "error")
                Exit Sub
            ElseIf CDbl(txtFinReqIntRate.Text) < CDbl(ViewState("MinIntRate")) Then
                notify("Interest rate less than minimum allowed for this product", "error")
                Exit Sub
            ElseIf Val(txtFinReqAmt.Text) > Val(ViewState("MaxAmt")) Or Val(txtFinReqAmt.Text) < Val(ViewState("MinAmt")) Then
                notify("Required amount out of the range for this product", "error")
                Exit Sub
            ElseIf CDbl(txtFinReqTenor.Text) > CDbl(ViewState("MaximumTenure")) Or CDbl(txtFinReqTenor.Text) < CDbl(ViewState("MinimumTenure")) Then
                notify("Loan tenure out of the range for this product", "error")
                Exit Sub
            ElseIf bdpFinReqRepaymt.Text = "" Then
                notify("Please Enter 1st Repayment Date", "error")
                Exit Sub
            End If
            Dim reqType = ""
            If cmbProductType.SelectedValue = "Asset Financing" Then
                reqType = ddlAssets.SelectedItem.Text
            End If
            getNextApproval(1)
            If btnSubmit.Text = "Update Application" Then ''" & txtBankName.Text & "','" & txtBranchName.Text & "','" & txtBankAccountNo.Text & "','" & txtBranchCode.Text & "'
                cmd = New SqlCommand("update QUEST_APPLICATION set ExportedFileTimes='" & txtFinReqTenor.Text & "',Bank='" & txtBankName.Text & "', BankBranch='" & txtBranchName.Text & "', BankAccountNo='" & txtBankAccountNo.Text & "', BranchCode='" & txtBranchCode.Text & "',[ReadyToDisburse]='" & ViewState("ReadyToDisburse") & "',[ApprovalNumber]=1,[Sector]='" & BankString.removeSpecialCharacter(cmbSector.SelectedValue) & "',[FinProductType]='" & BankString.removeSpecialCharacter(cmbProductType.SelectedValue) & "',[ASSET_NAME]='" & reqType.Replace("'", "''") & "',[CUSTOMER_TYPE]='" & rdbClientType.SelectedItem.Text & "',[SUB_INDIVIDUAL]='" & rdbSubIndividual.SelectedValue & "',[CUSTOMER_NUMBER]='" & txtCustNo.Text & "',[SURNAME]='" & BankString.removeSpecialCharacter(txtSurname.Text) & "',[FORENAMES]='" & BankString.removeSpecialCharacter(txtForenames.Text) & "',[DOB]='" & bdpDOB.Text & "',[IDNO]='" & txtIDNo.Text & "',[ISSUE_DATE]='" & bdpIssDate.Text & "',[ADDRESS]='" & BankString.removeSpecialCharacter(txtAddress.Text) & "',[CITY]='" & BankString.removeSpecialCharacter(txtCity.Text) & "',[PHONE_NO]='" & txtPhoneNo.Text & "',[NATIONALITY]='" & BankString.removeSpecialCharacter(txtNationality.Text) & "',[GENDER]='" & rdbGender.SelectedValue & "',[HOME_TYPE]='" & rdbHouse.SelectedValue & "',[MONTHLY_RENT]='" & txtRent.Text & "',[HOME_LENGTH]='" & txtHouseHowLong.Text & "',[MARITAL_STATUS]='" & cmbMaritalStatus.SelectedValue & "',[EDUCATION]='" & getEducation() & "',[CURR_EMPLOYER]='" & BankString.removeSpecialCharacter(txtCurrEmployer.Text) & "',[CURR_EMP_ADD]='" & BankString.removeSpecialCharacter(txtEmpAddress.Text) & "',[CURR_EMP_LENGTH]='" & txtEmpHowLong.Text & "',[CURR_EMP_PHONE]='" & txtEmpPhone.Text & "',[CURR_EMP_EMAIL]='" & txtEmpEmail.Text & "',[CURR_EMP_FAX]='" & txtEmpFax.Text & "',[CURR_EMP_CITY]='" & BankString.removeSpecialCharacter(txtEmpCity.Text) & "',[CURR_EMP_POSITION]='" & BankString.removeSpecialCharacter(txtEmpPosition.Text) & "',[CURR_EMP_SALARY]='" & txtEmpSalary.Text & "',[CURR_EMP_NET]='" & txtEmpSalaryNet.Text & "',[CURR_EMP_INCOME]='" & txtEmpOtherIncome.Text & "',[PREV_EMPLOYER]='" & BankString.removeSpecialCharacter(txtPrevEmployer.Text) & "',[PREV_EMP_ADD]='" & BankString.removeSpecialCharacter(txtPrevEmpAddress.Text) & "',[PREV_EMP_LENGTH]='" & txtPrevEmpHowLong.Text & "',[PREV_EMP_PHONE]='" & txtPrevEmpPhone.Text & "',[PREV_EMP_EMAIL]='" & txtPrevEmpEmail.Text & "',[PREV_EMP_FAX]='" & txtPrevEmpFax.Text & "',[PREV_EMP_CITY]='" & BankString.removeSpecialCharacter(txtPrevEmpCity.Text) & "',[PREV_EMP_POSITION]='" & BankString.removeSpecialCharacter(txtPrevEmpPosition.Text) & "',[PREV_EMP_SALARY]='" & txtPrevEmpSalary.Text & "',[PREV_EMP_NET]='" & txtPrevEmpSalaryNet.Text & "',[PREV_EMP_INCOME]='" & txtPrevEmpAnnualIncome.Text & "',[SPOUSE_NAME]='" & BankString.removeSpecialCharacter(txtSpouse.Text) & "',[SPOUSE_OCCUPATION]='" & BankString.removeSpecialCharacter(txtSpouseOccupation.Text) & "',[SPOUSE_EMPLOYER]='" & BankString.removeSpecialCharacter(txtSpouseEmployer.Text) & "',[NO_CHILDREN]=NULLIF('" & Trim(txtNoChildren.Text) & "',''),[NO_DEPENDANTS]=NULLIF('" & Trim(txtNoDependant.Text) & "',''),[TRADE_REF1]='" & txtTradeRef1.Text & "',[TRADE_REF2]='" & txtTradeRef2.Text & "',[GUARANTOR_NAME]='" & BankString.removeSpecialCharacter(txtGuarName.Text) & "',[GUARANTOR_DOB]='" & bdpGuarDOB.Text & "',[GUARANTOR_IDNO]='" & txtGuarIDNo.Text & "',[GUARANTOR_PHONE]='" & txtGuarPhone.Text & "',[GUARANTOR_ADD]='" & BankString.removeSpecialCharacter(txtGuarCurrAdd.Text) & "',[GUARANTOR_CITY]='" & BankString.removeSpecialCharacter(txtGuarCity.Text) & "',[GUARANTOR_HOME_TYPE]='" & rdbGuarHomeType.SelectedValue & "',[GUARANTOR_RENT]=NULLIF('" & Trim(txtGuarMonthRent.Text) & "',''),[GUARANTOR_HOME_LENGTH]=NULLIF('" & Trim(txtGuarHomeLength.Text) & "',''),[GUARANTOR_EMPLOYER]='" & BankString.removeSpecialCharacter(txtGuarCurrEmp.Text) & "',[GUARANTOR_EMP_ADD]='" & BankString.removeSpecialCharacter(txtGuarEmpAdd.Text) & "',[GUARANTOR_EMP_LENGTH]='" & txtGuarEmpLength.Text & "',[GUARANTOR_EMP_PHONE]='" & txtGuarEmpPhone.Text & "',[GUARANTOR_EMP_EMAIL]='" & BankString.removeSpecialCharacter(txtGuarEmpEmail.Text) & "',[GUARANTOR_EMP_FAX]='" & txtGuarEmpFax.Text & "',[GUARANTOR_EMP_POSTN]='" & BankString.removeSpecialCharacter(txtGuarEmpPosition.Text) & "',[GUARANTOR_EMP_SALARY]='" & txtGuarEmpSalary.Text & "',[GUARANTOR_EMP_INCOME]='" & txtGuarEmpIncome.Text & "',[GUARANTOR_REL_NAME]='" & BankString.removeSpecialCharacter(txtGuarNameRelative.Text) & "',[GUARANTOR_REL_ADD]='" & BankString.removeSpecialCharacter(txtGuarRelAddress.Text) & "',[GUARANTOR_REL_CITY]='" & BankString.removeSpecialCharacter(txtGuarRelCity.Text) & "',[GUARANTOR_REL_PHONE]='" & txtGuarRelPhone.Text & "',[GUARANTOR_REL_RELTNSHP]='" & BankString.removeSpecialCharacter(txtGuarRelReltnship.Text) & "',[FIN_AMT]='" & txtFinReqAmt.Text.Replace(",", "") & "',[FIN_TENOR]='" & txtFinReqTenor.Text & "',[FIN_INT_RATE]='" & txtFinReqIntRate.Text & "',[FIN_PURPOSE]='" & BankString.removeSpecialCharacter(cmbFinReqPurpose.SelectedValue) & "',[FIN_SRC_REPAYMT]='" & BankString.removeSpecialCharacter(txtFinReqSource.Text) & "',[FIN_SEC_OFFER]='" & BankString.removeSpecialCharacter(txtFinReqSecOffer.Text) & "',[FIN_BANK]='" & BankString.removeSpecialCharacter(txtFinReqBank.Text) & "',[FIN_BRANCH]='" & BankString.removeSpecialCharacter(txtFinReqBranchName.Text) & "',[FIN_BRANCH_CODE]='" & txtFinReqBranchCode.Text & "',[FIN_ACCNO]='" & txtFinReqAccNo.Text & "',[FIN_REPAY_DATE]='" & bdpFinReqRepaymt.Text & "',[OTHER_DESC]='" & BankString.removeSpecialCharacter(txtOtherDesc.Text) & "',[OTHER_ACCNO]='" & txtOtherAccNo.Text & "',[OTHER_AMT]='" & txtOtherAmt.Text & "',[QUES_HOW]='" & rdbQuesHow.SelectedValue & "',[QUES_EMPLOYEE]='" & BankString.removeSpecialCharacter(txtQuesEmployee.Text) & "',[QUES_AGENT]='" & BankString.removeSpecialCharacter(txtQuesAgent.Text) & "',[MODIFIED_BY]='" & Session("UserID") & "',[MODIFIED_DATE]=getdate(),[STATUS]='" & ViewState("StageName") & "',[SEND_TO]='" & ViewState("NextRole") & "',[BRANCH_CODE]='" & lblBranchCode.Text & "',[BRANCH_NAME]='" & BankString.removeSpecialCharacter(lblBranchName.Text) & "',[AREA]='" & cmbArea.SelectedValue & "',[AMT_APPLIED]='" & txtFinReqAmt.Text.Replace(",", "") & "',[ECOCASH_NUMBER]='" & txtEcocashNumber.Text & "',[OTHER_CHARGES]=NULLIF('" & Trim(txtFinReqOtherCharges.Text) & "',''),[FIN_ADMIN]=NULLIF('" & Trim(txtFinReqOtherCharges.Text) & "',''),[DISBURSE_OPTION]='',[MIN_DEPT]='" & txtMinDept.Text & "',[MIN_DEPT_NO]='" & txtMinDeptNo.Text & "',[ECNO]='" & txtECNo.Text & "',[CD]='" & txtECNoCD.Text & "',LO_ID='" & Session("ID") & "',LAST_ID='" & Session("ID") & "',INT_RATE='" & txtInterestRate.Text & "',INSURANCE_RATE='" & txtInsuranceRate.Text & "',ADMIN_RATE='" & txtAdminRate.Text & "',PDACode='" & cmbPDAAppType.SelectedValue & "',AppTypeBank='" & cmbBankAppType.SelectedValue & "',AppTypeBranch='" & cmbBranchAppType.SelectedValue & "',AppTypeOtherDesc='" & txtOtherAppType.Text & "',CUSTOMER_TYPE_ID='" & rdbClientType.SelectedValue & "',RepaymentIntervalNum=NULLIF('" & txtRepaymentInterval.Text & "',''),RepaymentIntervalUnit='" & cmbRepaymentInterval.SelectedValue & "' where ID='" & ViewState("globLoanID") & "'", con)
            Else
                'cmd = New SqlCommand("insert into QUEST_APPLICATION ([Sector],[FinProductType],[ASSET_NAME],[CUSTOMER_TYPE],[SUB_INDIVIDUAL],[CUSTOMER_NUMBER],[SURNAME],[FORENAMES],[DOB],[IDNO],[ISSUE_DATE],[ADDRESS],[CITY],[PHONE_NO],[NATIONALITY],[GENDER],[HOME_TYPE],[MONTHLY_RENT],[HOME_LENGTH],[MARITAL_STATUS],[EDUCATION],[CURR_EMPLOYER],[CURR_EMP_ADD],[CURR_EMP_LENGTH],[CURR_EMP_PHONE],[CURR_EMP_EMAIL],[CURR_EMP_FAX],[CURR_EMP_CITY],[CURR_EMP_POSITION],[CURR_EMP_SALARY],[CURR_EMP_NET],[CURR_EMP_INCOME],[PREV_EMPLOYER],[PREV_EMP_ADD],[PREV_EMP_LENGTH],[PREV_EMP_PHONE],[PREV_EMP_EMAIL],[PREV_EMP_FAX],[PREV_EMP_CITY],[PREV_EMP_POSITION],[PREV_EMP_SALARY],[PREV_EMP_NET],[PREV_EMP_INCOME],[SPOUSE_NAME],[SPOUSE_OCCUPATION],[SPOUSE_EMPLOYER],[NO_CHILDREN],[NO_DEPENDANTS],[TRADE_REF1],[TRADE_REF2],[GUARANTOR_NAME],[GUARANTOR_DOB],[GUARANTOR_IDNO],[GUARANTOR_PHONE],[GUARANTOR_ADD],[GUARANTOR_CITY],[GUARANTOR_HOME_TYPE],[GUARANTOR_RENT],[GUARANTOR_HOME_LENGTH],[GUARANTOR_EMPLOYER],[GUARANTOR_EMP_ADD],[GUARANTOR_EMP_LENGTH],[GUARANTOR_EMP_PHONE],[GUARANTOR_EMP_EMAIL],[GUARANTOR_EMP_FAX],[GUARANTOR_EMP_POSTN],[GUARANTOR_EMP_SALARY],[GUARANTOR_EMP_INCOME],[GUARANTOR_REL_NAME],[GUARANTOR_REL_ADD],[GUARANTOR_REL_CITY],[GUARANTOR_REL_PHONE],[GUARANTOR_REL_RELTNSHP],[FIN_AMT],[FIN_TENOR],[FIN_INT_RATE],[FIN_PURPOSE],[FIN_SRC_REPAYMT],[FIN_SEC_OFFER],[FIN_BANK],[FIN_BRANCH],[FIN_BRANCH_CODE],[FIN_ACCNO],[FIN_REPAY_DATE],[OTHER_DESC],[OTHER_ACCNO],[OTHER_AMT],[QUES_HOW],[QUES_EMPLOYEE],[QUES_AGENT],[APPL_SIGNATURE],[APPL_DATE],[JOINT_APPL_SIGNATURE],[APP1_APPROVED],[RECOMMENDED_AMT],[APP1_SIGNATURE],[APP2_APPROVED],[APPROVED_AMT],[APP2_SIGNATURE],[INSTALLMENT],[PERIOD],[CREATED_BY],[CREATED_DATE],[MODIFIED_BY],[MODIFIED_DATE],[STATUS],[SEND_TO],[BRANCH_CODE],[BRANCH_NAME],[AREA],[AMT_APPLIED],[ECOCASH_NUMBER],[OTHER_CHARGES],[DISBURSE_OPTION],[MIN_DEPT],[MIN_DEPT_NO],[ECNO],[CD],LO_ID,LAST_ID,INT_RATE,INSURANCE_RATE,ADMIN_RATE,[FIN_ADMIN],PDACode,AppTypeBank,AppTypeBranch,AppTypeOtherDesc) values ('" & BankString.removeSpecialCharacter(cmbSector.SelectedValue) & "','" & BankString.removeSpecialCharacter(cmbProductType.SelectedValue) & "','" & BankString.removeSpecialCharacter(reqType) & "','" & rdbClientType.SelectedValue & "','" & rdbSubIndividual.SelectedValue & "','" & txtCustNo.Text & "','" & BankString.removeSpecialCharacter(txtSurname.Text) & "','" & BankString.removeSpecialCharacter(txtForenames.Text) & "','" & bdpDOB.Text & "','" & txtIDNo.Text & "','" & bdpIssDate.Text & "','" & BankString.removeSpecialCharacter(txtAddress.Text) & "','" & BankString.removeSpecialCharacter(txtCity.Text) & "','" & txtPhoneNo.Text & "','" & BankString.removeSpecialCharacter(txtNationality.Text) & "','" & rdbGender.SelectedValue & "','" & rdbHouse.SelectedValue & "',NULLIF('" & Trim(txtRent.Text) & "',''),NULLIF('" & Trim(txtHouseHowLong.Text) & "',''),'" & cmbMaritalStatus.SelectedValue & "','" & getEducation() & "','" & BankString.removeSpecialCharacter(txtCurrEmployer.Text) & "','" & BankString.removeSpecialCharacter(txtEmpAddress.Text) & "',NULLIF('" & Trim(txtEmpHowLong.Text) & "',''),'" & txtEmpPhone.Text & "','" & txtEmpEmail.Text & "','" & txtEmpFax.Text & "','" & BankString.removeSpecialCharacter(txtEmpCity.Text) & "','" & BankString.removeSpecialCharacter(txtEmpPosition.Text) & "',NULLIF('" & Trim(txtEmpSalary.Text) & "',''),NULLIF('" & Trim(txtEmpSalaryNet.Text) & "',''),NULLIF('" & Trim(txtEmpOtherIncome.Text) & "',''),'" & BankString.removeSpecialCharacter(txtPrevEmployer.Text) & "','" & BankString.removeSpecialCharacter(txtPrevEmpAddress.Text) & "',NULLIF('" & Trim(txtPrevEmpHowLong.Text) & "',''),'" & txtPrevEmpPhone.Text & "','" & txtPrevEmpEmail.Text & "','" & txtPrevEmpFax.Text & "','" & BankString.removeSpecialCharacter(txtPrevEmpCity.Text) & "','" & BankString.removeSpecialCharacter(txtPrevEmpPosition.Text) & "',NULLIF('" & Trim(txtPrevEmpSalary.Text) & "',''),NULLIF('" & Trim(txtPrevEmpSalaryNet.Text) & "',''),NULLIF('" & Trim(txtPrevEmpAnnualIncome.Text) & "',''),'" & BankString.removeSpecialCharacter(txtSpouse.Text) & "','" & BankString.removeSpecialCharacter(txtSpouseOccupation.Text) & "','" & BankString.removeSpecialCharacter(txtSpouseEmployer.Text) & "',NULLIF('" & Trim(txtNoChildren.Text) & "',''),NULLIF('" & Trim(txtNoDependant.Text) & "',''),'" & txtTradeRef1.Text & "','" & txtTradeRef2.Text & "','" & BankString.removeSpecialCharacter(txtGuarName.Text) & "','" & bdpGuarDOB.Text & "','" & txtGuarIDNo.Text & "','" & txtGuarPhone.Text & "','" & BankString.removeSpecialCharacter(txtGuarCurrAdd.Text) & "','" & BankString.removeSpecialCharacter(txtGuarCity.Text) & "','" & rdbGuarHomeType.SelectedValue & "',NULLIF('" & Trim(txtGuarMonthRent.Text) & "',''),NULLIF('" & Trim(txtGuarHomeLength.Text) & "',''),'" & BankString.removeSpecialCharacter(txtGuarCurrEmp.Text) & "','" & BankString.removeSpecialCharacter(txtGuarEmpAdd.Text) & "',NULLIF('" & txtGuarEmpLength.Text & "',''),'" & txtGuarEmpPhone.Text & "','" & BankString.removeSpecialCharacter(txtGuarEmpEmail.Text) & "','" & txtGuarEmpFax.Text & "','" & BankString.removeSpecialCharacter(txtGuarEmpPosition.Text) & "',NULLIF('" & Trim(txtGuarEmpSalary.Text) & "',''),NULLIF('" & Trim(txtGuarEmpIncome.Text) & "',''),'" & BankString.removeSpecialCharacter(txtGuarNameRelative.Text) & "','" & BankString.removeSpecialCharacter(txtGuarRelAddress.Text) & "','" & BankString.removeSpecialCharacter(txtGuarRelCity.Text) & "','" & txtGuarRelPhone.Text & "','" & BankString.removeSpecialCharacter(txtGuarRelReltnship.Text) & "','" & txtFinReqAmt.Text.Replace(",", "") & "','" & txtFinReqTenor.Text & "','" & txtFinReqIntRate.Text & "','" & BankString.removeSpecialCharacter(cmbFinReqPurpose.SelectedValue) & "','" & BankString.removeSpecialCharacter(txtFinReqSource.Text) & "','" & BankString.removeSpecialCharacter(txtFinReqSecOffer.Text) & "','" & BankString.removeSpecialCharacter(txtFinReqBank.Text) & "','" & BankString.removeSpecialCharacter(txtFinReqBranchName.Text) & "','" & txtFinReqBranchCode.Text & "','" & txtFinReqAccNo.Text & "','" & bdpFinReqRepaymt.Text & "','" & BankString.removeSpecialCharacter(txtOtherDesc.Text) & "','" & txtOtherAccNo.Text & "',NULLIF('" & Trim(txtOtherAmt.Text) & "',''),'" & rdbQuesHow.SelectedValue & "','" & BankString.removeSpecialCharacter(txtQuesEmployee.Text) & "','" & BankString.removeSpecialCharacter(txtQuesAgent.Text) & "','','','','','','','','','','','','" & Session("UserID") & "',getdate(),'','','SUBMITTED','4042','" & lblBranchCode.Text & "','" & BankString.removeSpecialCharacter(lblBranchName.Text) & "','" & cmbArea.SelectedValue & "','" & txtFinReqAmt.Text.Replace(",", "") & "','" & txtEcocashNumber.Text & "',NULLIF('" & Trim(txtFinReqOtherCharges.Text) & "',''),'','" & txtMinDept.Text & "','" & txtMinDeptNo.Text & "','" & txtECNo.Text & "','" & txtECNoCD.Text & "','" & Session("ID") & "','" & Session("ID") & "','" & txtInterestRate.Text & "','" & txtInsuranceRate.Text & "','" & txtAdminRate.Text & "',NULLIF('" & Trim(txtFinReqOtherCharges.Text) & "',''),'" & cmbPDAAppType.SelectedValue & "','" & cmbBankAppType.SelectedValue & "','" & cmbBranchAppType.SelectedValue & "','" & txtOtherAppType.Text & "')", con)
                cmd = New SqlCommand("insert into QUEST_APPLICATION (ExportedFileTimes,Bank,BankBranch,BankAccountNo,BranchCode,[ReadyToDisburse],[ApprovalNumber],[Sector],[FinProductType],[ASSET_NAME],[CUSTOMER_TYPE],[SUB_INDIVIDUAL],[CUSTOMER_NUMBER],[SURNAME],[FORENAMES],[DOB],[IDNO],[ISSUE_DATE],[ADDRESS],[CITY],[PHONE_NO],[NATIONALITY],[GENDER],[HOME_TYPE],[MONTHLY_RENT],[HOME_LENGTH],[MARITAL_STATUS],[EDUCATION],[CURR_EMPLOYER],[CURR_EMP_ADD],[CURR_EMP_LENGTH],[CURR_EMP_PHONE],[CURR_EMP_EMAIL],[CURR_EMP_FAX],[CURR_EMP_CITY],[CURR_EMP_POSITION],[CURR_EMP_SALARY],[CURR_EMP_NET],[CURR_EMP_INCOME],[PREV_EMPLOYER],[PREV_EMP_ADD],[PREV_EMP_LENGTH],[PREV_EMP_PHONE],[PREV_EMP_EMAIL],[PREV_EMP_FAX],[PREV_EMP_CITY],[PREV_EMP_POSITION],[PREV_EMP_SALARY],[PREV_EMP_NET],[PREV_EMP_INCOME],[SPOUSE_NAME],[SPOUSE_OCCUPATION],[SPOUSE_EMPLOYER],[NO_CHILDREN],[NO_DEPENDANTS],[TRADE_REF1],[TRADE_REF2],[GUARANTOR_NAME],[GUARANTOR_DOB],[GUARANTOR_IDNO],[GUARANTOR_PHONE],[GUARANTOR_ADD],[GUARANTOR_CITY],[GUARANTOR_HOME_TYPE],[GUARANTOR_RENT],[GUARANTOR_HOME_LENGTH],[GUARANTOR_EMPLOYER],[GUARANTOR_EMP_ADD],[GUARANTOR_EMP_LENGTH],[GUARANTOR_EMP_PHONE],[GUARANTOR_EMP_EMAIL],[GUARANTOR_EMP_FAX],[GUARANTOR_EMP_POSTN],[GUARANTOR_EMP_SALARY],[GUARANTOR_EMP_INCOME],[GUARANTOR_REL_NAME],[GUARANTOR_REL_ADD],[GUARANTOR_REL_CITY],[GUARANTOR_REL_PHONE],[GUARANTOR_REL_RELTNSHP],[FIN_AMT],[FIN_TENOR],[FIN_INT_RATE],[FIN_PURPOSE],[FIN_SRC_REPAYMT],[FIN_SEC_OFFER],[FIN_BANK],[FIN_BRANCH],[FIN_BRANCH_CODE],[FIN_ACCNO],[FIN_REPAY_DATE],[OTHER_DESC],[OTHER_ACCNO],[OTHER_AMT],[QUES_HOW],[QUES_EMPLOYEE],[QUES_AGENT],[APPL_SIGNATURE],[APPL_DATE],[JOINT_APPL_SIGNATURE],[APP1_APPROVED],[RECOMMENDED_AMT],[APP1_SIGNATURE],[APP2_APPROVED],[APPROVED_AMT],[APP2_SIGNATURE],[INSTALLMENT],[PERIOD],[CREATED_BY],[CREATED_DATE],[MODIFIED_BY],[MODIFIED_DATE],[STATUS],[SEND_TO],[BRANCH_CODE],[BRANCH_NAME],[AREA],[AMT_APPLIED],[ECOCASH_NUMBER],[OTHER_CHARGES],[DISBURSE_OPTION],[MIN_DEPT],[MIN_DEPT_NO],[ECNO],[CD],LO_ID,LAST_ID,INT_RATE,INSURANCE_RATE,ADMIN_RATE,[FIN_ADMIN],PDACode,AppTypeBank,AppTypeBranch,AppTypeOtherDesc,[CUSTOMER_TYPE_ID],RepaymentIntervalNum,RepaymentIntervalUnit) values ('" & txtFinReqTenor.Text & "','" & txtBankName.Text & "','" & txtBranchName.Text & "','" & txtBankAccountNo.Text & "','" & txtBranchCode.Text & "','" & ViewState("ReadyToDisburse") & "',1,'" & BankString.removeSpecialCharacter(cmbSector.SelectedValue) & "','" & BankString.removeSpecialCharacter(cmbProductType.SelectedValue) & "','" & BankString.removeSpecialCharacter(reqType) & "','" & rdbClientType.SelectedItem.Text & "','" & rdbSubIndividual.SelectedValue & "','" & txtCustNo.Text & "','" & BankString.removeSpecialCharacter(txtSurname.Text) & "','" & BankString.removeSpecialCharacter(txtForenames.Text) & "','" & bdpDOB.Text & "','" & txtIDNo.Text & "','" & bdpIssDate.Text & "','" & BankString.removeSpecialCharacter(txtAddress.Text) & "','" & BankString.removeSpecialCharacter(txtCity.Text) & "','" & txtPhoneNo.Text & "','" & BankString.removeSpecialCharacter(txtNationality.Text) & "','" & rdbGender.SelectedValue & "','" & rdbHouse.SelectedValue & "',NULLIF('" & Trim(txtRent.Text) & "',''),NULLIF('" & Trim(txtHouseHowLong.Text) & "',''),'" & cmbMaritalStatus.SelectedValue & "','" & getEducation() & "','" & BankString.removeSpecialCharacter(txtCurrEmployer.Text) & "','" & BankString.removeSpecialCharacter(txtEmpAddress.Text) & "',NULLIF('" & Trim(txtEmpHowLong.Text) & "',''),'" & txtEmpPhone.Text & "','" & txtEmpEmail.Text & "','" & txtEmpFax.Text & "','" & BankString.removeSpecialCharacter(txtEmpCity.Text) & "','" & BankString.removeSpecialCharacter(txtEmpPosition.Text) & "',NULLIF('" & Trim(txtEmpSalary.Text) & "',''),NULLIF('" & Trim(txtEmpSalaryNet.Text) & "',''),NULLIF('" & Trim(txtEmpOtherIncome.Text) & "',''),'" & BankString.removeSpecialCharacter(txtPrevEmployer.Text) & "','" & BankString.removeSpecialCharacter(txtPrevEmpAddress.Text) & "',NULLIF('" & Trim(txtPrevEmpHowLong.Text) & "',''),'" & txtPrevEmpPhone.Text & "','" & txtPrevEmpEmail.Text & "','" & txtPrevEmpFax.Text & "','" & BankString.removeSpecialCharacter(txtPrevEmpCity.Text) & "','" & BankString.removeSpecialCharacter(txtPrevEmpPosition.Text) & "',NULLIF('" & Trim(txtPrevEmpSalary.Text) & "',''),NULLIF('" & Trim(txtPrevEmpSalaryNet.Text) & "',''),NULLIF('" & Trim(txtPrevEmpAnnualIncome.Text) & "',''),'" & BankString.removeSpecialCharacter(txtSpouse.Text) & "','" & BankString.removeSpecialCharacter(txtSpouseOccupation.Text) & "','" & BankString.removeSpecialCharacter(txtSpouseEmployer.Text) & "',NULLIF('" & Trim(txtNoChildren.Text) & "',''),NULLIF('" & Trim(txtNoDependant.Text) & "',''),'" & txtTradeRef1.Text & "','" & txtTradeRef2.Text & "','" & BankString.removeSpecialCharacter(txtGuarName.Text) & "','" & bdpGuarDOB.Text & "','" & txtGuarIDNo.Text & "','" & txtGuarPhone.Text & "','" & BankString.removeSpecialCharacter(txtGuarCurrAdd.Text) & "','" & BankString.removeSpecialCharacter(txtGuarCity.Text) & "','" & rdbGuarHomeType.SelectedValue & "',NULLIF('" & Trim(txtGuarMonthRent.Text) & "',''),NULLIF('" & Trim(txtGuarHomeLength.Text) & "',''),'" & BankString.removeSpecialCharacter(txtGuarCurrEmp.Text) & "','" & BankString.removeSpecialCharacter(txtGuarEmpAdd.Text) & "',NULLIF('" & txtGuarEmpLength.Text & "',''),'" & txtGuarEmpPhone.Text & "','" & BankString.removeSpecialCharacter(txtGuarEmpEmail.Text) & "','" & txtGuarEmpFax.Text & "','" & BankString.removeSpecialCharacter(txtGuarEmpPosition.Text) & "',NULLIF('" & Trim(txtGuarEmpSalary.Text) & "',''),NULLIF('" & Trim(txtGuarEmpIncome.Text) & "',''),'" & BankString.removeSpecialCharacter(txtGuarNameRelative.Text) & "','" & BankString.removeSpecialCharacter(txtGuarRelAddress.Text) & "','" & BankString.removeSpecialCharacter(txtGuarRelCity.Text) & "','" & txtGuarRelPhone.Text & "','" & BankString.removeSpecialCharacter(txtGuarRelReltnship.Text) & "','" & txtFinReqAmt.Text.Replace(",", "") & "','" & txtFinReqTenor.Text & "','" & txtFinReqIntRate.Text & "','" & BankString.removeSpecialCharacter(cmbFinReqPurpose.SelectedValue) & "','" & BankString.removeSpecialCharacter(txtFinReqSource.Text) & "','" & BankString.removeSpecialCharacter(txtFinReqSecOffer.Text) & "','" & BankString.removeSpecialCharacter(txtFinReqBank.Text) & "','" & BankString.removeSpecialCharacter(txtFinReqBranchName.Text) & "','" & txtFinReqBranchCode.Text & "','" & txtFinReqAccNo.Text & "','" & bdpFinReqRepaymt.Text & "','" & BankString.removeSpecialCharacter(txtOtherDesc.Text) & "','" & txtOtherAccNo.Text & "',NULLIF('" & Trim(txtOtherAmt.Text) & "',''),'" & rdbQuesHow.SelectedValue & "','" & BankString.removeSpecialCharacter(txtQuesEmployee.Text) & "','" & BankString.removeSpecialCharacter(txtQuesAgent.Text) & "','','','','','','','','','','','','" & Session("UserID") & "',getdate(),'','','" & ViewState("StageName") & "','" & ViewState("NextRole") & "','" & lblBranchCode.Text & "','" & BankString.removeSpecialCharacter(lblBranchName.Text) & "','" & cmbArea.SelectedValue & "',NULLIF('" & txtFinReqAmt.Text.Replace(",", "") & "',''),'" & txtEcocashNumber.Text & "',NULLIF('" & Trim(txtFinReqOtherCharges.Text) & "',''),'','" & txtMinDept.Text & "','" & txtMinDeptNo.Text & "','" & txtECNo.Text & "','" & txtECNoCD.Text & "','" & Session("ID") & "','" & Session("ID") & "',NULLIF('" & txtInterestRate.Text & "',''),NULLIF('" & txtInsuranceRate.Text & "',''),NULLIF('" & txtAdminRate.Text & "',''),NULLIF('" & Trim(txtFinReqOtherCharges.Text) & "',''),'" & cmbPDAAppType.SelectedValue & "','" & cmbBankAppType.SelectedValue & "','" & cmbBranchAppType.SelectedValue & "','" & txtOtherAppType.Text & "','" & rdbClientType.SelectedValue & "',NULLIF('" & txtRepaymentInterval.Text & "',''),'" & cmbRepaymentInterval.SelectedValue & "')", con)
                'cmd.Parameters.AddWithValue("@DefaultIntInterval", rdbInterestInterval.SelectedValue)
                'cmd.Parameters.AddWithValue("@IntCalcMethod", rdbInterestCalcMethod.SelectedValue)
                'cmd.Parameters.AddWithValue("@IntTrigger", rdbInterestTrigger.SelectedValue)
                'cmd.Parameters.AddWithValue("@DaysInYear", rdbYearDays.SelectedValue)
                'cmd.Parameters.AddWithValue("@RepaymentFreq", rdbRepayFreq.SelectedValue)
                'cmd.Parameters.AddWithValue("@HasGracePeriod", rdbGracePeriod.SelectedValue)
                'cmd.Parameters.AddWithValue("@GracePeriodType", rdbGracePeriodType.SelectedValue)
                'cmd.Parameters.AddWithValue("@GracePeriodLength", txtGracePerLength.Text)
                'cmd.Parameters.AddWithValue("@GracePeriodUnit", cmbGracePerLength.SelectedValue)
                'cmd.Parameters.AddWithValue("@AllowRepaymentOnWknd", rdbRepayWknd.SelectedValue)
                'cmd.Parameters.AddWithValue("@IfRepaymentFallsOnWknd", rdbRepaymentWknd.SelectedValue)
                'cmd.Parameters.AddWithValue("@AllowEditingPaymentSchedule", rdbEditPaySchedule.SelectedValue)
                'cmd.Parameters.AddWithValue("@RepayOrder1", cmbRepaymentAllocationOrder1.SelectedValue)
                'cmd.Parameters.AddWithValue("@RepayOrder2", cmbRepaymentAllocationOrder2.SelectedValue)
                'cmd.Parameters.AddWithValue("@RepayOrder3", cmbRepaymentAllocationOrder3.SelectedValue)
                'cmd.Parameters.AddWithValue("@RepayOrder4", cmbRepaymentAllocationOrder4.SelectedValue)
                'cmd.Parameters.AddWithValue("@TolerancePeriodNum", txtTolerancePeriod.Text)
                'cmd.Parameters.AddWithValue("@TolerancePeriodUnit", cmbTolerancePeriod.SelectedValue)
                'cmd.Parameters.AddWithValue("@ArrearNonWorkingDays", rdbArrearNonWorking.SelectedValue)
                'cmd.Parameters.AddWithValue("@PenaltyCharged", rdbPenaltyCharged.SelectedValue)
                'cmd.Parameters.AddWithValue("@PenaltyOption", rdbPenaltyOption.SelectedValue)
                'cmd.Parameters.AddWithValue("@AmtToPenalise", rdbAmtToPenalise.SelectedValue)
                'cmd.Parameters.AddWithValue("@ProductFees", rdbProductFees.SelectedValue)
                'cmd.Parameters.AddWithValue("@ProductFeeCalc", rdbProductFeeCalc.SelectedValue)
                'cmd.Parameters.AddWithValue("@ProductFeeAmtPerc", txtProductFee.Text)
            End If
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()

            If cmd.ExecuteNonQuery() Then
                updateDocLoanID(txtCustNo.Text)
                saveInitiatorComment()
                Dim strEmail As String
                Dim SignatoryEMail As String
                'Dim SignatoryEMail As String = Mailhelper.GetMultiBranchRoleEMailID(Session("BRANCHCODE"), "4042")

                strEmail = "Dear Sir/Madam,<br/><br/>You have received a request for " & ViewState("NextStageName") & ". Details of the application are as follows<br><br>"
                strEmail = strEmail & "<table style='border: 1px solid black; width:750px;border-collapse: collapse; font-size:13px'>"
                strEmail = strEmail & "<tr style='background-color: #f5f5f5;padding: 15px;text-align: left;'><th style='border: 1px solid black;text-align: left;'>Client Name:</th><td style='border: 1px solid black;'>" & txtSurname.Text & " " & txtForenames.Text & "</td></tr>"
                strEmail = strEmail & "<tr style='background-color: white;padding: 15px;text-align: left;'><th style='border: 1px solid black;text-align: left;'>Date:</th><td style='border: 1px solid black;'>" & Now.ToShortDateString() & "</td></tr>"
                strEmail = strEmail & "<tr style='background-color: #f5f5f5;padding: 15px;text-align: left;'><th style='border: 1px solid black;text-align: left;'>Applicant Type:</th><td style='border: 1px solid black;'>" & rdbClientType.SelectedItem.Text & "</td></tr>"
                strEmail = strEmail & "<tr style='background-color: white;padding: 15px;text-align: left;'><th style='border: 1px solid black;text-align: left;'>Product:</th><td style='border: 1px solid black;'>" & cmbProductType.SelectedItem.Text.ToString & "</td></tr>"
                strEmail = strEmail & "<tr style='background-color: #f5f5f5;padding: 15px;text-align: left;'><th style='border: 1px solid black;text-align: left;'>Sector:</th><td style='border: 1px solid black;'>" & cmbSector.SelectedItem.Text.ToString & "</td></tr>"
                strEmail = strEmail & "<tr style='background-color: white;padding: 15px;text-align: left;'><th style='border: 1px solid black;text-align: left;'>Branch:</th><td style='border: 1px solid black;'>" & lblBranchCode.Text.Trim() & " - " & lblBranchName.Text.Trim() & "</td></tr>"
                strEmail = strEmail & "<tr style='background-color: #f5f5f5;padding: 15px;text-align: left;'><th style='border: 1px solid black;text-align: left;'>Amount:</th><td style='border: 1px solid black;'>" & FormatCurrency(txtFinReqAmt.Text).ToString.Replace("Z", "ZMW").Replace("US$", "ZMW") & "</td></tr>"
                strEmail = strEmail & "</table>"
                strEmail = strEmail & "<br/>Thanks & Regards,<br/><b>Escrow 360 Support Team</b>"
                strEmail = strEmail + "<br/><br/><p style='font-size:10px; color:gray;'>Powered by <a href='escrowsystems.net'>Escrow Systems</a></p>"
                'If Trim(SignatoryEMail) = "" Then
                SignatoryEMail = Mailhelper.GetMultipleEMailID(ViewState("NextRole"))
                'End If
                Mailhelper.SendMailMessage("administrator", SignatoryEMail, "", "", "Escrow Credit Management - Loan Application", strEmail)
                clearAll()
                lblTest.Text = ViewState("globLoanID")

                ClientScript.RegisterStartupScript(Me.GetType(), "HideLabel", "<script type=""text/javascript"">showPopup()</script>")
                clearAll()
            End If

            con.Close()
            'End If

        Catch ex As Exception
            ErrorLogging.WriteLogFile(Session("UserId"), "QuestCredit/ApplicationForm.aspx -- submittapplication()", ex.ToString)
        End Try
    End Sub

    Protected Sub updateDocLoanID(custNo As String)
        ViewState("globLoanID") = getLastLoanID()
        cmd = New SqlCommand("update QUEST_DOCUMENTS set LOAN_ID='" & ViewState("globLoanID") & "' where CUST_NO='" & custNo & "' and (LOAN_ID='' or LOAN_ID is null)", con)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
    End Sub

    Protected Sub writeBranch()
        lblBranchCode.Text = Session("BRANCHCODE")
        lblBranchName.Text = Session("BRANCHNAME")
    End Sub

    Protected Sub writeSubmitButton(ByVal roleID As String)
        If roleID = "4042" Then
            btnSubmit.Text = "Recommend"
        ElseIf roleID = "4043" Then
            btnSubmit.Text = "Approve"
        ElseIf roleID = "4044" Then
            btnSubmit.Text = "Approve"
        ElseIf roleID = "1024" Then
            btnSubmit.Text = "Approve for Disbursal"
        ElseIf roleID = "4041" Then
            If Request.QueryString("rej") = 1 Then
                btnSubmit.Text = "Resubmit Application"
            Else
                btnSubmit.Text = "Disburse"
            End If
        End If
    End Sub
    'Protected Sub rdbSubIndividual_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdbSubIndividual.SelectedIndexChanged
    '    Try
    '        If rdbSubIndividual.SelectedValue = "SSB" Then
    '            SSBVisible()
    '        Else
    '            SSBInvisible()
    '        End If
    '    Catch ex As Exception

    Private Sub btnAddPurpose_Click(sender As Object, e As EventArgs) Handles btnAddPurpose.Click
        Try
            Using cmd = New SqlCommand("select * from PARA_PURPOSE where PURPOSE='" & txtPurpose.Text & "'", con)
                Dim ds As New DataSet
                adp = New SqlDataAdapter(cmd)
                adp.Fill(ds, "PRODUCTS")
                Dim cmdSub As New SqlCommand
                If ds.Tables(0).Rows.Count > 0 Then
                    'cmd = New SqlCommand("update PARA_PURPOSE set PURPOSE='" & BankString.removeSpecialCharacter(Trim(txtPurpose.Text)) & "', LOAN_MODIFIED_BY='" & Session("UserID") & "', LOAN_MODIFIED_DATE=getdate() where LOAN_SHORT_DESC='" & Trim(txtShortName.Text) & "'", con)
                Else
                    cmdSub = New SqlCommand("insert into PARA_PURPOSE ([PURPOSE]) values ('" & BankString.removeSpecialCharacter(Trim(txtPurpose.Text)) & "')", con)
                End If
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                cmdSub.ExecuteNonQuery()
                con.Close()
                CreditManager.notify("New purpose entered", "success")
                txtPurpose.Text = ""
                loadPurpose(cmbFinReqPurpose)
            End Using
        Catch ex As Exception
            ErrorLogging.WriteLogFile(Session("UserId"), "QuestCredit/ApplicationForm.aspx -- btnAddPurpose()", ex.Message)
        End Try
    End Sub

    Private Sub cmbProductType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbProductType.SelectedIndexChanged
        getProductDefaults(cmbProductType.SelectedValue)
        getCreditParams(cmbProductType.SelectedValue)
    End Sub
    Private Sub loadFarmerDetails(custNo As String)
        Try
            cmd = New SqlCommand("select *,convert(varchar(50),dob,113) as DOB1,convert(varchar(50),ISSUE_DATE,113) as ISSUE_DATE1 from CUSTOMER_DETAILS where CUSTOMER_NUMBER='" & custNo & "'", con)
            Dim ds As New DataSet
            Using adp = New SqlDataAdapter(cmd)
                adp.Fill(ds, "CUSTOMER")
            End Using
            If ds.Tables(0).Rows.Count > 0 Then
                txtCustNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CUSTOMER_NUMBER"))
                txtFarmNameOfGroup.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SURNAME"))
                txtFarmNameOfApplicant.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FORENAMES"))
                txtFarmCurrentAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ADDRESS"))
                'txtCreditLimit.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CREDIT_LIMIT"))
                txtFarmPhoneNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PHONE_NO"))
                txtFarmIDNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("IDNO"))
                txtFarmNameOfSpouse.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_NAME"))
                txtFarmCurrAddressOfSpouse.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_ADDRESS"))
                txtFarmMonthlyExpense.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("MONTH_EXPENSE"))
                txtFarmMonthlyIncome.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("MONTH_INCOME"))
                txtFarmPreviousSales.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_SALES"))
                txtFarmCurrentEstimate.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_ESTIMATE"))
                txtFarmSpousePhoneNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_PHONE"))
                txtFarmSpouseIDNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_IDNO"))

                txtFarmCropsGrown.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CROPS"))
                txtFarmPeriodFarming.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FARM_PERIOD"))

                rdbClientType.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("CUSTOMER_TYPE_ID"))
                rdbFarmGender.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("GENDER"))

                txtFarmDOB.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("DOB1"))
                txtFarmIssDate.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ISSUE_DATE1"))

            Else
            End If
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- loadFarmerDetails()", ex.ToString)
        End Try
    End Sub

End Class