﻿Imports System
Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient

Partial Class Credit_DateUpdate
    Inherits System.Web.UI.Page
    Public Shared globLoanID As Double = 0
    Public Shared isApproval As Double = 0
    Shared adp As New SqlDataAdapter
    Shared cmd As SqlCommand
    Shared con As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
    Public Sub msgbox(ByVal strMessage As String)

        'finishes server processing, returns to client.
        Dim strScript As String = "<script language=JavaScript>"
        strScript += "window.alert(""" & strMessage & """);"
        strScript += "</script>"
        Dim lbl As New System.Web.UI.WebControls.Label
        lbl.Text = strScript
        Page.Controls.Add(lbl)
    End Sub

    Protected Sub btnSearchLoanID_Click(sender As Object, e As EventArgs) Handles btnSearchLoanID.Click
        Try
            loadDisbDate(txtLoanID.Text)
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub btnSearchName_Click(sender As Object, e As EventArgs) Handles btnSearchName.Click
        Try
            loadLoans(txtSearchName.Text)
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub btnUpdateDisbDate_Click(sender As Object, e As EventArgs) Handles btnUpdateDisbDate.Click
        Try
            If Trim(txtDisbDate.Text) = "" Then
                msgbox("Enter Disbursement Date")
            Else
                cmd = New SqlCommand("update_disburse_date", con)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@loanID", txtLoanID.Text)
                cmd.Parameters.AddWithValue("@disb_date", txtDisbDate.Text)
                If con.State <> ConnectionState.Closed Then
                    con.Close()
                End If
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                msgbox("Disbursement Date Updated")
                loadLoans()
                txtDisbDate.Text = ""
                txtLoanID.Text = ""
                txtSearchName.Text = ""
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Function isAmortized(loanID As String) As Boolean
        cmd = New SqlCommand("select * from AMORTIZATION_SCHEDULE where LOANID='" & loanID & "'", con)
        Dim ds As New DataSet
        adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "armo")
        If ds.Tables(0).Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Protected Sub loadDisbDate(loanID As String)
        Try
            cmd = New SqlCommand("select isnull([SUB_INDIVIDUAL],'') as [SUB_INDIVIDUAL],[FIN_AMT],[FIN_TENOR],[FIN_INT_RATE],[FIN_ADMIN],[FIN_REPAY_DATE],[FIN_REPAY_OPT],convert(varchar,DISBURSED_DATE,106) as DISBURSED_DATE1 from QUEST_APPLICATION where ID='" & loanID & "' and disbursed=1", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "CREDIT")
            If ds.Tables(0).Rows.Count > 0 Then
                txtDisbDate.Text = ds.Tables(0).Rows(0).Item("DISBURSED_DATE1")
            Else
                msgbox("Loan not found")
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub loadLoans(Optional sname As String = "")
        Try
            If sname <> "" Then
                cmd = New SqlCommand("select ID,ltrim(isnull(SURNAME,'')+' ')+ltrim(isnull(FORENAMES,'')+' ')+ltrim(isnull(CUSTOMER_NUMBER,'')+' ')+ltrim(isnull(convert(varchar,AMT_APPLIED),'')+' ')+isnull(ADDRESS,'') as DISPLAY from QUEST_APPLICATION where ltrim(isnull(SURNAME,'')+' ')+ltrim(isnull(FORENAMES,'')+' ')+ltrim(isnull(CUSTOMER_NUMBER,'')+' ')+ltrim(isnull(IDNO,'')+' ')+isnull(ADDRESS,'') like '%" & Trim(sname) & "%' and disbursed=1 order by DISPLAY", con)
            Else
                cmd = New SqlCommand("select ID,ltrim(isnull(SURNAME,'')+' ')+ltrim(isnull(FORENAMES,'')+' ')+ltrim(isnull(CUSTOMER_NUMBER,'')+' ')+ltrim(isnull(convert(varchar,AMT_APPLIED),'')+' ')+isnull(ADDRESS,'') as DISPLAY from QUEST_APPLICATION where disbursed=1 order by DISPLAY", con)
            End If
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "LRS")
            If ds.Tables(0).Rows.Count > 0 Then
                lstLoans.Visible = True
                lstLoans.DataSource = ds.Tables(0)
                lstLoans.DataTextField = "DISPLAY"
                lstLoans.DataValueField = "ID"
            Else
                lstLoans.DataSource = Nothing
            End If
            lstLoans.DataBind()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub lstLoans_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstLoans.SelectedIndexChanged
        Try
            Dim loanID = lstLoans.SelectedValue
            txtLoanID.Text = loanID
            btnSearchLoanID_Click(sender, New EventArgs)
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True
        If Not IsPostBack Then
            loadLoans()
        End If
    End Sub
End Class