﻿Partial Class Credit_ViewMaturityProfile
    Inherits System.Web.UI.Page

End Class