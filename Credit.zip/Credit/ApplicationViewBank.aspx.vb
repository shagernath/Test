﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Credit_ApplicationViewBank
    Inherits System.Web.UI.Page
    Dim adp As SqlDataAdapter
    Dim cmd As SqlCommand
    Dim con As New SqlConnection
    Dim connection As String
    Protected Sub btnModalPopup_Click(sender As Object, e As EventArgs) Handles btnModalPopup.Click

    End Sub

    Protected Sub btnSearchRange_Click(sender As Object, e As EventArgs) Handles btnSearchRange.Click
        Try
            cmd = New SqlCommand("select ID,CUSTOMER_NUMBER as [CUST NO.],RTRIM(SURNAME+' '+FORENAMES) as NAME,FIN_AMT as AMOUNT,CREATED_DATE as 'APPLICATION DATE' from QUEST_APPLICATION where SEND_TO='" & Session("ROLE") & "' and CREATED_DATE between '" & DateFormat.getSaveDate(bdpFrom.SelectedDate) & "' and '" & DateFormat.getSaveDate(bdpTo.SelectedDate) & "' AND FIN_BANK <>'' order by CREATED_DATE desc", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "APP")
            If ds.Tables(0).Rows.Count > 0 Then
                grdApps.DataSource = ds.Tables(0)
            Else
                grdApps.DataSource = Nothing
            End If
            grdApps.DataBind()
        Catch ex As Exception
        End Try
    End Sub

    Protected Sub getApplications(ByVal roleID As String)
        Try
            cmd = New SqlCommand("select ID,CUSTOMER_NUMBER as [CUST NO.],case IS_PARTIAL when 1 then RTRIM(SURNAME+' '+FORENAMES)+' - PARTIALLY DISBURSED' else RTRIM(SURNAME+' '+FORENAMES) end as NAME,CONVERT(DECIMAL(30,2),FIN_AMT) as AMOUNT,CREATED_DATE as 'APPLICATION DATE' from QUEST_APPLICATION where SEND_TO='" & roleID & "' and STATUS<>'REJECTED' AND FIN_BANK <>'' order by CREATED_DATE desc", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "APP")
            If ds.Tables(0).Rows.Count > 0 Then
                grdApps.DataSource = ds.Tables(0)
            Else
                grdApps.DataSource = Nothing
            End If
            grdApps.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub grdApps_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles grdApps.RowCommand
        Try
            If e.CommandName = "Select" Then
                Dim loanID = e.CommandArgument
                If isIndividual(loanID) Then
                    Response.Redirect("ApplicationApprovalBank.aspx?id=" & loanID)
                Else
                    Response.Redirect("ApplicationApprovalGrp.aspx?id=" & loanID)
                End If
            ElseIf e.CommandName = "Details" Then
                Dim loanID = e.CommandArgument
                lblDetailID.Text = loanID
                lblSessionRole.Text = Session("ROLE")
                'btnModalPopup_Click(sender, New EventArgs)
            End If
        Catch ex As Exception
        End Try
    End Sub

    Protected Sub grdApps_SelectedIndexChanged(sender As Object, e As EventArgs) Handles grdApps.SelectedIndexChanged

    End Sub

    Protected Function isIndividual(ByVal loanID As String) As Boolean
        Dim ind As String = ""
        cmd = New SqlCommand("select CUSTOMER_TYPE from QUEST_APPLICATION where ID='" & loanID & "'", con)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        ind = cmd.ExecuteScalar
        con.Close()
        'msgbox(ind)
        If ind = "Individual" Then
            Return True
        Else
            Return False
        End If
    End Function

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Try
            Page.MaintainScrollPositionOnPostBack = True
            con = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            If Not IsPostBack Then
                If Trim(Session("ROLE")) = "" Then
                    Response.Redirect("~/Login.aspx")
                Else
                    getApplications(Session("ROLE"))
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class