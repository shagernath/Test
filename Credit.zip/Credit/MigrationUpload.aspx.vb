﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Text
Imports Microsoft.VisualBasic.FileIO

Partial Class Credit_MigrationUpload
    Inherits System.Web.UI.Page
    Dim adp As New SqlDataAdapter
    Dim cmd As SqlCommand
    Dim con As New SqlConnection
    Dim connection As String
    Dim urlPermission As String = "PermissionDenied.aspx"

    Public Sub createTabbedFile(ByVal csvFileFullPath As String, ByVal tabFileFullPath As String)
        'This routine uses the VB TextFieldParser class to properly parse the csv file and convert to a
        'tab delimited file and subsequent tasks in the package can read from the tab file. Apparently the
        'TaskFieldParser class does not have this limitation and it works as we expected. Besides it also
        'provides an added feature where by you can trim extra spaces from text  fields.

        Using tabStreamWriter As New StreamWriter(tabFileFullPath)
            Using csvFileReader As New TextFieldParser(csvFileFullPath)
                csvFileReader.TextFieldType = FieldType.Delimited
                csvFileReader.Delimiters = New String() {","}
                csvFileReader.HasFieldsEnclosedInQuotes = True
                csvFileReader.TrimWhiteSpace = True
                Dim currentRow As String()
                While Not (csvFileReader.EndOfData)
                    Try
                        Dim i As Int32 = 1
                        Dim outputRow As New Text.StringBuilder()
                        currentRow = csvFileReader.ReadFields()
                        For Each currentField As String In currentRow
                            'currentField = currentField.Replace(Chr(34), Chr(39)) 'replace double quote with single quote if needed
                            outputRow.Append(currentField)
                            If i < currentRow.Length Then
                                outputRow.Append(Chr(9)) 'add a tab for each field except last one
                            End If
                            i = i + 1
                        Next
                        tabStreamWriter.WriteLine(outputRow.ToString())
                    Catch ex As Microsoft.VisualBasic.FileIO.MalformedLineException
                        'Dts.TaskResult = Dts.Results.Failure
                    End Try
                End While
            End Using
        End Using
        'Dts.TaskResult = Dts.Results.Success
    End Sub

    Public Sub insertAccounts()
        Try
            'Dim bankCode = cmbBanks.SelectedValue
            'Dim bankName = cmbBanks.SelectedItem.Text
            Dim fd As New DataSet
            fd = GetData()
            Dim rowcount = fd.Tables(0).Rows.Count
            Dim colcount = fd.Tables(0).Columns.Count
            For i = 0 To rowcount - 1
                'msgbox(fd.Tables(0).Rows(i).Item(6).ToString)
                Dim name = Trim(removeNULL(fd, i, 0))
                Dim custAcNo = Trim(removeNULL(fd, i, 1))
                'Dim email = Trim(removeNULL(fd, i, 2))
                'Dim freq = Trim(removeNULL(fd, i, 3))
                cmd = New SqlCommand()
                cmd.Connection = con
                Dim accID = isAccount(custAcNo)
                If accID = 0 Then
                    cmd.CommandText = "insert into CUSTOMER_DETAILS(CUSTOMER_NUMBER,SURNAME,FORENAMES) values ('" & custAcNo & "','" & name.Replace("'", "''") & "','')"
                    If con.State = ConnectionState.Open Then
                        con.Close()
                    End If
                    con.Open()
                    cmd.ExecuteNonQuery()
                    con.Close()
                Else
                    'cmd.CommandText = "update CUSTOMER_DETAILS set CUSTOMER_NUMBER='" & custAcNo & "',SURNAME='" & name.Replace("'", "''") & "',FORENAMES='' where ID='" & accID & "'"
                End If

                'msgbox(cmd.CommandText)
            Next
            msgbox("Import successful")
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Public Sub msgbox(ByVal strMessage As String)

        'finishes server processing, returns to client.
        Dim strScript As String = "<script language=JavaScript>"
        strScript += "window.alert(""" & strMessage & """);"
        strScript += "</script>"
        Dim lbl As New System.Web.UI.WebControls.Label
        lbl.Text = strScript
        Page.Controls.Add(lbl)
    End Sub

    Function removeNULL(ByVal myreader As DataSet, ByVal j As Integer, ByVal stval As Integer) As String

        Dim val As Object = myreader.Tables(0).Rows(j).Item(stval)
        If val IsNot DBNull.Value And val <> "" Then
            Return val.ToString()
        Else
            Return Convert.ToString(0)
        End If
    End Function

    Protected Sub btnUpload_Click(sender As Object, e As EventArgs) Handles btnUpload.Click
        insertAccounts()
    End Sub
    Protected Function isAccount(accNo As String) As Double
        Dim fqy As Double = 0
        cmd = New SqlCommand("select ID from CUSTOMER_DETAILS where CUSTOMER_NUMBER='" & accNo & "'", con)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        fqy = cmd.ExecuteScalar
        con.Close()
        Try
            Return fqy
        Catch ex As Exception
            Return 0
        End Try
    End Function

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True
        con = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
        If Not IsPostBack Then
        End If
    End Sub

    Private Function GetData() As DataSet
        'msgbox(Server.MapPath(FileUpload1.FileName).ToString)
        'Exit Function
        Dim strLine As String
        Dim strArray() As String
        Dim charArray() As Char = {"	"c}
        Dim ds As New DataSet()
        Dim dt As DataTable = ds.Tables.Add("TheData")
        fldUpload.SaveAs(Server.MapPath("Uploads/" & fldUpload.FileName))
        createTabbedFile(Server.MapPath("Uploads/" & fldUpload.FileName), Server.MapPath("Uploads/tab" & fldUpload.FileName))
        Dim aFile As New FileStream(Server.MapPath("Uploads/tab" & fldUpload.FileName), FileMode.Open)
        Dim sr As New StreamReader(aFile)

        strLine = sr.ReadLine()
        strArray = strLine.Split(charArray)

        For x As Integer = 0 To strArray.GetUpperBound(0)
            dt.Columns.Add(strArray(x).Trim())
        Next x

        strLine = sr.ReadLine()
        Do While strLine IsNot Nothing
            strArray = strLine.Split(charArray)
            Dim dr As DataRow = dt.NewRow()
            For i As Integer = 0 To strArray.GetUpperBound(0)
                dr(i) = strArray(i).Trim()
            Next i
            dt.Rows.Add(dr)
            strLine = sr.ReadLine()
        Loop
        sr.Close()
        Return ds
    End Function
End Class