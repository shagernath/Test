﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports ErrorLogging

Partial Class LoanAdjustmentsFormFile
    Inherits System.Web.UI.Page
    Dim cmd As SqlCommand
    Dim adp As SqlDataAdapter
    Dim con As New SqlConnection
    Dim connection As String
    Public Shared typeEditID As Double
    Public Sub msgbox(ByVal strMessage As String)
        'finishes server processing, returns to client.
        Dim strScript As String = "<script language=JavaScript>"
        strScript += "window.alert(""" & strMessage & """);"
        strScript += "</script>"
        Dim lbl As New System.Web.UI.WebControls.Label
        lbl.Text = strScript
        Page.Controls.Add(lbl)
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True
        con = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
        If Not IsPostBack Then
            getApplications(Trim(txtSearchName.Text))
        End If
    End Sub
    Protected Sub getApplications(cliName As String)
        Try
            If DropDownList1.SelectedIndex = 0 Then
                cmd = New SqlCommand("select ID,CUSTOMER_NUMBER as [CUST NO.],case IS_PARTIAL when 1 then RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,''))+' - PARTIALLY DISBURSED' else RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) end as NAME,CONVERT(DECIMAL(30,2),FIN_AMT) as AMOUNT,CREATED_DATE as 'APPLICATION DATE',Branch_Name,FIN_REPAY_DATE AS '1st Repay Date',Disbursed_Date,IDNO AS 'NRC No.',Bank,BANKBRANCH AS Branch,BANKACCOUNTNO AS 'Account No.' from QUEST_APPLICATION where DISBURSE_OPTION='DDEBIT' and ExportedFile=1 and isnull(MarkedForredownload,0)<>1 and STATUS NOT IN ('REJECTED','TERMINATED') and RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) like '%" & cliName & "%' order by id desc", con)
            Else
                cmd = New SqlCommand("select ID,CUSTOMER_NUMBER as [CUST NO.],case IS_PARTIAL when 1 then RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,''))+' - PARTIALLY DISBURSED' else RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) end as NAME,CONVERT(DECIMAL(30,2),FIN_AMT) as AMOUNT,CREATED_DATE as 'APPLICATION DATE',Branch_Name,FIN_REPAY_DATE AS '1st Repay Date',Disbursed_Date,IDNO AS 'NRC No.' from QUEST_APPLICATION where DISBURSE_OPTION<>'DDEBIT' and ExportedFile=1 and isnull(MarkedForredownload,0)<>1 and STATUS NOT IN ('REJECTED','TERMINATED') and RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) like '%" & cliName & "%' order by id desc", con)
            End If
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "APP")
            If ds.Tables(0).Rows.Count > 0 Then
                grdApps.DataSource = ds.Tables(0)
            Else
                grdApps.DataSource = Nothing
            End If
            grdApps.DataBind()
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- getApplications", ex.ToString)
        End Try
    End Sub
    Protected Sub grdApps_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles grdApps.PageIndexChanging
        grdApps.PageIndex = e.NewPageIndex
        getApplications(Trim(txtSearchName.Text))
    End Sub
    Protected Sub btnSearchRange_Click(sender As Object, e As EventArgs) Handles btnSearchRange.Click
        getApplications(Trim(txtSearchName.Text))
    End Sub

    Protected Sub btnModify_Click(sender As Object, e As EventArgs) Handles btnModify.Click
        If gridhasmarked() = False Then
            msgbox("Select Applications")
        Else
            For Each row As GridViewRow In grdApps.Rows
                Dim chkView As CheckBox = DirectCast(row.FindControl("chk"), CheckBox)
                If chkView.Checked Then
                    Dim LoanID As Integer = CInt(row.Cells(2).Text)
                    cmd = New SqlCommand("select * from QUEST_APPLICATION where ID='" & LoanID & "'", con)
                    Dim ds As New DataSet
                    adp = New SqlDataAdapter(cmd)
                    adp.Fill(ds, "QUEST_APPLICATION")
                    If ds.Tables(0).Rows.Count > 0 Then
                        Dim cmdstr As String = ""
                        If DropDownList1.SelectedIndex = 0 Then
                            cmdstr = "update QUEST_APPLICATION Set MarkedForredownload=1,ExportedFile=0,ExportedFileTimes=isnull(ExportedFileTimes,0)+1 where ID=" & LoanID & ""
                        Else
                            cmdstr = "update QUEST_APPLICATION Set MarkedForredownload=1,ExportedFile=0 where ID=" & LoanID & ""
                        End If
                        cmd = New SqlCommand(cmdstr, con)
                        If con.State = ConnectionState.Open Then
                            con.Close()
                        End If
                        con.Open()
                        If cmd.ExecuteNonQuery() Then
                        End If
                    End If
                End If
            Next
            getApplications(Trim(txtSearchName.Text))
            msgbox("Marked Applications Successfully Updated for re-download")
        End If
    End Sub
    Private Function gridhasmarked() As Boolean
        If grdApps.Rows.Count > 0 Then
            Dim k As Long = 0
            For Each row As GridViewRow In grdApps.Rows
                Dim chkView As CheckBox = DirectCast(row.FindControl("chk"), CheckBox)
                If chkView.Checked Then
                    k += 1
                Else
                    k += 0
                End If
            Next
            If k = 0 Then
                Return False
            Else
                Return True
            End If
        Else
            Return False
        End If
    End Function
    Protected Sub btnSelectAll_Click(sender As Object, e As EventArgs) Handles btnSelectAll.Click
        If grdApps.Rows.Count > 0 Then
            For Each row As GridViewRow In grdApps.Rows
                Dim chkView As CheckBox = DirectCast(row.FindControl("chk"), CheckBox)
                If chkView.Checked Then
                Else
                    chkView.Checked = True
                End If
            Next
        End If
    End Sub
    Protected Sub DropDownList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList1.SelectedIndexChanged
        getApplications(Trim(txtSearchName.Text))
    End Sub
End Class
