﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Credit_ApplicationView
    Inherits System.Web.UI.Page
    Dim adp As SqlDataAdapter
    Dim cmd As SqlCommand
    Dim con As New SqlConnection

    Public Sub msgbox(ByVal strMessage As String)
        'finishes server processing, returns to client.
        Dim strScript As String = "<script language=JavaScript>"
        strScript += "window.alert(""" & strMessage & """);"
        strScript += "</script>"
        Dim lbl As New System.Web.UI.WebControls.Label
        lbl.Text = strScript
        Page.Controls.Add(lbl)
    End Sub

    

    Protected Sub btnSearchRange_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearchRange.Click
        'Try
        '    cmd = New SqlCommand("select ID,CUSTOMER_NUMBER as [CUST NO.],RTRIM(SURNAME+' '+FORENAMES) as NAME,FIN_AMT as AMOUNT,CREATED_DATE as 'APPLICATION DATE' from QUEST_APPLICATION where SEND_TO='" & Session("ROLE") & "' and CREATED_DATE between '" & bdpFrom.Text & "' and '" & bdpTo.Text & "'  order by CREATED_DATE desc", con)
        '    Dim ds As New DataSet
        '    adp = New SqlDataAdapter(cmd)
        '    adp.Fill(ds, "APP")
        '    If ds.Tables(0).Rows.Count > 0 Then
        '        grdApps.DataSource = ds.Tables(0)
        '    Else
        '        grdApps.DataSource = Nothing
        '    End If
        '    grdApps.DataBind()
        'Catch ex As Exception

        'End Try
        getApplications(Session("ROLE"), Trim(txtSearchName.Text))
    End Sub

    Protected Sub getApplications(ByVal roleID As String, cliName As String)
        Try
            Dim ds As New DataSet
            'If roleID = "4045" Or roleID = "1024" Then
            '    'cmd = New SqlCommand("select ID,CUSTOMER_NUMBER as [CUST NO.],CUSTOMER_TYPE as [TYPE],case IS_PARTIAL when 1 then RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,''))+' - PARTIALLY DISBURSED' else RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) end as NAME,CONVERT(DECIMAL(30,2),FIN_AMT) as AMOUNT,convert(varchar,CREATED_DATE,113) as 'APPLICATION DATE' from QUEST_APPLICATION where SEND_TO='1024' and STATUS<>'REJECTED' AND DISBURSE_OPTION ='RTGS' and RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) like '%" & cliName & "%' order by SURNAME asc", con)
            '    cmd = New SqlCommand("select ID,CUSTOMER_NUMBER as [CUST NO.],CUSTOMER_TYPE as [TYPE],case IS_PARTIAL when 1 then RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,''))+' - PARTIALLY DISBURSED' else RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) end as NAME,CONVERT(DECIMAL(30,2),FIN_AMT) as AMOUNT,convert(varchar,CREATED_DATE,113) as 'APPLICATION DATE' from QUEST_APPLICATION where (SEND_TO='" & roleID & "' or SEND_TO='1024') and STATUS<>'REJECTED' and RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) like '%" & cliName & "%' order by SURNAME asc", con)
            '    adp = New SqlDataAdapter(cmd)
            '    adp.Fill(ds, "APP")
            '    If ds.Tables(0).Rows.Count > 0 Then
            '        grdApps.DataSource = ds.Tables(0)
            '    Else
            '        grdApps.DataSource = Nothing
            '    End If
            '    grdApps.DataBind()
            '    'ElseIf roleID = "1024" Then
            '    '    'cmd = New SqlCommand("select ID,CUSTOMER_NUMBER as [CUST NO.],CUSTOMER_TYPE as [TYPE],case IS_PARTIAL when 1 then RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,''))+' - PARTIALLY DISBURSED' else RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) end as NAME,CONVERT(DECIMAL(30,2),FIN_AMT) as AMOUNT,convert(varchar,CREATED_DATE,113) as 'APPLICATION DATE' from QUEST_APPLICATION where SEND_TO='" & roleID & "' and STATUS<>'REJECTED' AND DISBURSE_OPTION <>'RTGS' and RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) like '%" & cliName & "%' order by SURNAME asc", con)
            '    '    cmd = New SqlCommand("select ID,CUSTOMER_NUMBER as [CUST NO.],CUSTOMER_TYPE as [TYPE],case IS_PARTIAL when 1 then RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,''))+' - PARTIALLY DISBURSED' else RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) end as NAME,CONVERT(DECIMAL(30,2),FIN_AMT) as AMOUNT,convert(varchar,CREATED_DATE,113) as 'APPLICATION DATE' from QUEST_APPLICATION where (SEND_TO='" & roleID & "' or SEND_TO='1024') and STATUS<>'REJECTED' and RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) like '%" & cliName & "%' order by SURNAME asc", con)
            '    '    'Dim ds As New DataSet
            '    '    adp = New SqlDataAdapter(cmd)
            '    '    adp.Fill(ds, "APP")
            '    '    If ds.Tables(0).Rows.Count > 0 Then
            '    '        grdApps.DataSource = ds.Tables(0)
            '    '    Else
            '    '        grdApps.DataSource = Nothing
            '    '    End If
            '    '    grdApps.DataBind()
            'Else
            '    'cmd = New SqlCommand("select ID,CUSTOMER_NUMBER as [CUST NO.],CUSTOMER_TYPE as [TYPE],case IS_PARTIAL when 1 then RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,''))+' - PARTIALLY DISBURSED' else RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) end as NAME,CONVERT(DECIMAL(30,2),FIN_AMT) as AMOUNT,convert(varchar,CREATED_DATE,113) as 'APPLICATION DATE' from QUEST_APPLICATION where SEND_TO='" & roleID & "' and STATUS<>'REJECTED' and RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) like '%" & cliName & "%' order by SURNAME asc", con)
            Dim newrole As String
            If roleID = "5049" Then
                newrole = "4041"
            Else
                newrole = roleID
            End If

            Dim cmd_addtional As String = ""
            If roleID = "4041" Then
                cmd_addtional = " and LO_ID=" & Session("ID")
            Else
                cmd_addtional = ""
            End If

            Dim cmdStr As String
            If Session("DASHBOARD") = "Overall" Then
                cmdStr = "select StageName,qa.ID,CUSTOMER_NUMBER as [CUST NO.],CUSTOMER_TYPE as [TYPE],case IS_PARTIAL when 1 then RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,''))+' - PARTIALLY DISBURSED' else RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) end as NAME,CONVERT(DECIMAL(30,2),FIN_AMT) as AMOUNT,convert(varchar,CREATED_DATE,113) as 'APPLICATION DATE' from QUEST_APPLICATION qa join	 paraapprovalstages pas on qa.SEND_TO=pas.roleid AND qa.ApprovalNumber=pas.stageorder-1 where SEND_TO='" & newrole & "' and STATUS<>'REJECTED' and RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) like '%" & cliName & "%' " & cmd_addtional & " order by SURNAME asc"
            ElseIf Session("DASHBOARD") = "Branch" Then
                cmdStr = "select StageName,qa.ID,CUSTOMER_NUMBER as [CUST NO.],CUSTOMER_TYPE as [TYPE],case IS_PARTIAL when 1 then RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,''))+' - PARTIALLY DISBURSED' else RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) end as NAME,CONVERT(DECIMAL(30,2),FIN_AMT) as AMOUNT,convert(varchar,CREATED_DATE,113) as 'APPLICATION DATE' from QUEST_APPLICATION qa join	 paraapprovalstages pas on qa.SEND_TO=pas.roleid AND qa.ApprovalNumber=pas.stageorder-1 where SEND_TO='" & newrole & "' and STATUS<>'REJECTED' and RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) like '%" & cliName & "%' " & cmd_addtional & " And BRANCH_CODE='" & Session("BRANCHCODE").ToString() & "' order by SURNAME asc"
            ElseIf Session("DASHBOARD") = "Individual" Then
                cmdStr = "select StageName,qa.ID,CUSTOMER_NUMBER as [CUST NO.],CUSTOMER_TYPE as [TYPE],case IS_PARTIAL when 1 then RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,''))+' - PARTIALLY DISBURSED' else RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) end as NAME,CONVERT(DECIMAL(30,2),FIN_AMT) as AMOUNT,convert(varchar,CREATED_DATE,113) as 'APPLICATION DATE' from QUEST_APPLICATION qa join	 paraapprovalstages pas on qa.SEND_TO=pas.roleid AND qa.ApprovalNumber=pas.stageorder-1 where SEND_TO='" & newrole & "' and STATUS<>'REJECTED' and RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) like '%" & cliName & "%' " & cmd_addtional & " And BRANCH_CODE='" & Session("BRANCHCODE").ToString() & "' order by SURNAME asc"
            Else
                cmdStr = "select StageName,qa.ID,CUSTOMER_NUMBER as [CUST NO.],CUSTOMER_TYPE as [TYPE],case IS_PARTIAL when 1 then RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,''))+' - PARTIALLY DISBURSED' else RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) end as NAME,CONVERT(DECIMAL(30,2),FIN_AMT) as AMOUNT,convert(varchar,CREATED_DATE,113) as 'APPLICATION DATE' from QUEST_APPLICATION qa join	 paraapprovalstages pas on qa.SEND_TO=pas.roleid AND qa.ApprovalNumber=pas.stageorder-1 where SEND_TO='" & newrole & "' and STATUS<>'REJECTED' and RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) like '%" & cliName & "%' " & cmd_addtional & " And BRANCH_CODE='" & Session("BRANCHCODE").ToString() & "' order by SURNAME asc"
            End If

            cmd = New SqlCommand(cmdStr, con) 'And BRANCH_CODE='"& Session("BRANCHCODE").ToString() &"' 
            'Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "APP")
            If ds.Tables(0).Rows.Count > 0 Then
                grdApps.DataSource = ds.Tables(0)
            Else
                grdApps.DataSource = Nothing
            End If
            grdApps.DataBind()

            'End If
            lblAppCount.Text = ds.Tables(0).Rows.Count
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub grdApps_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles grdApps.PageIndexChanging
        grdApps.PageIndex = e.NewPageIndex
    
           ' Dim ds As New DataSet
         ' cmd = New SqlCommand("select StageName,qa.ID,CUSTOMER_NUMBER as [CUST NO.],CUSTOMER_TYPE as [TYPE],case IS_PARTIAL when 1 then RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,''))+' - PARTIALLY DISBURSED' else 'RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) end as NAME,CONVERT(DECIMAL(30,2),FIN_AMT) as AMOUNT,convert(varchar,CREATED_DATE,113) as 'APPLICATION DATE' from QUEST_APPLICATION qa join	 paraapprovalstages pas 'on qa.SEND_TO=pas.roleid AND qa.ApprovalNumber=pas.stageorder-1 where SEND_TO='" & Session("ROLE").ToString() & "' and STATUS<>'REJECTED' and RTRIM(isnull(SURNAME,'')+' '+isnull(FORENAMES,'')) like '%" & 'txtSearchName.Text & "%' And BRANCH_CODE='"& Session("BRANCHCODE").ToString() &"' order by SURNAME asc", con)
            'Dim ds As New DataSet
           ' adp = New SqlDataAdapter(cmd)
           ' adp.Fill(ds, "APP")
           ' If ds.Tables(0).Rows.Count > 0 Then
            '    grdApps.DataSource = ds.Tables(0)
            'Else
            '    grdApps.DataSource = Nothing
           ' End If
           ' grdApps.DataBind()

            'End If
            'lblAppCount.Text = ds.Tables(0).Rows.Count
      getApplications(Session("ROLE"), Trim(txtSearchName.Text))
    End Sub

    Protected Sub grdApps_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles grdApps.RowCommand
        Try
            '
            '  Dim row As GridViewRow = DirectCast(DirectCast(e.CommandSource,Control).NamingContainer, GridViewRow)
            Dim row As GridViewRow
            ' Dim id As Integer = CInt(GridView1.DataKeys(row.RowIndex).Value)
            Try
                row = grdApps.Rows(Convert.ToInt32(e.CommandArgument))
            Catch ex As Exception
                row = CType(CType(e.CommandSource, Control).NamingContainer, GridViewRow)
            End Try

            Dim LinkButton1 As LinkButton = CType(row.FindControl("LinkButton1"), LinkButton)
            'msgbox(LinkButton1.Text)
            If e.CommandName = "Select" Then
                Dim loanID = e.CommandArgument
                'If isIndividual(loanID) Then
                '    Response.Redirect("ApplicationApproval.aspx?id=" & loanID)
                'Else
                '    Response.Redirect("ApplicationApprovalGrp.aspx?id=" & loanID)
                'End If
                'If Session("ROLE") = "1024" Or Session("ROLE") = "4045" Then
                '    Response.Redirect("LoanDisbursement.aspx?id=" & loanID)
                'End If
                'msgbox(loanID)
                If LinkButton1.Text.Contains("Disbursement") = True Then
                    Response.Redirect("LoanDisbursement.aspx?id=" & loanID, False)
                End If
            ElseIf e.CommandName = "Details" Then
                Dim loanID = e.CommandArgument
                lblDetailID.Text = loanID
                lblSessionRole.Text = Session("ROLE")
                'btnModalPopup_Click(sender, New EventArgs)
            ElseIf e.CommandName = "Application" Then
                Dim loanID = e.CommandArgument
                    If LinkButton1.Text = "Disburse" Then
                        If isIndividual(loanID) Then
                            Response.Redirect("ApplicationApproval.aspx?id=" & loanID & "&isd=1")
                        Else
                            Response.Redirect("ApplicationApprovalGrp.aspx?id=" & loanID & "&isd=1")
                        End If
                    Else
                        If isIndividual(loanID) Then
                            Response.Redirect("ApplicationApproval.aspx?id=" & loanID)
                        Else
                            Response.Redirect("ApplicationApprovalGrp.aspx?id=" & loanID)
                        End If
                    End If
                    Dim EncQuery As New BankEncryption64
                    'ViewState("Level") = EncQuery.Decrypt(Request.QueryString("lev").Replace(" ", "+"))
                    'Dim appType As String = CType(row.Cells(3), DataControlFieldCell).Text
                    'If appType = "Invoice" Then
                    'Response.Redirect("ApplicationApproval.aspx?id=" & HttpUtility.UrlEncode(EncQuery.Encrypt(loanID)) & "&lev=" & HttpUtility.UrlEncode(EncQuery.Encrypt(ViewState("Level"))))
                    'Response.Redirect("ApplicationApproval.aspx?id=" & loanID & "&lev=" & ViewState("Level"))
                    Response.Redirect("ApplicationApproval.aspx?id=" & loanID)
                    'ElseIf appType = "Cheque" Then
                    '    Response.Redirect("ApplicationChequeDiscountApproval.aspx?id=" & HttpUtility.UrlEncode(EncQuery.Encrypt(loanID)) & "&lev=" & HttpUtility.UrlEncode(EncQuery.Encrypt(ViewState("Level"))))
                    'End If
                End If
            Catch ex As Exception
                msgbox(ex.ToString)
        End Try
    End Sub

    Protected Sub grdApps_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles grdApps.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim lnk = CType(e.Row.FindControl("LinkButton1"), LinkButton)
            If Session("ROLE") = "1024" Or Session("ROLE") = "4045" Then
                lnk.Text = "Disburse"
                'ElseIf ViewState("Level") = "2" Then
                '    lnk.Text = "Appraise"
                'ElseIf ViewState("Level") = "3" Then
                '    lnk.Text = "Approve Appraisal"
                'ElseIf ViewState("Level") = "4" Then
                '    lnk.Text = "Prepare Disbursement"
                'ElseIf ViewState("Level") = "5" Then
                '    lnk.Text = "Check Disbursement"
                'ElseIf ViewState("Level") = "6" Then
                '    lnk.Text = "Send to Executive"
                'ElseIf ViewState("Level") = "7" Then
                '    lnk.Text = "Approve Disbursement"
                'ElseIf ViewState("Level") = "8" Then
                '    lnk.Text = "EFT File"
            Else
                'Response.Redirect("ApplicationApproval.aspx?id=" & HttpUtility.UrlEncode(EncQuery.Encrypt(loanID)) & "&lev=" & HttpUtility.UrlEncode(EncQuery.Encrypt(ViewState("Level"))))
            End If
        End If
    End Sub


    Protected Function isIndividual(ByVal loanID As String) As Boolean
        Dim ind As String = ""
        cmd = New SqlCommand("select CUSTOMER_TYPE from QUEST_APPLICATION where ID='" & loanID & "'", con)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        ind = cmd.ExecuteScalar
        con.Close()
        If ind = "Individual" Then
            Return True
        Else
            Return False
        End If
    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Page.MaintainScrollPositionOnPostBack = True
            con = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            If Not IsPostBack Then
                If Trim(Session("ROLE")) = "" Then
                    Response.Redirect("~/Login.aspx")
                Else
                    getApplications(Session("ROLE"), Trim(txtSearchName.Text))
                End If
                grdApps.UseAccessibleHeader = True
                grdApps.HeaderRow.TableSection = TableRowSection.TableHeader
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class