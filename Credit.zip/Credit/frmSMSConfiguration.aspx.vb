﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Net
Imports ErrorLogging

Partial Class Credit_SMS_CONFIGURATIONS
    Inherits System.Web.UI.Page
    Dim cmd As SqlCommand
    Dim adp As SqlDataAdapter
    Dim con As New SqlConnection
    Dim connection As String
    Public Shared typeEditID As Double
    Public Sub msgbox(ByVal strMessage As String)
        'finishes server processing, returns to client.
        Dim strScript As String = "<script language=JavaScript>"
        strScript += "window.alert(""" & strMessage & """);"
        strScript += "</script>"
        Dim lbl As New System.Web.UI.WebControls.Label
        lbl.Text = strScript
        Page.Controls.Add(lbl)
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True
        con = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
        If Not IsPostBack Then
            Get_Rec()
        End If
    End Sub
    Protected Sub btnUpdateConfig_Click(sender As Object, e As EventArgs) Handles btnUpdateConfig.Click
        If Rec_Exists() = True Then
            UpdateCONFIG()
        Else
            saveCONFIG()
        End If
    End Sub
    Protected Sub saveCONFIG()
        Try
            Dim DISB = chkDisb.Checked
            Dim duerep = chkDueRep.Checked
            Dim birthday = chkBirthday.Checked
            Dim loansettl = chkloanSettlmnt.Checked
            Dim staticDet = chkstaticdetail.Checked
            Dim pastdue = chkpastDue.Checked
            Dim onRepay = chkonRepayments.Checked
            cmd = New SqlCommand("insert into SMSCONFIG (OnRepayments,Disbursement, DueRepayment, Birthday, LoanSettlement, StaticDetail, PastDuePayments) values('" & onRepay & "','" & DISB & "','" & duerep & "','" & birthday & "','" & loansettl & "','" & staticDet & "','" & pastdue & "')", con)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            Get_Rec()
            msgbox("SMS Configuration Saved")
        Catch ex As Exception
            msgbox(ex.Message.ToString)
        End Try
    End Sub
    Protected Sub UpdateCONFIG()
        Try
            Dim DISB = chkDisb.Checked
            Dim duerep = chkDueRep.Checked
            Dim birthday = chkBirthday.Checked
            Dim loansettl = chkloanSettlmnt.Checked
            Dim staticDet = chkstaticdetail.Checked
            Dim pastdue = chkpastDue.Checked
            Dim onRepay = chkonRepayments.Checked
            cmd = New SqlCommand("UPDATE SMSCONFIG SET OnRepayments='" & onRepay & "',Disbursement='" & DISB & "', DueRepayment='" & duerep & "', Birthday='" & birthday & "', LoanSettlement='" & loansettl & "', StaticDetail='" & staticDet & "',PastDuePayments='" & pastdue & "'", con)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            Get_Rec()
            msgbox("SMS Configuration Updated")
        Catch ex As Exception
            msgbox(ex.Message.ToString)
        End Try
    End Sub
    Protected Function Rec_Exists() As Boolean
        Try
            cmd = New SqlCommand("select * from SMSCONFIG", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "SMSCONFIG")
            If ds.Tables(0).Rows.Count > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            msgbox(ex.Message.ToString)
            Return False
        End Try
    End Function
    Protected Sub Get_Rec()
        Try
            cmd = New SqlCommand("select * from SMSCONFIG", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "SMSCONFIG")
            If ds.Tables(0).Rows.Count > 0 Then
                Dim dr As DataRow = ds.Tables(0).Rows(0)
                chkBirthday.Checked = CBool(dr.Item("Birthday"))
                chkDisb.Checked = CBool(dr.Item("Disbursement"))
                chkDueRep.Checked = CBool(dr.Item("DueRepayment"))
                chkloanSettlmnt.Checked = CBool(dr.Item("LoanSettlement"))
                chkpastDue.Checked = CBool(dr.Item("PastDuePayments"))
                chkstaticdetail.Checked = CBool(dr.Item("StaticDetail"))
                chkonRepayments.Checked = CBool(dr.Item("OnRepayments"))
            Else

            End If
        Catch ex As Exception
            msgbox(ex.Message.ToString)
        End Try
    End Sub
    Protected Sub btnBroadcast_Click(sender As Object, e As EventArgs) Handles btnBroadcast.Click
        SendHappyBirthdaySMS()
    End Sub
    Public Sub SendHappyBirthdaySMS()
        FetchTodayRecords()
        Try
            Using cmd As New SqlCommand("Select * from Broadcast_Messages where SMS_Sent =0", con)
                Using adp As New SqlDataAdapter(cmd)
                    Dim ds As New DataSet
                    adp.Fill(ds, "Assets")
                    If ds.Tables(0).Rows.Count > 0 Then
                        For Each dr As DataRow In ds.Tables(0).Rows
                            Dim sms_message As String = ""
                            Dim Mobile_no As String = ""
                            Dim CustNo_ As String = ""
                            Mobile_no = dr.Item("Mobile_Number").ToString
                            sms_message = dr.Item("ClientMessage").ToString

                            CustNo_ = dr.Item("Customer_Number").ToString
                            If Mobile_no.Contains("/") Then
                                Dim word As String
                                For Each word In GetSeparateNumbers(Mobile_no)
                                    'If SendSMS(sms_message, word).Contains("00") Then
                                    UpdateSMSSent(Mobile_no, CustNo_, SendSMS(sms_message, word))
                                    'End If
                                Next
                            Else
                                'If SendSMS(sms_message, Mobile_no).Contains("00") Then
                                UpdateSMSSent(Mobile_no, CustNo_, SendSMS(sms_message, Mobile_no))
                                ' End If
                            End If
                        Next
                    End If
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub
    Function GetSeparateNumbers(theOrgNum As String) As String()
        ' We want to split this input string.
        Dim s As String = theOrgNum

        ' Split string based on spaces.
        Dim words As String() = s.Split(New Char() {"/"c})

        ' Use For Each loop over words and display them.
        Dim word As String
        'For Each word In words
        '    testWrite(word)
        'Next
        Return words
    End Function
    Function sendTestMessageToCosta() As String
        Dim word As String
        Dim bltstr = ""
        'For Each word In GetSeparateNumbers("260967517320/260977899379")
        'For Each word In GetSeparateNumbers("260977964096")
        Dim tyt = SendSMS("To All Our Valued Clients, All our branches will be closed at 12:00Hrs due to the new year celebrations. We will resume normal working hours on 3rd January 2017. We wish you a very successful 2017. GoodFellow Distributors Ltd.", "260977964096")
        '  bltstr = bltstr & tyt
        '  Next
        ' Dim rtstr = SendSMS("test double Number....HI there, this is a test message on " & Date.Now.ToString("dd MMMM yyyy hh:mm:ss"), "260967517320/260977899379")
        Return bltstr
    End Function
    Sub UpdateSMSSent(ByVal mobile As String, ByVal custNo As String, ByVal reply As String)
        Try
            Using cmd As New SqlCommand("update Broadcast_Messages set SMS_Sent=1,DateSent=GETDATE(),Reply='" & reply.Replace("'", "") & "' WHERE Customer_Number='" & custNo & "' AND Mobile_Number='" & mobile & "'", con)
                cmd.CommandType = CommandType.Text
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub
    Public Sub FetchTodayRecords()
        Try
            Using cmd As New SqlCommand("insert into Broadcast_Messages(Customer_Number,ClientMessage, DateCreated,Mobile_Number) Select CUSTOMER_NUMBER,'Goodfellow wishes you a Merry Christmas!!',GETDATE(),PHONE_NO from customer_details where CUSTOMER_NUMBER NOT IN (Select b.Customer_Number from Broadcast_Messages b)", con)
                cmd.CommandType = CommandType.Text
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub
    Private Function SendSMS(ByVal strMsg As String, ByVal MobNo As String) As String
        Dim SmsStatusMsg As String = String.Empty
        Try
            'Sending SMS To User
            Dim client As WebClient = New WebClient()
            Dim URL As String = "http://www.savannacom.zm/smsservices/bms_dot_php_third_party_api.php?customerid=149&from=gfdl&to=" & MobNo.Replace(" ", "") & "&message=" & strMsg & ""

            SmsStatusMsg = client.DownloadString(URL)
            If SmsStatusMsg.Contains("<br>") Then
                SmsStatusMsg = SmsStatusMsg.Replace("<br>", ", ")
            End If

        Catch e1 As WebException
            SmsStatusMsg = e1.Message
            WriteLogFile(e1.ToString)
        Catch e2 As Exception
            SmsStatusMsg = e2.Message
            WriteLogFile(e2.ToString)
        End Try
        Return SmsStatusMsg
    End Function


    'send other messages
    Public Sub Send_Other_SMS()
        Fetch_Other_Records()
        Try
            Using cmd As New SqlCommand("Select * from Other_Messages where SMS_Sent =0", con)
                Using adp As New SqlDataAdapter(cmd)
                    Dim ds As New DataSet
                    adp.Fill(ds, "Assets")
                    If ds.Tables(0).Rows.Count > 0 Then
                        For Each dr As DataRow In ds.Tables(0).Rows
                            Dim sms_message As String = ""
                            Dim Mobile_no As String = ""
                            Dim CustNo_ As String = ""
                            Mobile_no = dr.Item("Mobile_Number").ToString
                            sms_message = dr.Item("ClientMessage").ToString

                            CustNo_ = dr.Item("Customer_Number").ToString
                            If Mobile_no.Contains("/") Then
                                Dim word As String
                                For Each word In GetSeparateNumbers(Mobile_no)
                                    'If SendSMS(sms_message, word).Contains("00") Then
                                    Update_Other_SMSSent(Mobile_no, CustNo_, SendSMS(sms_message, word))
                                    'End If
                                Next
                            Else
                                'If SendSMS(sms_message, Mobile_no).Contains("00") Then
                                Update_Other_SMSSent(Mobile_no, CustNo_, SendSMS(sms_message, Mobile_no))
                                ' End If
                            End If
                        Next
                    End If
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub
    Sub Update_Other_SMSSent(ByVal mobile As String, ByVal custNo As String, ByVal reply As String)
        Try
            Using cmd As New SqlCommand("update Other_Messages set SMS_Sent=1,DateSent=GETDATE(),Reply='" & reply.Replace("'", "") & "' WHERE Customer_Number='" & custNo & "' AND Mobile_Number='" & mobile & "'", con)
                cmd.CommandType = CommandType.Text
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub
    Public Sub Fetch_Other_Records()
        Try
            ' Using cmd As New SqlCommand("insert into Other_Messages(Customer_Number,ClientMessage, DateCreated,Mobile_Number) Select CUSTOMER_NUMBER,'You''re kindly advised that our DDACs were sent on Friday.As per Boz rules they will be effected on Tuesday morning.Please do not remove all your money as the system will charge you K510 for insufficient funds .Thank you',GETDATE(),PHONE_NO from QUEST_APPLICATION where CUSTOMER_NUMBER NOT IN (Select b.Customer_Number from Other_Messages b) and bank in ('Stanbic','Investrust','znbs','FNB','INDO BANK','CAVMONT','STANCHART','FBZ')", con)
            ' Using cmd As New SqlCommand("insert into Other_Messages(Customer_Number,ClientMessage, DateCreated,Mobile_Number) Select CUSTOMER_NUMBER,'You Are Requested To Withdraw Money From Your Account And Pay Cash to any of our branches. Our System Did Not Deduct From Your Bank. Failure To Pay Will Attract Interest For Next Month. If you have already paid using cash or Payroll, ignore this message. GoodFellow Distributors Ltd.',GETDATE(),PHONE_NO from QUEST_APPLICATION where bank in ('znbs')", con)
            Using cmd As New SqlCommand("insert into Other_Messages(Customer_Number,ClientMessage, DateCreated,Mobile_Number) Select CUSTOMER_NUMBER,'To All Our Valued Clients, All our branches will be closed at 12:00Hrs due to the new year celebrations. We will resume normal working hours on 3rd January 2017. We wish you a very successful 2017. GoodFellow Distributors Ltd.',GETDATE(),PHONE_NO from CUSTOMER_DETAILS", con)
                cmd.CommandType = CommandType.Text
                If con.State = ConnectionState.Open Then con.Close()
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        Catch ex As Exception
            WriteLogFile(ex.ToString)
        End Try
    End Sub
    Protected Sub btnsecBroadcast_Click(sender As Object, e As EventArgs) Handles btnsecBroadcast.Click
        Send_Other_SMS()
        ' msgbox(sendTestMessageToCosta())
    End Sub
End Class
