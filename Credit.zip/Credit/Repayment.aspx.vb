﻿Imports System.Data
Imports System.Data.SqlClient
Imports CreditManager
Imports ErrorLogging
Imports BankString
Imports System.Xml
Imports System.Net

Partial Class Credit_Repayment
    Inherits System.Web.UI.Page

    Protected Shared Function getLastRepaymentDate(loanId As String) As String
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            'Using cmd As New SqlCommand("select isnull(rep.TrxnDate,act.DISBURSED_DATE) as TrxnDate from QUEST_APPLICATION act left join Repayments rep on rep.[LoanID]=act.ID where act.[ID]='" + loanId + "' order by TrxnDate desc", con)
            Using cmd As New SqlCommand("select isnull(rep.TrxnDate,'') as TrxnDate from Repayments rep where rep.[LoanID]='" + loanId + "' order by TrxnDate desc", con)
                Dim ds As New DataSet
                Dim adp As New SqlDataAdapter(cmd)
                adp.Fill(ds, "FUN")
                If ds.Tables(0).Rows.Count > 0 Then
                    Return ds.Tables(0).Rows(0).Item("TrxnDate").ToString
                Else
                    Return ""
                End If
            End Using
        End Using
    End Function

    Protected Sub allocateRepayment(order1 As String, order2 As String, order3 As String, order4 As String, amtPaid As Double, expPrincipal As Double, expInterest As Double, expPenalty As Double, expFees As Double)
        Try
            Dim remBalance As Double = amtPaid
            If order1 = "Principal" Then
                If remBalance > expPrincipal Then
                    ViewState("PrincipalPaid") = expPrincipal
                    remBalance = remBalance - expPrincipal
                Else
                    ViewState("PrincipalPaid") = remBalance
                End If
            ElseIf order1 = "Interest" Then
                If remBalance > expInterest Then
                    ViewState("InterestPaid") = expInterest
                    remBalance = remBalance - expInterest
                Else
                    ViewState("InterestPaid") = remBalance
                End If
            ElseIf order1 = "Fees" Then
                If remBalance > expFees Then
                    ViewState("FeesPaid") = expFees
                    remBalance = remBalance - expFees
                Else
                    ViewState("FeesPaid") = remBalance
                End If
            ElseIf order1 = "Penalties" Then
                If remBalance > expPenalty Then
                    ViewState("PenaltiesPaid") = expPenalty
                    remBalance = remBalance - expPenalty
                Else
                    ViewState("PenaltiesPaid") = remBalance
                End If
            End If
            If order2 = "Principal" Then
                If remBalance > expPrincipal Then
                    ViewState("PrincipalPaid") = expPrincipal
                    remBalance = remBalance - expPrincipal
                Else
                    ViewState("PrincipalPaid") = remBalance
                End If
            ElseIf order2 = "Interest" Then
                If remBalance > expInterest Then
                    ViewState("InterestPaid") = expInterest
                    remBalance = remBalance - expInterest
                Else
                    ViewState("InterestPaid") = remBalance
                End If
            ElseIf order2 = "Fees" Then
                If remBalance > expFees Then
                    ViewState("FeesPaid") = expFees
                    remBalance = remBalance - expFees
                Else
                    ViewState("FeesPaid") = remBalance
                End If
            ElseIf order2 = "Penalties" Then
                If remBalance > expPenalty Then
                    ViewState("PenaltiesPaid") = expPenalty
                    remBalance = remBalance - expPenalty
                Else
                    ViewState("PenaltiesPaid") = remBalance
                End If
            End If
            If order3 = "Principal" Then
                If remBalance > expPrincipal Then
                    ViewState("PrincipalPaid") = expPrincipal
                    remBalance = remBalance - expPrincipal
                Else
                    ViewState("PrincipalPaid") = remBalance
                End If
            ElseIf order3 = "Interest" Then
                If remBalance > expInterest Then
                    ViewState("InterestPaid") = expInterest
                    remBalance = remBalance - expInterest
                Else
                    ViewState("InterestPaid") = remBalance
                End If
            ElseIf order3 = "Fees" Then
                If remBalance > expFees Then
                    ViewState("FeesPaid") = expFees
                    remBalance = remBalance - expFees
                Else
                    ViewState("FeesPaid") = remBalance
                End If
            ElseIf order3 = "Penalties" Then
                If remBalance > expPenalty Then
                    ViewState("PenaltiesPaid") = expPenalty
                    remBalance = remBalance - expPenalty
                Else
                    ViewState("PenaltiesPaid") = remBalance
                End If
            End If
            If order4 = "Principal" Then
                If remBalance > expPrincipal Then
                    ViewState("PrincipalPaid") = expPrincipal
                    remBalance = remBalance - expPrincipal
                Else
                    ViewState("PrincipalPaid") = remBalance
                End If
            ElseIf order4 = "Interest" Then
                If remBalance > expInterest Then
                    ViewState("InterestPaid") = expInterest
                    remBalance = remBalance - expInterest
                Else
                    ViewState("InterestPaid") = remBalance
                End If
            ElseIf order4 = "Fees" Then
                If remBalance > expFees Then
                    ViewState("FeesPaid") = expFees
                    remBalance = remBalance - expFees
                Else
                    ViewState("FeesPaid") = remBalance
                End If
            ElseIf order4 = "Penalties" Then
                If remBalance > expPenalty Then
                    ViewState("PenaltiesPaid") = expPenalty
                    remBalance = remBalance - expPenalty
                Else
                    ViewState("PenaltiesPaid") = remBalance
                End If
            End If
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- allocateRepayment()", ex.ToString)
        End Try
    End Sub
    Protected Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            If Trim(txtCustNo.Text) = "" Then
                notify("Enter the customer number", "error")
                txtCustNo.Focus()
            ElseIf Not IsNumeric(txtAmtPaid.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", "")) Then
                notify("Enter numeric value for total amount", "error")
                txtAmtPaid.Text = "0"
                txtAmtPaid.Focus()
                'ElseIf Not IsNumeric(txtCapital.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", "")) Then
                '    notify("Enter numeric value for capital amount", "error")
                '    txtCapital.Text = "0"
                '    txtCapital.Focus()
                'ElseIf Not IsNumeric(txtInterest.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", "")) Then
                '    notify("Enter numeric value for interest", "error")
                '    txtInterest.Text = "0"
                '    txtInterest.Focus()
                'ElseIf Not IsNumeric(txtPenalty.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", "")) Then
                '    notify("Enter numeric value for penalty amount", "error")
                '    txtPenalty.Text = "0"
                '    txtPenalty.Focus()
                'ElseIf CDbl(txtAmtPaid.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", "")) <> CDbl(txtCapital.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", "")) + CDbl(txtInterest.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", "")) + CDbl(txtPenalty.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", "")) Then
                '    notify("Total amount paid must be equal to Capital + Interest + Penalty", "error")
            ElseIf CDbl(txtAmtPaid.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", "").Replace("ZMW", "")) <= 0 Then
                notify("Enter numeric value for total amount", "error")
                txtAmtPaid.Text = "0"
                txtAmtPaid.Focus()
            ElseIf Not IsDate(txtRepaymentDate.Text) Then
                notify("Enter valid repayment date", "error")
                txtRepaymentDate.Focus()
            Else
                saveRepayment()
                'notify("Capital saving", "information")
                saveTransaction(ViewState("globLoanID"), "Capital Repayment", txtAmtPaid.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", ""), 0, "LO/" & Session("ID").ToString(), txtCustNo.Text, "1", "Cash Receipting " & Session("UserID"), "", "", "", txtRepaymentDate.Text)
                UpdateAllRepaidLoans()
                'send SMS=----------------------------------------------------------------------------------
                Try
                    If Send_SMSon_Repayment() = True Then
                        Dim mob_number As String = getCustMobile(txtCustNo.Text)
                        WriteLogFile(Session("UserID"), "Repayment.aspx", SendSMS("We have received a repayment of ZMW" & txtAmtPaid.Text & " from you, thank you for your committment, GOODFELLOW DISTRIBUTORS LIMITED", mob_number))
                    End If
                Catch ex As Exception

                End Try
                'send SMS=----------------------------------------------------------------------------------
                'If toMoney(txtPenalty.Text) > 0 Then
                '    'notify("Penalty saving", "information")
                '    saveTransaction(ViewState("globLoanID"), "Penalty Charged", txtPenalty.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", ""), 0, "PenaltyReceivable", txtCustNo.Text, "1", "", "", "", "", txtRepaymentDate.Text)  
                '    saveTransaction(ViewState("globLoanID"), "Penalty Repayment", txtPenalty.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", ""), 0, txtCustNo.Text, cmbPenaltyAccount.SelectedValue, "1", "", "", "", "", txtRepaymentDate.Text)
                'End If
                'If txtInterest.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", "") > 0 Then
                '    ' notify("Interest saving", "information")
                '    saveTransaction(ViewState("globLoanID"), "Interest Repayment", txtInterest.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", ""), 0, cmbInterestAccount.SelectedValue, txtCustNo.Text, "1", "", "", "", "", txtRepaymentDate.Text)
                'End If
                'PayLoanOfficer()

                Response.Write("<script>alert('Repayment saved') ; location.href='Repayment.aspx'</script>")
            End If
            'Credit the loan officer after repayment
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- btnSave_Click()", ex.ToString)
        End Try
    End Sub
    Private Function getCustMobile(custNo As String) As String
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Dim cmd = New SqlCommand("select * from customer_details where Customer_number='" & custNo & "'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "appForm")
            If ds.Tables(0).Rows.Count > 0 Then
                Dim dr As DataRow = ds.Tables(0).Rows(0)
                Return dr.Item("PHONE_NO").ToString
            Else
                Return "260"
            End If
        End Using
    End Function
    Private Function SendSMS(ByVal strMsg As String, ByVal MobNo As String) As String
        Dim SmsStatusMsg As String = String.Empty
        Try
            'Sending SMS To User
            Dim client As WebClient = New WebClient()
            Dim URL As String = "http://www.savannacom.zm/smsservices/bms_dot_php_third_party_api.php?customerid=149&from=gfdl&to=" & MobNo & "&message=" & strMsg & ""

            SmsStatusMsg = client.DownloadString(URL)
            If SmsStatusMsg.Contains("<br>") Then
                SmsStatusMsg = SmsStatusMsg.Replace("<br>", ", ")
            End If

        Catch e1 As WebException
            SmsStatusMsg = e1.Message
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- SendSMS_Click()", e1.ToString)
            ' testWrite(e1.ToString)
        Catch e2 As Exception
            SmsStatusMsg = e2.Message
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- SendSMS_Click()", e2.ToString)
            'testWrite(e2.ToString)
        End Try
        Return SmsStatusMsg
    End Function
    Private Function Send_SMSon_Repayment() As Boolean
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Dim cmd = New SqlCommand("select * from SMSCONFIG", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "appForm")
            If ds.Tables(0).Rows.Count > 0 Then
                Dim dr As DataRow = ds.Tables(0).Rows(0)
                If CBool(dr.Item("OnRepayments")) = True Then
                    Return True
                Else
                    Return False
                End If
            Else
                Return False
            End If
        End Using
    End Function
    Public Sub PayLoanOfficer()
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Using cmd As New SqlCommand("insert into Accounts_Transactions(Type,Category,TrxnDate,Account,Refrence,Description,Debit,Credit,ContraAccount,CostCode,Status,Other,Committed,BatchRef,CaptureDate) values('System Entry','Loan Repayment',GETDATE(), 'LO/'+ CONVERT(VARCHAR,'" & Session("ID").ToString() & "'),'" & txtLoanID.Text & "','Loan Repayment','" & txtAmtPaid.Text & "','0', 'LO/'+ CONVERT(VARCHAR,'" & Session("ID").ToString() & "'),'','1','','','Rep10001',GETDATE())", con)
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub
    Protected Sub btnSearchName_Click(sender As Object, e As EventArgs) Handles btnSearchName.Click
        'populate listbox
        Try
            Using cmd As New SqlCommand("Select id,isnull([SURNAME],' ') + ' ' + isnull([FORENAMES],' ') + ' - ' + isnull([CUSTOMER_NUMBER],' ') + ' - ' + convert(varchar,isnull([CREATED_DATE],' '),106) + ' - ' + isnull(FORMAT([FIN_AMT],'c'),' ') as [Name] FROM [QUEST_APPLICATION] where (isnull([SURNAME],'') like '%" & txtApplicantName.Text & "%' or isnull(FORENAMES,'') like '%" & txtApplicantName.Text & "%') and [STATUS]='Disbursed'")
                'msgbox(cmd.CommandText)
                cmd.CommandType = CommandType.Text
                Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                    cmd.Connection = con
                    Dim ds As New DataSet
                    Dim adp As New SqlDataAdapter(cmd)
                    adp.Fill(ds, "FUN")
                    If ds.Tables(0).Rows.Count > 0 Then
                        lstLoans.DataSource = ds.Tables(0)
                        lstLoans.DataTextField = "Name"
                        lstLoans.DataValueField = "id"
                        lstLoans.Visible = True
                    Else
                        lstLoans.DataSource = Nothing
                        lstLoans.Visible = False
                    End If
                    lstLoans.DataBind()
                    clearLoanDetails()
                    'cmbFSP.ClearSelection()
                    txtLoanID.Text = ""
                    ViewState("globLoanID") = "0"
                    txtCustNo.Text = ""
                    clearLoanDetails()
                    txtInterest.Text = ""
                    lblCurrentInterestBalance.Text = ""
                    lblCurrentLoanBalance.Text = ""
                    lblTotalCapitalRepayment.Text = ""
                    grdRepaymentHistory.DataSource = Nothing
                    grdRepaymentHistory.DataBind()
                End Using
            End Using
        Catch ex As Exception
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- btnSearchName_Click", ex.ToString)
        End Try
    End Sub

    Protected Sub btnSearchVCAID_Click(sender As Object, e As EventArgs) Handles btnSearchVCAID.Click
        Try
            displayLoanDetails(txtLoanID.Text)
        Catch ex As Exception
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- btnSearchVCAID_Click", ex.ToString)
        End Try
    End Sub

    Protected Function calculateInterestDue(disbDate As String, firstPayDate As String, lastPayDate As String, calcDate As String, principalBal As Decimal, interestRate As Decimal) As Decimal
        Try
            'msgbox("in")
            Dim noDays As Decimal = 0
            Dim monthDays As Decimal = 30 'default value
            Dim intDue As Decimal = 0
            If lastPayDate = "" Then
                'no payment made yet
                'if calculation date less than firstPayDate then expected interest is less
                'else it is greater
                If CDate(calcDate) <= CDate(firstPayDate) Then
                    'monthDays = DateDiff(DateInterval.Day, CDate(disbDate), CDate(firstPayDate))
                    noDays = DateDiff(DateInterval.Day, CDate(disbDate), CDate(calcDate))
                Else
                    'get 100% interest upto firstPayDate then calculate subsequent interest on 30-day month
                    intDue = principalBal * (interestRate / 100)
                    noDays = DateDiff(DateInterval.Day, CDate(firstPayDate), CDate(calcDate))
                End If
            Else
                'some repayment made before
                noDays = DateDiff(DateInterval.Day, CDate(lastPayDate), CDate(calcDate))
            End If
            Dim dayFrac = noDays / monthDays
            Dim intRate = interestRate / 100
            intDue = intDue + (dayFrac * principalBal * intRate)
            Return intDue
        Catch ex As Exception
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- calculateInterestDue()", ex.ToString)
        End Try
    End Function

    Protected Sub clearLoanDetails()
        loanDets.Visible = False
        lblDisbDate.Text = ""
        lblInterestAmount.Text = ""
        lblInterestUpfront.Text = ""
        lblLoanAmount.Text = ""
        lblTenure.Text = ""
        lblNetAmount.Text = ""
    End Sub

    Protected Sub displayLoanDetails(vca As String)
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd As New SqlCommand("Select *,convert(nvarchar,[DISBURSED_DATE],106) as DisburseDate1,convert(nvarchar,[FIN_REPAY_DATE],106) as FIN_REPAY_DATE1,convert(nvarchar,MaturityDate,106) as MaturityDate1 FROM [QUEST_APPLICATION] where id='" & vca & "' and [STATUS]='Disbursed'", con)
                    'fillAppForm(vca)
                    cmd.CommandType = CommandType.Text
                    Dim ds As New DataSet
                    Dim adp As New SqlDataAdapter(cmd)
                    adp.Fill(ds, "VCA")
                    clearLoanDetails()
                    If ds.Tables(0).Rows.Count > 0 Then
                        Dim dr As DataRow = ds.Tables(0).Rows(0)
                        txtApplicantName.Text = isNullString(dr.Item("SURNAME")) + " " + isNullString(dr.Item("FORENAMES"))
                        txtLoanID.Text = isNullString(dr.Item("ID"))
                        ViewState("globLoanID") = isNullString(dr.Item("ID"))
                        txtCustNo.Text = isNullString(dr.Item("CUSTOMER_NUMBER"))
                        getProductOptions(dr.Item("FinProductType"))
                        loanDets.Visible = True
                        Try
                            lblLoanAmount.Text = FormatNumber(isNullString(dr.Item("FIN_AMT")), 2)
                            'lblLoanAmount.Text = FormatCurrency(200)
                        Catch ex As Exception

                        End Try
                        Try
                            lblDisbDate.Text = isNullString(dr.Item("DisburseDate1"))
                        Catch ex As Exception

                        End Try
                        Try
                            lblTenure.Text = FormatNumber(isNullString(dr.Item("FIN_TENOR")), 0)
                        Catch ex As Exception

                        End Try
                        Try
                            lblInterestRate.Text = FormatNumber(isNullString(dr.Item("FIN_INT_RATE")), 2)
                        Catch ex As Exception

                        End Try
                        Try
                            lblRepayDate.Text = isNullString(dr.Item("FIN_REPAY_DATE1"))
                        Catch ex As Exception

                        End Try
                        Try
                            lblInterestAmount.Text = FormatNumber(getInterestToMaturity(txtCustNo.Text, ViewState("globLoanID")), 2) ' FormatCurrency(isNullString(dr.Item("IntAmt")))
                        Catch ex As Exception

                        End Try

                        lblInterestUpfront.Text = 0 ' FormatCurrency(isNullString(dr.Item("InterestUpfront")))
                        lblNetAmount.Text = lblLoanAmount.Text ' FormatCurrency(isNullString(dr.Item("NetAmount")))
                        Try
                            lblLastRepayDate.Text = Convert.ToDateTime(getLastRepaymentDate(vca)).ToString("dd/MM/yyyy")
                        Catch ex As Exception

                        End Try

                        ' txtInterest.Text = lblInterestAmount.Text - lblInterestUpfront.Text
                        Try
                            loadPrevRepayments(vca)
                        Catch ex As Exception

                        End Try
                        Try
                            loadAmortization(vca)
                        Catch ex As Exception

                        End Try
                        Try
                            getCurrentLoanBalance()
                        Catch ex As Exception

                        End Try
                        Try
                            getCurrentBalances(vca, txtRepaymentDate.Text)
                        Catch ex As Exception

                        End Try

                        'txtInterest.Text = FormatCurrency(calculateInterestDue(lblDisbDate.Text, lblRepayDate.Text, lblLastRepayDate.Text, txtRepaymentDate.Text, lblCurrentLoanBalance.Text.Replace("US", "").Replace("$", ""), lblInterestRate.Text))
                    Else
                        'cmbFSP.ClearSelection()
                        txtLoanID.Text = ""
                        ViewState("globLoanID") = "0"
                        txtCustNo.Text = ""
                        txtApplicantName.Text = ""
                        clearLoanDetails()
                        txtInterest.Text = ""
                        'loadPrevRepayments(vca)
                        grdRepaymentHistory.DataSource = Nothing
                        grdRepaymentHistory.DataBind()
                        lblCurrentInterestBalance.Text = ""
                        lblCurrentLoanBalance.Text = ""
                        lblTotalCapitalRepayment.Text = ""
                        'txtPastelInterest.Text = ""
                        notify("Loan not found or already repaid", "error")
                    End If
                End Using
            End Using
        Catch ex As Exception
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- displayLoanDetails()", ex.ToString)
        End Try
    End Sub

    Protected Sub fillAppForm(VCAId As String)
        Try
            Using cmd As New SqlCommand("Select *,convert(nvarchar,DateOfRegistration,106) as DateOfRegistration1 FROM VCAApplication where ID='" & VCAId & "'")
                cmd.CommandType = CommandType.Text
                Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                    cmd.Connection = con
                    Dim ds As New DataSet
                    Dim adp As New SqlDataAdapter(cmd)
                    adp.Fill(ds, "VCA")
                    If ds.Tables(0).Rows.Count > 0 Then
                        Dim dr As DataRow = ds.Tables(0).Rows(0)
                        txtApplicantName.Text = isNullString(dr.Item("Name"))
                        txtLoanID.Text = isNullString(dr.Item("ID"))
                        txtCustNo.Text = isNullString(dr.Item("NationalRegNo"))
                    Else

                    End If
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- fillAppForm()", ex.ToString)
        End Try
    End Sub

    Protected Sub getCurrentBalances(vca As Double, dat As String)
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            'Using cmd As New SqlCommand("select top 1 * from AMORTIZATION_SCHEDULE_DAILY where loanid='" & vca & "' and DAY_DATE<='" & dat & "' order by DAY_DATE desc", con)
            Using cmd As New SqlCommand("select top 1 * from AMORTIZATION_SCHEDULE where loanid='" & vca & "' and PAYMENT_DATE<='" & dat & "' order by PAYMENT_DATE desc", con)
                Dim ds As New DataSet
                Dim adp As New SqlDataAdapter(cmd)
                adp.Fill(ds, "FUN")
                If ds.Tables(0).Rows.Count > 0 Then
                    Dim dr = ds.Tables(0).Rows(0)
                    Try
                        lblCapitalRepaymentDue.Text = FormatCurrency(dr.Item("CUMULATIVE_PRINCIPAL"))
                    Catch ex As Exception
                        lblCapitalRepaymentDue.Text = ""
                    End Try
                    Try
                        lblInterestRepaymentDue.Text = FormatCurrency(dr.Item("CUMULATIVE_INTEREST"))
                    Catch ex As Exception
                        lblInterestRepaymentDue.Text = ""
                    End Try
                    lblPenaltyChargesAccrued.Text = ""
                    lblEarlyRepaymentDeduction.Text = ""
                    lblTotalRepaymentDue.Text = ""
                Else
                    lblCapitalRepaymentDue.Text = 0
                    lblInterestRepaymentDue.Text = 0
                    lblPenaltyChargesAccrued.Text = 0
                    lblEarlyRepaymentDeduction.Text = 0
                    lblTotalRepaymentDue.Text = 0
                End If
            End Using
        End Using
    End Sub

    Protected Sub getCurrentLoanBalance()
        Try
            lblCurrentLoanBalance.Text = ""
            lblTotalCapitalRepayment.Text = ""
            Dim TotCapRepay = 0
            Dim TotIntRepay = 0
            For Each row As GridViewRow In grdRepaymentHistory.Rows
                TotCapRepay = TotCapRepay + CDbl(row.Cells(2).Text.Replace("$", "").Replace(",", ""))
                TotIntRepay = TotIntRepay + CDbl(row.Cells(4).Text.Replace("$", "").Replace(",", ""))
            Next
            lblTotalCapitalRepayment.Text = FormatNumber(TotCapRepay, 2)
            lblCurrentLoanBalance.Text = FormatNumber(lblLoanAmount.Text.Replace("US$", "").Replace(",", "") - TotCapRepay, 2)

            lblCurrentInterestBalance.Text = FormatNumber(toMoney(lblInterestAmount.Text) - toMoney(lblInterestUpfront.Text) - toMoney(TotIntRepay), 2)
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- getCurrentLoanBalance()", ex.ToString)
        End Try
    End Sub

    Protected Function getInterestToMaturity(custNo As String, loanID As String) As String
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            'Using cmd As New SqlCommand("select sum(debit) as Interest from Accounts_Transactions act where Description='Interest to Maturity' and Account='" + custNo + "' and Refrence='" + loanID + "'", con)
            Using cmd As New SqlCommand("SELECT MAX(CUMULATIVE_INTEREST) as Interest FROM AMORTIZATION_SCHEDULE WHERE LOANID='" + loanID + "'", con)
                Dim ds As New DataSet
                Dim adp As New SqlDataAdapter(cmd)
                adp.Fill(ds, "FUN")
                If ds.Tables(0).Rows.Count > 0 Then
                    Return ds.Tables(0).Rows(0).Item("Interest").ToString
                Else
                    Return "0"
                End If
            End Using
        End Using
    End Function

    Protected Sub getProductOptions(prodID As String)
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("SELECT * FROM creditproducts where id='" & prodID & "'", con)
                    Dim dt As New DataTable
                    Using adp As New SqlDataAdapter(cmd)
                        adp.Fill(dt)
                    End Using
                    If dt.Rows.Count > 0 Then
                        Dim dr = dt.Rows(0)
                        ViewState("RepayOrder1") = dr("RepayOrder1")
                        ViewState("RepayOrder2") = dr("RepayOrder2")
                        ViewState("RepayOrder3") = dr("RepayOrder3")
                        ViewState("RepayOrder4") = dr("RepayOrder4")
                    End If
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- getProductOptions()", ex.ToString)
        End Try
    End Sub
    Protected Sub insertInterestAccountsTemp(loanID As String)
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Using cmd = New SqlCommand("SaveAccountsTrxnsTempWithContra", con)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@Type", "System Entry")
                cmd.Parameters.AddWithValue("@Category", "Loan Repayment")
                cmd.Parameters.AddWithValue("@Ref", loanID)
                cmd.Parameters.AddWithValue("@Desc", "Interest Repayment")
                cmd.Parameters.AddWithValue("@Debit", 0)
                cmd.Parameters.AddWithValue("@Credit", toMoney(txtInterest.Text))
                'cmd.Parameters.AddWithValue("@Account", "213/1")
                cmd.Parameters.AddWithValue("@Account", txtCustNo.Text)
                'cmd.Parameters.AddWithValue("@ContraAccount", cmbInterestAccount.SelectedValue)
                cmd.Parameters.AddWithValue("@Status", 1)
                'cmd.Parameters.AddWithValue("@Other", txtCustNo.Text)
                cmd.Parameters.AddWithValue("@Other", "")
                cmd.Parameters.AddWithValue("@BankAccID", "")
                cmd.Parameters.AddWithValue("@BankAccName", "")
                cmd.Parameters.AddWithValue("@BatchRef", "")
                cmd.Parameters.AddWithValue("@TrxnDate", txtRepaymentDate.Text)
                cmd.Parameters.AddWithValue("@CaptureBy", Session("UserId"))
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub

    Protected Sub loadAccounts()
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("select convert(varchar,MainAccount)  + '/' + convert(varchar,SubAccount) as AccountNo, AccountName  + '  ' + convert(varchar,MainAccount)  + '/' + convert(varchar,SubAccount) as AccountName from tbl_FinancialAccountsCreation where (MainAccount='212' or MainAccount='211') and SubAccount<>1", con)
                    'End if
                    Dim ds As New DataSet
                    Using adp = New SqlDataAdapter(cmd)
                        adp.Fill(ds, "LRS2")
                    End Using
                    cmbCapitalAccount.Visible = True
                    loadCombo(ds.Tables(0), cmbCapitalAccount, "AccountName", "AccountNo")
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- loadAccounts()", ex.ToString)
        End Try
    End Sub

    Protected Sub loadAmortization(vca As Double)
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Using cmd As New SqlCommand("Select [PAYMENT_NO] as [No.],convert(nvarchar,[PAYMENT_DATE],106) as [Date],FORMAT([PRINCIPAL],'c') as [Principal],FORMAT([INTEREST],'c') as [Interest],FORMAT([ADMIN_CHARGE],'c') as [Admin],FORMAT([PAYMENT],'c') as [Total] from [AMORTIZATION_SCHEDULE] where LoanId='" & vca & "' order by [PAYMENT_NO] asc", con)
                Dim ds As New DataSet
                Dim adp As New SqlDataAdapter(cmd)
                adp.Fill(ds, "FUN")
                If ds.Tables(0).Rows.Count > 0 Then
                    grdAmortization.DataSource = ds.Tables(0)
                    ViewState("Interest") = ds.Tables(0).Rows(0).Item("Interest")
                    ViewState("Principal") = ds.Tables(0).Rows(0).Item("Principal")
                    ViewState("Fees") = ds.Tables(0).Rows(0).Item("Admin")
                    ViewState("Penalty") = 0
                    ViewState("Total") = ds.Tables(0).Rows(0).Item("Total")
                Else
                    grdAmortization.DataSource = Nothing
                End If
                grdAmortization.DataBind()
            End Using
        End Using
    End Sub

    Protected Sub loadInterestAccounts()
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("select convert(varchar,MainAccount)  + '/' + convert(varchar,SubAccount) as AccountNo, AccountName  + '  ' + convert(varchar,MainAccount)  + '/' + convert(varchar,SubAccount) as AccountName from tbl_FinancialAccountsCreation where MainAccount='217' and SubAccount<>1", con)
                    Dim ds As New DataSet
                    Using adp = New SqlDataAdapter(cmd)
                        adp.Fill(ds, "LRS2")
                    End Using
                    cmbInterestAccount.Visible = True
                    loadCombo(ds.Tables(0), cmbInterestAccount, "AccountName", "AccountNo")
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- loadInterestAccounts()", ex.ToString)
        End Try
    End Sub

    Protected Sub loadPrevRepayments(vca As Double)
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Using cmd As New SqlCommand("Select convert(nvarchar,[TrxnDate],106) as [Payment Date],FORMAT([TotalAmount],'c') as [Total Amount],FORMAT([Principal],'c') as [Principal Amount],FORMAT([Interest],'c') as [Interest],FORMAT([Charges],'c') as [Penalty] from Repayments where LoanId='" & vca & "' order by [TrxnDate] asc", con)
                Dim ds As New DataSet
                Dim adp As New SqlDataAdapter(cmd)
                adp.Fill(ds, "FUN")
                If ds.Tables(0).Rows.Count > 0 Then
                    grdRepaymentHistory.DataSource = ds.Tables(0)
                Else
                    grdRepaymentHistory.DataSource = Nothing
                End If
                grdRepaymentHistory.DataBind()
            End Using
        End Using
    End Sub

    Protected Sub lstLoans_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstLoans.SelectedIndexChanged
        Try
            txtLoanID.Text = lstLoans.SelectedValue
            btnSearchVCAID_Click(sender, New EventArgs)
        Catch ex As Exception
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- lstLoans_SelectedIndexChanged", ex.ToString)
        End Try
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True

        If Not IsPostBack Then
            loadAccounts()
            loadInterestAccounts()
            loadPenaltyAccounts()
            If Request.QueryString("id") <> "" Then
                Dim EncQuery As New BankEncryption64
                ViewState("globLoanID") = EncQuery.Decrypt(Request.QueryString("id"), "taDz392018hbdER")
                'fillAppForm(ViewState("globLoanID"))
            Else
                ViewState("globLoanID") = 0
            End If
        End If
    End Sub
    Protected Sub loadPenaltyAccounts()
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("select convert(varchar,MainAccount)  + '/' + convert(varchar,SubAccount) as AccountNo, AccountName  + '  ' + convert(varchar,MainAccount)  + '/' + convert(varchar,SubAccount) as AccountName from tbl_FinancialAccountsCreation where MainAccount='218' and SubAccount<>1", con)
                    Dim ds As New DataSet
                    Using adp = New SqlDataAdapter(cmd)
                        adp.Fill(ds, "LRS2")
                    End Using
                    cmbPenaltyAccount.Visible = True
                    loadCombo(ds.Tables(0), cmbPenaltyAccount, "AccountName", "AccountNo")
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- loadPenaltyAccounts()", ex.ToString)
        End Try
    End Sub

    Protected Sub saveRepayment()
        Try
            If txtAmtPaid.Text = "" Or Not IsNumeric(toMoney(txtAmtPaid.Text)) Then
                notify("Enter valid total amount paid", "error")
                txtAmtPaid.Focus()
                Exit Sub
            End If

            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd As New SqlCommand("SaveRepayment", con)
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@loanID", txtLoanID.Text)
                    cmd.Parameters.AddWithValue("@CustNo", txtCustNo.Text)
                    cmd.Parameters.AddWithValue("@TrxnDate", txtRepaymentDate.Text)
                    cmd.Parameters.AddWithValue("@Interest", toMoney(txtInterest.Text))
                    cmd.Parameters.AddWithValue("@Principal", toMoney(txtCapital.Text))
                    cmd.Parameters.AddWithValue("@Penalty", toMoney(txtPenalty.Text))
                    cmd.Parameters.AddWithValue("@TotalAmount", toMoney(txtAmtPaid.Text))
                    cmd.Parameters.AddWithValue("@RolloverBalance", 0)
                    cmd.Parameters.AddWithValue("@InterestNextPmt", 0)
                    cmd.Parameters.AddWithValue("@NextPmtTotal", 0)
                    cmd.Parameters.AddWithValue("@CapturedBy", Session("UserId"))
                    If con.State = ConnectionState.Open Then
                        con.Close()
                    End If
                    con.Open()
                    If cmd.ExecuteNonQuery() Then
                    Else
                        notify("Error saving repayment", "error")
                    End If
                    con.Close()
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- saveRepayment()", ex.ToString)
        End Try
    End Sub

    Protected Sub saveTransaction(reference As String, description As String, debit As Double, credit As Double, account As String, contra As String, status As String, other As String, bankAccId As String, bankAccName As String, batchRef As String, trxnDate As Date)
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Using cmd As New SqlCommand("SaveAccountsTrxnsTempWithContra", con)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@Type", "System Entry")
                cmd.Parameters.AddWithValue("@Category", "Loan Repayment")
                cmd.Parameters.AddWithValue("@Ref", reference)
                cmd.Parameters.AddWithValue("@Desc", description)
                cmd.Parameters.AddWithValue("@Debit", debit)
                cmd.Parameters.AddWithValue("@Credit", credit)
                cmd.Parameters.AddWithValue("@Account", account)
                cmd.Parameters.AddWithValue("@ContraAccount", contra)
                cmd.Parameters.AddWithValue("@Status", status)
                cmd.Parameters.AddWithValue("@Other", other)
                cmd.Parameters.AddWithValue("@BankAccID", bankAccId)
                cmd.Parameters.AddWithValue("@BankAccName", bankAccName)
                cmd.Parameters.AddWithValue("@BatchRef", batchRef)
                cmd.Parameters.AddWithValue("@TrxnDate", trxnDate)
                cmd.Parameters.AddWithValue("@CaptureBy", Session("UserId"))

                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub

    Protected Function toMoney(inp As String) As Double
        If inp = "" Then
            inp = 0
        End If
        Return inp.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", "")
    End Function

    Protected Sub txtAmtPaid_TextChanged(sender As Object, e As EventArgs) Handles txtAmtPaid.TextChanged


        Try
            If IsNumeric(txtAmtPaid.Text) Then


                Dim remBalance As Double = CDbl(toMoney(txtAmtPaid.Text))
                'Dim expectedPart=Convert.ToDouble(ViewState("Principal").ToString())
                ' msgbox(toMoney())
                allocateRepayment(ViewState("RepayOrder1"), ViewState("RepayOrder2"), ViewState("RepayOrder3"), ViewState("RepayOrder4"), remBalance, toMoney(ViewState("Principal")), toMoney(ViewState("Interest")), toMoney(ViewState("Penalty")), toMoney(ViewState("Fees")))

                txtCapital.Text = ViewState("PrincipalPaid")
                txtInterest.Text = ViewState("InterestPaid")
                txtPenalty.Text = ViewState("PenaltiesPaid")
                'finalcalculation

                Dim earlypaydec As Double = 0
                Dim AmtPaid As Double = 0
                Dim InterestPaid As Double = 0
                Dim Capital As Double = 0
                Dim expectedPart As Double = 0

                AmtPaid = Convert.ToDouble(txtAmtPaid.Text)
                InterestPaid = Convert.ToDouble(txtInterest.Text)
                Capital = Convert.ToDouble(txtCapital.Text)
                expectedPart = Convert.ToDouble(toMoney(ViewState("Total")).ToString())



                If AmtPaid > expectedPart Then
                    earlypaydec = AmtPaid - (Capital + InterestPaid)
                    txtEarlyPayment.Text = earlypaydec.ToString()
                ElseIf AmtPaid < expectedPart Then
                    Capital = AmtPaid - InterestPaid
                    txtCapital.Text = Capital.ToString()
                    txtEarlyPayment.Text = ""
                End If

                'Underpayment

                'fees amount
                'If ViewState("RepayOrder1") = "Principal" Then

                'End If
                'If CDbl(txtAmtPaid.Text) > CDbl(toMoney(ViewState("Principal"))) Then
                '    txtCapital.Text = ViewState("Principal")
                '    remBalance = remBalance - toMoney(txtCapital.Text)
                'Else
                '    txtCapital.Text = txtAmtPaid.Text
                '    remBalance = remBalance - toMoney(txtCapital.Text)
                'End If
                'If remBalance > 0 And remBalance > CDbl(toMoney(ViewState("Interest"))) Then
                '    txtInterest.Text = ViewState("Interest")
                '    remBalance = remBalance - toMoney(txtInterest.Text)
                'Else
                '    txtInterest.Text = remBalance
                '    remBalance = remBalance - toMoney(txtInterest.Text)
                'End If
                ''If remBalance > 0 And remBalance > CDbl(toMoney(ViewState("Admin"))) Then
                ''txtAdmin.Text = ViewState("Admin")
                ''remBalance = remBalance - toMoney(txtAdmin.Text)
                ''Else
                ''txtAdmin.Text = remBalance
                ''remBalance = remBalance - toMoney(txtAdmin.Text)
                ''End If
                'If remBalance > 0 Then
                '    txtCapital.Text = toMoney(txtCapital.Text) + remBalance
                'End If
                'txtPenalty.Text = 0
            End If
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- txtAmtPaid_TextChanged()", ex.ToString)
        End Try
    End Sub
    Protected Sub UpdateAllRepaidLoans()
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Using cmd As New SqlCommand("update QUEST_APPLICATION set status='REPAID' where convert(varchar,id) in (select refrence from Accounts_Transactions acct where account in (select customer_number from CUSTOMER_DETAILS) group by Refrence having sum(debit-credit)<=0)", con)
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub

End Class