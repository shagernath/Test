﻿Imports System.Data
Imports System.Data.SqlClient
Imports CreditManager
Imports ErrorLogging

Partial Class Credit_Quest_Assets
    Inherits System.Web.UI.Page
    Dim adp As SqlDataAdapter
    Dim AssetID As String
    Dim cmd As SqlCommand
    Dim con As New SqlConnection
    Protected Sub btnSaveRefund_Click(sender As Object, e As EventArgs) Handles btnSaveRefund.Click
        Try
            If txtAsstid.Text = "" Or txtAssetDescription.Text = "" Or txtAssetName.Text = "" Then
                notify("Enter all fields", "error")
                Exit Sub
            End If
            Dim cmd1 As New SqlCommand("insert into Quest_Assets ( CreatedBy,Name, Category, Cost_price, Selling_Price, Stock_level, DateAcquire, Description, AssetID) values ('" & Session("userid") & "','" & txtAssetName.Text & "','" & txtCategory.Text & "','" & txtCostPrice.Text & "','" & txtSellingPrice.Text & "','" & txtStockLevel.Text & "','" & bdpAcqiured.Text & "','" & txtAssetDescription.Text & "','" & txtAsstid.Text & "')", con)
            If con.State <> ConnectionState.Closed Then
                con.Close()
            End If
            con.Open()
            If cmd1.ExecuteNonQuery() Then
                msgbox("Record Saved Successfully")
                clearAll()
            End If
            con.Close()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub btnSearchAsset_Click(sender As Object, e As EventArgs) Handles btnSearchAsset.Click
        LoadAssets()
    End Sub

    Protected Sub btnuPDATE_Click(sender As Object, e As EventArgs) Handles btnuPDATE.Click
        Try
            cmd = New SqlCommand("update Quest_Assets  set UpdatedBy='" & Session("userid") & "',Name='" & txtAssetName.Text & "', Category='" & txtCategory.Text & "', Cost_price='" & txtCostPrice.Text & "', Selling_Price='" & txtSellingPrice.Text & "', Stock_level='" & txtStockLevel.Text & "', DateAcquire='" & bdpAcqiured.Text & "', Description='" & txtAssetDescription.Text & "' where AssetID='" & txtAsstid.Text & "'", con)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            cmd.ExecuteNonQuery()
            msgbox("Successfully Updated")
            clearAll()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub clearAll()
        txtAssetDescription.Text = ""
        txtAssetName.Text = ""
        txtAsstid.Text = ""
        txtCostPrice.Text = ""
        txtSearchAsset.Text = ""
        txtSellingPrice.Text = ""
        txtStockLevel.Text = ""
        bdpAcqiured.Text = ""
        txtCategory.Text = ""
    End Sub
    Protected Sub LoadAssets()
        Try
            If txtSearchAsset.Text <> "" Then
                cmd = New SqlCommand("select id,(Name+' '+Description+' '+AssetID) as DISPLAY from  Quest_Assets where (Name+' '+Description+' '+AssetID) like '" & txtSearchAsset.Text & "%'", con)
                'as DISPLAY from CAPITAL_DISBURSEMENTS where ACCOUNTNAME like '" & txtSearchName.Text & "%'", con)
            Else
                cmd = New SqlCommand("select id,(Name+' '+Description+' '+AssetID) as DISPLAY from Quest_Assets ", con)
            End If
            Dim ds As New DataSet
            Dim adp As New SqlDataAdapter
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "INVOICES")
            If ds.Tables(0).Rows.Count > 0 Then
                lstAssets.DataSource = ds.Tables(0)
                lstAssets.DataTextField = "DISPLAY"
                lstAssets.DataValueField = "id"
                lstAssets.Visible = True
            Else
                lstAssets.DataSource = Nothing
                lstAssets.Visible = False
                msgbox("Asset not found")
                txtSearchAsset.Text = ""
            End If
            lstAssets.DataBind()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub
    Protected Sub lstAssets_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstAssets.SelectedIndexChanged
        Try
            ', , , , , , , CreatedBy, UpdatedBy, UpdateDate,

            AssetID = lstAssets.SelectedValue()
            cmd = New SqlCommand("select * from Quest_Assets where ID='" & AssetID & "'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "Assets")
            ' Dim InvoiceAmt As Double
            If ds.Tables(0).Rows.Count > 0 Then
                txtAssetDescription.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("Description")).ToString
                txtAssetName.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("Name")).ToString
                txtAsstid.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("AssetID")).ToString
                txtCostPrice.Text = FormatNumber(Val(ds.Tables(0).Rows(0).Item("Cost_price").ToString), 2)
                txtSellingPrice.Text = FormatNumber(Val(ds.Tables(0).Rows(0).Item("Selling_Price").ToString), 2)
                txtStockLevel.Text = FormatNumber(Val(ds.Tables(0).Rows(0).Item("Stock_level").ToString), 2)
                bdpAcqiured.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("DateAcquire")).ToString
                txtCategory.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("Category")).ToString
            End If
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True
        con = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
        If Not IsPostBack Then

        End If
    End Sub

    Protected Sub txtAssetDescription_TextChanged(sender As Object, e As EventArgs) Handles txtAssetDescription.TextChanged

    End Sub
End Class