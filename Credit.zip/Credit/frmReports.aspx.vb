﻿Imports System.Data
Imports System.Data.SqlClient
Imports CreditManager

Partial Class Credit_frmReports
    Inherits System.Web.UI.Page
    Dim adp As SqlDataAdapter
    Dim cmd As SqlCommand
    Dim con As New SqlConnection
    Dim connection As String

    Protected Sub btnPrintArrear_Click(sender As Object, e As EventArgs) Handles btnPrintArrear.Click
        openReport("rptArrears.aspx?from=" + txtDueArrearFromDate.Text + "&to=" + txtArrearToDate.Text + "&brnch=" + cmbBranchArrear.SelectedValue + "")
    End Sub

    Protected Sub btnPrintDisb_Click(sender As Object, e As EventArgs) Handles btnPrintDisb.Click
        'openReport("rptDisbursements.aspx?from=" + txtDisbFromDate.Text + "&to=" + txtDisbToDate.Text + "&disb=All&brnch=" + cmbBranchDisb.SelectedValue + "")
        openReport("rptDisbursements.aspx?from=" + txtDisbFromDate.Text + "&to=" + txtDisbToDate.Text + "&disb=&brnch=" + cmbBranchDisb.SelectedValue + "&plofficer=" + cmbLOOptions.SelectedValue + "")
    End Sub

    Protected Sub btnPrintDuePayments_Click(sender As Object, e As EventArgs) Handles btnPrintDuePayments.Click
        openReport("rptDuePayments.aspx?from=" + txtDueFromDate.Text + "&to=" + txtDueToDate.Text + "&brnch=" + cmbBranchDue.SelectedValue + "")
    End Sub

    Protected Sub btnPrintInterest_Click(sender As Object, e As EventArgs) Handles btnPrintInterest.Click
        openReport("rptEarnedInterest.aspx?from=" + txtInterestFromDate.Text + "&to=" + txtInterestToDate.Text + "&brnch=" + cmbInterestBranch.SelectedValue + "")
    End Sub

    Protected Sub btnPrintMaturity_Click(sender As Object, e As EventArgs) Handles btnPrintMaturity.Click
        openReport("rptMaturity.aspx?from=" + txtFromDate.Text + "&to=" + txtToDate.Text + "&brnch=" + branchOption.SelectedValue + "")
    End Sub

    Protected Sub btnPrintStatus_Click(sender As Object, e As EventArgs) Handles btnPrintStatus.Click
        openReport("rptStatusReport.aspx?from=" + txtStatusFromDate.Text + "&to=" + txtStatusToDate.Text + "&brnch=" + cmbStatusBranch.SelectedValue + "&status=" + cmbStatus.SelectedValue)
    End Sub

    Protected Sub btnSearchLoanID_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearchLoanID.Click
        Try
            If Trim(Session("SessionID")) = "" Or IsDBNull(Session("SessionID")) Then
                Response.Redirect("~/logout.aspx")
            Else
                'btnPrint_Click(sender, New EventArgs)
            End If
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub btnSearchName_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearchName.Click
        Try
            cmd = New SqlCommand("select ID,SURNAME+' '+FORENAMES+' '+convert(varchar,CUSTOMER_NUMBER)+' '+convert(varchar,FIN_AMT) as DISPLAY from QUEST_APPLICATION where SURNAME like '" & txtSearchName.Text & "%'", con)
            Dim ds As New DataSet
            Dim adp As New SqlDataAdapter
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "LOANS")
            If ds.Tables(0).Rows.Count > 0 Then
                lstLoans.DataSource = ds.Tables(0)
                lstLoans.DataTextField = "DISPLAY"
                lstLoans.DataValueField = "ID"
                lstLoans.Visible = True
            Else
                lstLoans.DataSource = Nothing
                lstLoans.Visible = False
                'msgbox("Search name not found")
                ClientScript.RegisterStartupScript(Me.GetType(), "Gritter", "<script type=""text/javascript"">$.gritter.add({title: 'Name not found!',text: 'There is no record which matches the entered name.',image: 'images/error_button.png'});</script>")
                txtLoanID.Text = ""
            End If
            lstLoans.DataBind()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub
    
    Protected Sub loadBranches()
        Try
            cmd = New SqlCommand("select * from BNCH_DETAILS", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "bnch")
            If ds.Tables(0).Rows.Count > 0 Then
                branchOption.DataSource = ds.Tables(0)
                branchOption.DataTextField = "BNCH_NAME"
                branchOption.DataValueField = "BNCH_CODE"
                cmbBranchArrear.DataSource = ds.Tables(0)
                cmbBranchArrear.DataTextField = "BNCH_NAME"
                cmbBranchArrear.DataValueField = "BNCH_CODE"
                cmbBranchDisb.DataSource = ds.Tables(0)
                cmbBranchDue.DataSource = ds.Tables(0)
                cmbBranchDisb.DataTextField = "BNCH_NAME"
                cmbBranchDisb.DataValueField = "BNCH_CODE"
                cmbBranchDue.DataTextField = "BNCH_NAME"
                cmbBranchDue.DataValueField = "BNCH_CODE"
                cmbBranchBranch.DataSource = ds.Tables(0)
                cmbBranchBranch.DataTextField = "BNCH_NAME"
                cmbBranchBranch.DataValueField = "BNCH_CODE"
                cmbInterestBranch.DataSource = ds.Tables(0)
                cmbInterestBranch.DataTextField = "BNCH_NAME"
                cmbInterestBranch.DataValueField = "BNCH_CODE"
                'loadCombo(ds.Tables(0), cmbInterestBranch, "BNCH_NAME", "BNCH_CODE")
                cmbStatusBranch.DataSource = ds.Tables(0)
                cmbStatusBranch.DataTextField = "BNCH_NAME"
                cmbStatusBranch.DataValueField = "BNCH_CODE"
           
                      ddBranch.DataSource = ds.Tables(0)
                ddBranch.AppendDataBoundItems=True
                     ddBranch.DataTextField = "BNCH_NAME"
                ddBranch.DataValueField = "BNCH_CODE"

                cmbEODBranch.DataSource = ds.Tables(0)
                cmbEODBranch.DataTextField = "BNCH_NAME"
                cmbEODBranch.DataValueField = "BNCH_CODE"

                cmbPaymentRepBranch.DataSource = ds.Tables(0)
                cmbPaymentRepBranch.DataTextField = "BNCH_NAME"
                cmbPaymentRepBranch.DataValueField = "BNCH_CODE"

                cmbBranchDownloadedRep.DataSource = ds.Tables(0)
                cmbBranchDownloadedRep.DataTextField = "BNCH_NAME"
                cmbBranchDownloadedRep.DataValueField = "BNCH_CODE"

                cmbInstallDueBranch.DataSource = ds.Tables(0)
                cmbInstallDueBranch.DataTextField = "BNCH_NAME"
                cmbInstallDueBranch.DataValueField = "BNCH_CODE"

                cmbLoanBookBranch.DataSource = ds.Tables(0)
                cmbLoanBookBranch.DataTextField = "BNCH_NAME"
                cmbLoanBookBranch.DataValueField = "BNCH_CODE"
            Else
                branchOption.DataSource = Nothing
                cmbEODBranch.DataSource = Nothing
                cmbPaymentRepBranch.DataSource = Nothing
                cmbBranchDownloadedRep.DataSource = Nothing
                cmbInstallDueBranch.DataSource = Nothing
                cmbLoanBookBranch.DataSource = Nothing
            End If
            branchOption.DataBind()
            cmbBranchArrear.DataBind()
            cmbBranchDue.DataBind()
            cmbBranchDisb.DataBind()
            cmbBranchBranch.DataBind()
            cmbInterestBranch.DataBind()
            cmbStatusBranch.DataBind()
            ddBranch.DataBind()
            cmbEODBranch.DataBind()
            cmbPaymentRepBranch.DataBind()
            cmbBranchDownloadedRep.DataBind()
            cmbInstallDueBranch.DataBind()
            cmbLoanBookBranch.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub loadStatus()
        Try
            statusOption.Items.Clear()
            statusOption.Items.Add("")
            cmd = New SqlCommand("select distinct STATUS from QUEST_APPLICATION", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "bnch")
            If ds.Tables(0).Rows.Count > 0 Then
                statusOption.DataSource = ds.Tables(0)
                statusOption.DataTextField = "STATUS"
                statusOption.DataValueField = "STATUS"
                cmbStatus.DataSource = ds.Tables(0)
                cmbStatus.DataTextField = "STATUS"
                cmbStatus.DataValueField = "STATUS"
            Else
                statusOption.DataSource = Nothing
            End If
            statusOption.DataBind()
            cmbStatus.DataBind()
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub loadPayTypes()
        Try
            cmd = New SqlCommand("select distinct case when qa.DISBURSE_OPTION='DDebit' then qa.Bank ELSE 'PMEC' END as P_Source from QUEST_APPLICATION qa where qa.DISBURSED =1", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "bnch")
            If ds.Tables(0).Rows.Count > 0 Then
                cmbInstallDuePayType.DataSource = ds.Tables(0)
                cmbInstallDuePayType.DataTextField = "P_Source"
                cmbInstallDuePayType.DataValueField = "P_Source"

                cmbLoanBookPayType.DataSource = ds.Tables(0)
                cmbLoanBookPayType.DataTextField = "P_Source"
                cmbLoanBookPayType.DataValueField = "P_Source"
            Else
                cmbInstallDuePayType.DataSource = Nothing
                cmbLoanBookPayType.DataSource = Nothing
            End If
            cmbInstallDuePayType.DataBind()
            cmbLoanBookPayType.DataBind()
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub loadLOOfficers()
        Try
            cmd = New SqlCommand("select USERID,USER_LOGIN from MASTER_USERS order by user_Login asc", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "MASTER_USERS")
            If ds.Tables(0).Rows.Count > 0 Then
                cmbLOOptions.DataSource = ds.Tables(0)
                cmbLOOptions.DataTextField = "USER_LOGIN"
                cmbLOOptions.DataValueField = "USERID"

                cmbEODLoanofficer.DataSource = ds.Tables(0)
                cmbEODLoanofficer.DataTextField = "USER_LOGIN"
                cmbEODLoanofficer.DataValueField = "USERID"

                cmbLofficerDownloadedRep.DataSource = ds.Tables(0)
                cmbLofficerDownloadedRep.DataTextField = "USER_LOGIN"
                cmbLofficerDownloadedRep.DataValueField = "USERID"

                cmbInstallDueLofficer.DataSource = ds.Tables(0)
                cmbInstallDueLofficer.DataTextField = "USER_LOGIN"
                cmbInstallDueLofficer.DataValueField = "USERID"

                cmbLoanBookLOfficer.DataSource = ds.Tables(0)
                cmbLoanBookLOfficer.DataTextField = "USER_LOGIN"
                cmbLoanBookLOfficer.DataValueField = "USERID"
            Else
                cmbLOOptions.DataSource = Nothing
                cmbEODLoanofficer.DataSource = Nothing
                cmbLofficerDownloadedRep.DataSource = Nothing
                cmbInstallDueLofficer.DataSource = Nothing
                cmbLoanBookLOfficer.DataSource = Nothing
            End If
            cmbLOOptions.DataBind()
            cmbEODLoanofficer.DataBind()
            cmbLofficerDownloadedRep.DataBind()
            cmbInstallDueLofficer.DataBind()
            cmbLoanBookLOfficer.DataBind()
        Catch ex As Exception
        End Try
    End Sub
    Protected Sub lstLoans_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstLoans.SelectedIndexChanged
        Try
            Dim loanID = lstLoans.SelectedValue
            txtLoanID.Text = loanID
            btnSearchLoanID_Click(sender, New EventArgs)
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub openReport(url As String)
        Dim EncQuery As New BankEncryption64
        Dim strscript As String
        strscript = "<script langauage=JavaScript>"
        strscript += "window.open('" & url & "')"
        strscript += "</script>"
        ClientScript.RegisterStartupScript(Me.GetType(), "newwin", strscript)
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Try
            Page.MaintainScrollPositionOnPostBack = True
            con = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            If Not IsPostBack Then
                loadBranches()
                loadStatus()
                loadLOOfficers()
                loadLOOfficers_SpecBranch(cmbInstallDueBranch, cmbInstallDueBranch)
                loadLOOfficers_SpecBranch(cmbLoanBookLOfficer, cmbLoanBookBranch)
                loadPayTypes()
                If Session("Role") = "4041" Then
                    HyperLinnk12.Enabled = False
                Else
                    HyperLinnk12.Enabled = True
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub btnPrintBranch_Click(sender As Object, e As EventArgs) Handles btnPrintBranch.Click
        openReport("rptBranchReport.aspx?from=" + txtBranchFromDate.Text + "&to=" + txtBranchToDate.Text + "&brnch=" + cmbBranchBranch.SelectedValue + "")
    End Sub
    Private Sub btnEODPrint_Click(sender As Object, e As EventArgs) Handles btnEODPrint.Click
        openReport("rptEODLOfficerSummary.aspx?from=" + txtEODFrom.Text + "&to=" + txtEODTo.Text + "&brnch=" + cmbEODBranch.SelectedValue + "&lofficer=" + cmbEODLoanofficer.SelectedValue + "")
    End Sub
    Private Sub btnPaymentRepPrint_Click(sender As Object, e As EventArgs) Handles btnPaymentRepPrint.Click
        openReport("rptPaymentReport.aspx?from=" + txtPaymentRepFrom.Text + "&to=" + txtPaymentRepTo.Text + "&brnch=" + cmbPaymentRepBranch.SelectedValue + "")
    End Sub
    Private Sub btnPrintDownloadedRep_Click(sender As Object, e As EventArgs) Handles btnPrintDownloadedRep.Click
        openReport("rptDownloadedFileReport.aspx?from=" + txtDownloadedRepFrom.Text + "&to=" + txtDownloadedRepTo.Text + "&brnch=" + cmbBranchDownloadedRep.SelectedValue + "&LOfficer=" + cmbLofficerDownloadedRep.SelectedValue + "&FType=" + cmbType.SelectedValue + "")
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ddBranch.SelectedItem.Text <> "All" Then
            openReport("../Reports/rptLoanOfficerCashBranch.aspx?brnch=" + ddBranch.SelectedValue + "")
        Else
            openReport("../Reports/rptLoanOfficerCash.aspx")
        End If
    End Sub
    Private Sub btnInstallDuePrint_Click(sender As Object, e As EventArgs) Handles btnInstallDuePrint.Click
        openReport("rptInstallDueeReport.aspx?from=" + txtInstallDueFrom.Text + "&to=" + txtInstallDueTo.Text + "&brnch=" + cmbInstallDueBranch.SelectedValue + "&LOfficer=" + cmbInstallDueLofficer.SelectedValue + "&FType=" + cmbInstallDuePayType.SelectedValue + "")
    End Sub
    Protected Sub loadLOOfficers_SpecBranch(cmb_b As DropDownList, cmb_d As DropDownList)
        cmb_b.ClearSelection()
        cmb_b.Items.Clear()
        cmb_b.Items.Add(New ListItem("All", "All"))
        Try
            If cmb_d.SelectedItem.Value = "All" Then
                cmb_b.DataSource = Nothing
                cmb_b.DataBind()
            Else
                cmd = New SqlCommand("select USERID,USER_LOGIN from MASTER_USERS where USER_BRANCH='" & cmb_d.SelectedItem.Value & "' order by user_Login asc", con)
                Dim ds As New DataSet
                adp = New SqlDataAdapter(cmd)
                adp.Fill(ds, "MASTER_USERS")
                If ds.Tables(0).Rows.Count > 0 Then
                    cmb_b.DataSource = ds.Tables(0)
                    cmb_b.DataTextField = "USER_LOGIN"
                    cmb_b.DataValueField = "USERID"
                Else
                    cmb_b.DataSource = Nothing
                End If
                cmb_b.DataBind()
            End If

        Catch ex As Exception
        End Try
    End Sub
    Protected Sub cmbInstallDueBranch_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbInstallDueBranch.SelectedIndexChanged
        loadLOOfficers_SpecBranch(cmbInstallDueBranch, cmbInstallDueBranch)
        ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "Pop", "openModal();", True)
    End Sub
    Protected Sub cmbLoanBookBranch_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbLoanBookBranch.SelectedIndexChanged
        loadLOOfficers_SpecBranch(cmbLoanBookLOfficer, cmbLoanBookBranch)
        ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "Pop", "openModal_2();", True)
    End Sub
    Private Sub btnLoanBookPrint_Click(sender As Object, e As EventArgs) Handles btnLoanBookPrint.Click
        'from=" + txtLoanBookFrom.Text + "&to=" + txtLoanBookTo.Text + "&
        openReport("rptLoanBookReport.aspx?brnch=" + cmbLoanBookBranch.SelectedValue + "&LOfficer=" + cmbLoanBookLOfficer.SelectedValue + "&FType=" + cmbLoanBookPayType.SelectedValue + "")
    End Sub
End Class