﻿Imports System.Data
Imports System.Data.SqlClient
Imports CreditManager
Imports ErrorLogging
Imports BankString
Imports System.Xml
Imports System.IO
Imports ClosedXML.Excel
Imports System.Net
Imports System.Data.OleDb

Partial Class Credit_Repayment_upload
    Inherits System.Web.UI.Page
    Protected Shared Function getLastRepaymentDate(loanId As String) As String
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            'Using cmd As New SqlCommand("select isnull(rep.TrxnDate,act.DISBURSED_DATE) as TrxnDate from QUEST_APPLICATION act left join Repayments rep on rep.[LoanID]=act.ID where act.[ID]='" + loanId + "' order by TrxnDate desc", con)
            Using cmd As New SqlCommand("select isnull(rep.TrxnDate,'') as TrxnDate from Repayments rep where rep.[LoanID]='" + loanId + "' order by TrxnDate desc", con)
                Dim ds As New DataSet
                Dim adp As New SqlDataAdapter(cmd)
                adp.Fill(ds, "FUN")
                If ds.Tables(0).Rows.Count > 0 Then
                    Return ds.Tables(0).Rows(0).Item("TrxnDate").ToString
                Else
                    Return ""
                End If
            End Using
        End Using
    End Function
    Protected Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            If Not IsDate(txtRepaymentDate.Text) Then
                notify("Enter valid repayment date", "error")
                txtRepaymentDate.Focus()
            ElseIf cmbCapitalAccount.Text = "" Then
                notify("Select Account", "error")
                cmbCapitalAccount.Focus()
            ElseIf grdRepaymentsinfile.Rows.Count <= 0 Then
                notify("Load File First", "error")
                cmbCapitalAccount.Focus()
            Else
                SaveUploadedRepayments()
                UpdateAllRepaidLoans()
                Response.Write("<script>alert('Repayments posted') ; location.href='RepaymentsUpload.aspx'</script>")
            End If
        Catch ex As Exception
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- btnSave_Click()", ex.ToString)
        End Try
    End Sub
    Protected Sub getProductOptions(prodID As String)
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("SELECT * FROM creditproducts where id='" & prodID & "'", con)
                    Dim dt As New DataTable
                    Using adp As New SqlDataAdapter(cmd)
                        adp.Fill(dt)
                    End Using
                    If dt.Rows.Count > 0 Then
                        Dim dr = dt.Rows(0)
                        ViewState("RepayOrder1") = dr("RepayOrder1")
                        ViewState("RepayOrder2") = dr("RepayOrder2")
                        ViewState("RepayOrder3") = dr("RepayOrder3")
                        ViewState("RepayOrder4") = dr("RepayOrder4")
                    End If
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- getProductOptions()", ex.ToString)
        End Try
    End Sub
    Protected Sub insertInterestAccountsTemp(loanID As String, custno As String, interestamt As Double)
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Using cmd = New SqlCommand("SaveAccountsTrxnsTempWithContra", con)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@Type", "System Entry")
                cmd.Parameters.AddWithValue("@Category", "Loan Repayment")
                cmd.Parameters.AddWithValue("@Ref", loanID)
                cmd.Parameters.AddWithValue("@Desc", "Interest Repayment")
                cmd.Parameters.AddWithValue("@Debit", 0)
                cmd.Parameters.AddWithValue("@Credit", toMoney(interestamt))
                cmd.Parameters.AddWithValue("@Account", custno)
                cmd.Parameters.AddWithValue("@Status", 1)
                cmd.Parameters.AddWithValue("@Other", "")
                cmd.Parameters.AddWithValue("@BankAccID", "")
                cmd.Parameters.AddWithValue("@BankAccName", "")
                cmd.Parameters.AddWithValue("@BatchRef", "")
                cmd.Parameters.AddWithValue("@TrxnDate", txtRepaymentDate.Text)
                cmd.Parameters.AddWithValue("@CaptureBy", Session("UserId"))
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub
    Protected Sub loadAccounts()
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("select convert(varchar,MainAccount)  + '/' + convert(varchar,SubAccount) as AccountNo, AccountName  + '  ' + convert(varchar,MainAccount)  + '/' + convert(varchar,SubAccount) as AccountName from tbl_FinancialAccountsCreation where (MainAccount='212') and SubAccount<>1", con)
                    'End if
                    Dim ds As New DataSet
                    Using adp = New SqlDataAdapter(cmd)
                        adp.Fill(ds, "LRS2")
                    End Using
                    cmbCapitalAccount.Visible = True
                    loadCombo(ds.Tables(0), cmbCapitalAccount, "AccountName", "AccountNo")
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- loadAccounts()", ex.ToString)
        End Try
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True
        If Not IsPostBack Then
            loadAccounts()
        End If
    End Sub
    Protected Function saveRepayment(loanid As String, custno As String, capital As Double, interesttt As Double, totalamt As Double, penaltyamt As Double) As Boolean
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd As New SqlCommand("SaveRepayment", con)
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@loanID", loanid)
                    cmd.Parameters.AddWithValue("@CustNo", custno)
                    cmd.Parameters.AddWithValue("@TrxnDate", txtRepaymentDate.Text)
                    cmd.Parameters.AddWithValue("@Interest", toMoney(interesttt))
                    cmd.Parameters.AddWithValue("@Principal", toMoney(capital))
                    cmd.Parameters.AddWithValue("@Penalty", toMoney(penaltyamt))
                    cmd.Parameters.AddWithValue("@TotalAmount", toMoney(totalamt))
                    cmd.Parameters.AddWithValue("@RolloverBalance", 0)
                    cmd.Parameters.AddWithValue("@InterestNextPmt", 0)
                    cmd.Parameters.AddWithValue("@NextPmtTotal", 0)
                    cmd.Parameters.AddWithValue("@CapturedBy", Session("UserId"))
                    If con.State = ConnectionState.Open Then
                        con.Close()
                    End If
                    con.Open()
                    If cmd.ExecuteNonQuery() Then
                        Return True
                    Else
                        notify("Error saving repayment", "error")
                        Return False
                    End If
                    con.Close()
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- saveRepayment()", ex.ToString)
            notify(ex.Message.ToString, "error")
            Return False
        End Try
    End Function
    Protected Sub saveTransaction(reference As String, description As String, debit As Double, credit As Double, account As String, contra As String, status As String, other As String, bankAccId As String, bankAccName As String, batchRef As String, trxnDate As Date)
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Using cmd As New SqlCommand("SaveAccountsTrxnsTempWithContra", con)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@Type", "System Entry")
                cmd.Parameters.AddWithValue("@Category", "Loan Repayment")
                cmd.Parameters.AddWithValue("@Ref", reference)
                cmd.Parameters.AddWithValue("@Desc", description)
                cmd.Parameters.AddWithValue("@Debit", debit)
                cmd.Parameters.AddWithValue("@Credit", credit)
                cmd.Parameters.AddWithValue("@Account", account)
                cmd.Parameters.AddWithValue("@ContraAccount", contra)
                cmd.Parameters.AddWithValue("@Status", status)
                cmd.Parameters.AddWithValue("@Other", other)
                cmd.Parameters.AddWithValue("@BankAccID", bankAccId)
                cmd.Parameters.AddWithValue("@BankAccName", bankAccName)
                cmd.Parameters.AddWithValue("@BatchRef", batchRef)
                cmd.Parameters.AddWithValue("@TrxnDate", trxnDate)
                cmd.Parameters.AddWithValue("@CaptureBy", Session("UserId"))
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub
    Protected Function toMoney(inp As String) As Double
        Return inp.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", "")
    End Function
    Protected Sub UpdateAllRepaidLoans()
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Using cmd As New SqlCommand("update QUEST_APPLICATION set status='REPAID' where id in (select refrence from Accounts_Transactions acct where account in (select customer_number from CUSTOMER_DETAILS) group by Refrence having sum(debit-credit)<=0)", con)
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub
    Protected Sub updateProcessed(IDn As Long)
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Using cmd As New SqlCommand("update Repayments_temp set Processed=1 where ID='" & IDn & "'", con)
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub
    Protected Sub DeleteRecords()
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Dim cmd As SqlCommand
            cmd = New SqlCommand("delete from Repayments_Upload where CapturedBy='" & Session("UserId") & "' delete from Repayments_temp where Processed=0 and CapturedBy='" & Session("UserId") & "'", con)
            If (con.State = ConnectionState.Open) Then
                con.Close()
            End If
            con.Open()
            If cmd.ExecuteNonQuery() Then

            End If
            con.Close()
        End Using
    End Sub
    Sub insertNew_temptable_PMEC()
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Dim fd As New DataSet
                fd = ImportExcel_PMEC()
                Dim rowcount = fd.Tables(0).Rows.Count
                Dim colcount = fd.Tables(0).Columns.Count
                Dim fileName As String = FileUpload1.FileName
                Dim comm As New SqlCommand
                If rowcount > 0 Then
                    DeleteRecords()
                    For i = 0 To rowcount - 1
                        Dim ReferenceNo, Rec_no, Acc_No, Branch, ADHOC, ZMW, Namess, CURRENCY, GoodFellowNum, DDACC As String
                        ReferenceNo = Trim(fileName)
                        Rec_no = Trim(removeNULLString(fd, i, 0))
                        Acc_No = Trim(removeNULLString(fd, i, 2))
                        Branch = Trim(removeNULLString(fd, i, 2))
                        ADHOC = Trim(removeNULLString(fd, i, 3))
                        ZMW = Trim(removeNULLString(fd, i, 4))
                        Namess = Trim(removeNULLString(fd, i, 1))
                        CURRENCY = "ZMW"
                        GoodFellowNum = Trim(removeNULLString(fd, i, 5))
                        DDACC = "GF " & ADHOC & " PMEC"

                        Using command As New SqlCommand("INSERT INTO Repayments_Upload([Acc_No],[Branch],[Rec_No],[ADHOC_No],[ZMW],[Names],[CURRENCY],[GoodFellowNo],[DDACC],[ReferenceNo],[CapturedBy],[CaptureDate],[FileType])VALUES(@data0,@data1,@data2,@data3,@data4,@data5,@data6,@data7,@data8,@data9,@data10,getdate(),'PMEC')", con)
                            command.Parameters.AddWithValue("@data0", Acc_No)
                            command.Parameters.AddWithValue("@data1", Branch)
                            command.Parameters.AddWithValue("@data2", Rec_no)
                            command.Parameters.AddWithValue("@data3", ADHOC)
                            command.Parameters.AddWithValue("@data4", ZMW)
                            command.Parameters.AddWithValue("@data5", Namess)
                            command.Parameters.AddWithValue("@data6", CURRENCY)
                            command.Parameters.AddWithValue("@data7", GoodFellowNum)
                            command.Parameters.AddWithValue("@data8", DDACC)
                            command.Parameters.AddWithValue("@data9", ReferenceNo)
                            command.Parameters.AddWithValue("@data10", Session("UserId"))
                            If (con.State = ConnectionState.Open) Then
                                con.Close()
                            End If
                            con.Open()
                            command.ExecuteNonQuery()
                            con.Close()
                        End Using
                    Next
                    RemoveUndesiredRecords()
                    'insert into temp table
                    Dim cmdstr As String = ""
                    If cmbFileType.Text = "DDACC" Then
                        cmdstr = "INSERT INTO Repayments_temp([Acc_No],[Branch],[Rec_No],[ADHOC_No],[ZMW],[Names],[CURRENCY],[GoodFellowNo],[DDACC],[ReferenceNo],[CapturedBy],[CaptureDate],[Customer_Number],[FileType]) select [Acc_No],[Branch],[Rec_No],[ADHOC_No],[ZMW],[Names],[CURRENCY],[GoodFellowNo],[DDACC],[ReferenceNo],[CapturedBy],[CaptureDate],(select q.Customer_Number from quest_application q where q.ID=convert(numeric(18,0),[GoodFellowNo])),[FileType] from Repayments_Upload where CapturedBy='" & Session("UserId") & "'"
                    Else
                        cmdstr = "INSERT INTO Repayments_temp([Acc_No],[Branch],[Rec_No],[ADHOC_No],[ZMW],[Names],[CURRENCY],[GoodFellowNo],[DDACC],[ReferenceNo],[CapturedBy],[CaptureDate],[Customer_Number],[FileType]) select [Acc_No],[Branch],[Rec_No],[ADHOC_No],[ZMW],[Names],[CURRENCY],[GoodFellowNo],[DDACC],[ReferenceNo],[CapturedBy],[CaptureDate],(select q.Customer_Number from quest_application q where q.IDNO=[Acc_No] and q.ID=convert(numeric(18,0),[GoodFellowNo])),[FileType] from Repayments_Upload where CapturedBy='" & Session("UserId") & "'"
                    End If
                    Using command As New SqlCommand(cmdstr, con)
                        If (con.State = ConnectionState.Open) Then
                            con.Close()
                        End If
                        con.Open()
                        command.ExecuteNonQuery()
                        con.Close()
                    End Using
                    getUploadedRepayments()
                    'insert into into temp table
                Else
                    notify("file has no data", "error")
                End If
            End Using
        Catch ex As Exception
            notify("Error Occured, Check File Format", "error")
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- insertNew_temptable_PMEC()", ex.ToString)
        End Try
    End Sub
    Sub insertNew_temptable_Banks()
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Dim fd As New DataSet
                fd = ImportExcel()
                Dim rowcount = fd.Tables(0).Rows.Count
                Dim colcount = fd.Tables(0).Columns.Count
                Dim fileName As String = FileUpload1.FileName
                Dim comm As New SqlCommand
                If rowcount > 0 Then
                    DeleteRecords()
                    For i = 0 To rowcount - 1
                        Dim ReferenceNo, Rec_no, Acc_No, Branch, ADHOC, ZMW, Namess, CURRENCY, GoodFellowNum, DDACC As String
                        ReferenceNo = Trim(fileName)
                        Rec_no = Trim(removeNULLString(fd, i, 0))
                        Acc_No = Trim(removeNULLString(fd, i, 1))
                        Branch = Trim(removeNULLString(fd, i, 2))
                        ADHOC = Trim(removeNULLString(fd, i, 3))
                        ZMW = Trim(removeNULLString(fd, i, 4))
                        Namess = Trim(removeNULLString(fd, i, 5))
                        CURRENCY = Trim(removeNULLString(fd, i, 6))
                        GoodFellowNum = Trim(removeNULLString(fd, i, 7))
                        DDACC = Trim(removeNULLString(fd, i, 8))

                        Using command As New SqlCommand("INSERT INTO Repayments_Upload([Acc_No],[Branch],[Rec_No],[ADHOC_No],[ZMW],[Names],[CURRENCY],[GoodFellowNo],[DDACC],[ReferenceNo],[CapturedBy],[CaptureDate],[FileType])VALUES(@data0,@data1,@data2,@data3,@data4,@data5,@data6,@data7,@data8,@data9,@data10,getdate(),'DDACC')", con)
                            command.Parameters.AddWithValue("@data0", Acc_No)
                            command.Parameters.AddWithValue("@data1", Branch)
                            command.Parameters.AddWithValue("@data2", Rec_no)
                            command.Parameters.AddWithValue("@data3", ADHOC)
                            command.Parameters.AddWithValue("@data4", ZMW)
                            command.Parameters.AddWithValue("@data5", Namess)
                            command.Parameters.AddWithValue("@data6", CURRENCY)
                            command.Parameters.AddWithValue("@data7", GoodFellowNum)
                            command.Parameters.AddWithValue("@data8", DDACC)
                            command.Parameters.AddWithValue("@data9", ReferenceNo)
                            command.Parameters.AddWithValue("@data10", Session("UserId"))
                            If (con.State = ConnectionState.Open) Then
                                con.Close()
                            End If
                            con.Open()
                            command.ExecuteNonQuery()
                            con.Close()
                        End Using
                    Next
                    '
                    RemoveUndesiredRecords()
                    'insert into temp table
                    Using command As New SqlCommand("INSERT INTO Repayments_temp([Acc_No],[Branch],[Rec_No],[ADHOC_No],[ZMW],[Names],[CURRENCY],[GoodFellowNo],[DDACC],[ReferenceNo],[CapturedBy],[CaptureDate],[Customer_Number],[FileType]) select [Acc_No],[Branch],[Rec_No],[ADHOC_No],[ZMW],[Names],[CURRENCY],[GoodFellowNo],[DDACC],[ReferenceNo],[CapturedBy],[CaptureDate],(select Customer_Number from quest_application where ID=convert(numeric(18,0),[GoodFellowNo])),[FileType] from Repayments_Upload", con)
                        If (con.State = ConnectionState.Open) Then
                            con.Close()
                        End If
                        con.Open()
                        command.ExecuteNonQuery()
                        con.Close()
                    End Using
                    getUploadedRepayments()
                    'insert into into temp table
                Else
                    notify("file has no data", "error")
                End If
            End Using
        Catch ex As Exception
            notify("Error Occured, Check File Format", "error")
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- insertNew_temptable_Banks()", ex.ToString)
        End Try
    End Sub
    Protected Function FileExists(FileNo As String) As Boolean
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Using cmd = New SqlCommand("select * from Repayments_temp where ReferenceNo='" & FileNo & "' and Processed=1", con)
                Dim ds As New DataSet
                Using adp = New SqlDataAdapter(cmd)
                    adp.Fill(ds, "LRS2")
                End Using
                If ds.Tables(0).Rows.Count > 0 Then
                    Return True
                Else
                    Return False
                End If
            End Using
        End Using
    End Function
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            If FileUpload1.HasFile = False Then
                notify("Please Select File", "error")
                Exit Sub
            ElseIf cmbFileType.Text = "" Then
                notify("Please Select File Type", "error")
                Exit Sub
            ElseIf FileExists(FileUpload1.FileName) = True Then
                notify("This File have already been uploaded & posted", "error")
                Exit Sub
            Else
                'If cmbFileType.Text = "DDACC" Then
                '    insertNew_temptable_Banks()
                'Else
                '    insertNew_temptable_PMEC
                'End If
                '/////////////////
                If cmbFileType.SelectedItem.Text = "DDACC" Then
                    insertNew_temptable_Banks()
                ElseIf cmbFileType.SelectedItem.Text = "PMEC" Then
                    insertNew_temptable_PMEC()
                ElseIf cmbFileType.SelectedItem.Text = "OTHER BANKS - ZNBS" Then
                    insertNew_temptable_ZNBS()
                ElseIf cmbFileType.SelectedItem.Text = "OTHER BANKS - BANCABC" Then
                    insertNew_temptable_BANCABC()
                Else
                    notify("File Format Not Ready", "error")
                    Exit Sub
                End If
                '////////////////
            End If
        Catch ex As Exception
            notify(ex.Message.ToString, "error")
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- Button1_Click()", ex.ToString)
        End Try
    End Sub

    Function removeNULLString(ByVal myreader As DataSet, ByVal j As Integer, ByVal stval As Integer) As String

        Dim val As Object = myreader.Tables(0).Rows(j).Item(stval)
        If val IsNot DBNull.Value Then
            If val <> "" Then
                Return val.ToString()
            Else
                Return Convert.ToString("")
            End If
        Else
            Return Convert.ToString("")
        End If
    End Function
    Protected Function ImportExcel() As DataSet
        'Save the uploaded Excel file.
        Dim filePath As String = Server.MapPath("~/Docs/") + Path.GetFileName(FileUpload1.PostedFile.FileName)
        FileUpload1.SaveAs(filePath)
        'Open the Excel file using ClosedXML.
        Using workBook As New XLWorkbook(filePath)
            'Read the first Sheet from Excel file.
            Dim workSheet As IXLWorksheet = workBook.Worksheet(1)

            'Create a new DataTable.
            Dim dt As New DataTable()
            Dim dss As New DataSet()

            'Loop through the Worksheet rows.
            Dim firstRow As Boolean = True
            For Each row As IXLRow In workSheet.Rows()
                'Use the first row to add columns to DataTable.
                If firstRow Then
                    For Each cell As IXLCell In row.Cells()
                        dt.Columns.Add(cell.Value.ToString())
                    Next
                    firstRow = False
                Else
                    'Add rows to DataTable.
                    dt.Rows.Add()
                    Dim i As Integer = 0
                    For Each cell As IXLCell In row.Cells()
                        Try
                            dt.Rows(dt.Rows.Count - 1)(i) = cell.Value.ToString()
                        Catch ex As Exception
                        End Try
                        i += 1
                    Next
                End If
            Next
            dss.Tables.Add(dt)
            Return dss
        End Using
    End Function
    Protected Function ImportExcel_PMEC() As DataSet
        'Save the uploaded Excel file.
        Dim filePath As String = Server.MapPath("~/Docs/") + Path.GetFileName(FileUpload1.PostedFile.FileName)
        FileUpload1.SaveAs(filePath)
        'Open the Excel file using ClosedXML.
        Using workBook As New XLWorkbook(filePath)
            'Read the first Sheet from Excel file.
            Dim workSheet As IXLWorksheet = workBook.Worksheet(1)

            'Create a new DataTable.
            Dim dt As New DataTable()
            Dim dss As New DataSet()

            'Loop through the Worksheet rows.
            Dim firstRow As Boolean = True
            For Each row As IXLRow In workSheet.Rows()
                'Use the first row to add columns to DataTable.
                If firstRow Then
                    For Each cell As IXLCell In row.Cells()
                        dt.Columns.Add(cell.Value.ToString())
                    Next
                    firstRow = False
                Else
                    'Add rows to DataTable.
                    dt.Rows.Add()
                    Dim i As Integer = 0
                    For Each cell As IXLCell In row.Cells()
                        Try
                            dt.Rows(dt.Rows.Count - 1)(i) = cell.Value.ToString()
                        Catch ex As Exception
                        End Try
                        i += 1
                    Next
                End If
            Next
            dss.Tables.Add(dt)
            Return dss
        End Using
    End Function
    Sub getUploadedRepayments()
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("select ID,[GoodFellowNo],[Acc_No],[Branch],[Names],[ZMW],[CURRENCY],[Customer_Number] from Repayments_temp where Processed=0 and CapturedBy='" & Session("UserId") & "'", con)
                    'End if
                    Dim ds As New DataSet
                    Using adp = New SqlDataAdapter(cmd)
                        adp.Fill(ds, "LRS2")
                    End Using
                    grdRepaymentsinfile.DataSource = ds
                    grdRepaymentsinfile.DataBind()
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- getUploadedRepayments()", ex.ToString)
        End Try
    End Sub
    Sub SaveUploadedRepayments()
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("select * from Repayments_temp where Processed=0 and CapturedBy='" & Session("UserId") & "'", con)
                    Dim ds As New DataSet
                    Using adp = New SqlDataAdapter(cmd)
                        adp.Fill(ds, "LRS2")
                    End Using
                    If ds.Tables(0).Rows.Count > 0 Then
                        If AllRecordsHaveloanIDs() = False Then
                            notify("Check File, some Entries do not have valid loan IDs", "error")
                            Exit Sub
                        Else
                            For Each dr As DataRow In ds.Tables(0).Rows
                                ' saveRepayme
                                If saveRepayment(dr.Item("GoodFellowNo"), dr.Item("Customer_Number").ToString, CDbl(dr.Item("ZMW")), 0, CDbl(dr.Item("ZMW")), 0) = True Then
                                    saveTransaction(CLng(dr.Item("GoodFellowNo")), "Capital Repayment", CDbl(dr.Item("ZMW")), 0, cmbCapitalAccount.SelectedItem.Value, dr.Item("Customer_Number").ToString, "1", dr.Item("ReferenceNo").ToString, "", "", "", txtRepaymentDate.Text)
                                    updateProcessed(CLng(dr.Item("ID")))
                                    AuthoriseTrans(CLng(dr.Item("GoodFellowNo")), CDbl(dr.Item("ZMW")))
                                End If
                                ' saveRepayme
                            Next
                            Response.Write("<script>alert('Repayments posted') ; location.href='RepaymentsUpload.aspx'</script>")
                        End If
                    Else
                        notify("No Repayments Uploaded", "error")
                        Exit Sub
                    End If
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- SaveUploadedRepayments()", ex.ToString)
        End Try
    End Sub
    Private Function AllRecordsHaveloanIDs() As Boolean
        Try
            Dim k As Long = 0
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("select * from Repayments_temp where Processed=0  and CapturedBy='" & Session("UserId") & "'", con)
                    Dim ds As New DataSet
                    Using adp = New SqlDataAdapter(cmd)
                        adp.Fill(ds, "LRS2")
                    End Using
                    If ds.Tables(0).Rows.Count > 0 Then
                        For Each dr As DataRow In ds.Tables(0).Rows
                            If IsNumeric(dr.Item("GoodFellowNo").ToString) = False Or dr.Item("Customer_Number").ToString.Trim = "" Or IsNumeric(dr.Item("ZMW").ToString) = False Then
                                k = k + 1
                            End If
                        Next
                    End If
                End Using
            End Using
            If k > 0 Then
                Return False
            Else
                Return True
            End If
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- AllRecordsHaveloanIDs()", ex.ToString)
        End Try
    End Function
    Protected Sub btnSave2_Click(sender As Object, e As EventArgs) Handles btnSave2.Click
        Try
            If Not IsDate(txtRepaymentDate.Text) Then
                notify("Enter valid repayment date", "error")
                txtRepaymentDate.Focus()
            ElseIf cmbCapitalAccount.Text = "" Then
                notify("Select Account", "error")
                cmbCapitalAccount.Focus()
            ElseIf grdRepaymentsinfile.Rows.Count <= 0 Then
                notify("Load File First", "error")
                cmbCapitalAccount.Focus()
            Else
                SaveUploadedRepayments()
                UpdateAllRepaidLoans()
            End If
        Catch ex As Exception
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- btnSave2_Click()", ex.ToString)
        End Try
    End Sub
    Protected Function getBatchNo() As String
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd As New SqlCommand("select max(isnull(nullif(SUBSTRING(BatchRef,4,10),''),0)) as MaxBatch from Accounts_Transactions where Category='Loan Repayment'", con)
                    Dim ds As New DataSet
                    Dim adp = New SqlDataAdapter(cmd)
                    adp.Fill(ds, "APP")
                    Dim batchNo = ""
                    If ds.Tables(0).Rows(0).Item("MaxBatch") = 0 Then
                        batchNo = "10001"
                    Else
                        batchNo = ds.Tables(0).Rows(0).Item("MaxBatch") + 1
                    End If
                    Return "Rep" & batchNo
                End Using
            End Using
        Catch ex As Exception
            ErrorLogging.WriteLogFile(Session("UserId"), "Accounting/RepaymentAuthorization---getBatchNo()", ex.Message)
            Return "Rep10001"
        End Try
    End Function
    Sub AuthoriseTrans(Reference_No As String, amt As Double)
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd As New SqlCommand("CommitDisbursementRepayment", con)
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@loanID", Reference_No)
                    cmd.Parameters.AddWithValue("@BatchRef", getBatchNo())
                    cmd.Parameters.AddWithValue("@Category", "Loan Repayment")
                    con.Open()
                    cmd.ExecuteNonQuery()
                    con.Close()
                End Using
                Try
                    If Send_SMSon_Repayment() = True Then
                        Dim mob_number As String = getCustMobile(Reference_No)
                        WriteLogFile(Session("UserID"), "Repaymentupload.aspx", SendSMS("We have received a repayment of ZMW" & CStr(amt) & " from you, thank you for your committment, GOODFELLOW DISTRIBUTORS LIMITED", mob_number))
                    End If
                Catch ex As Exception

                End Try
            End Using
        Catch ex As Exception
            ErrorLogging.WriteLogFile(Session("UserId"), "AuthoriseTrans()", ex.Message)
        End Try
    End Sub
    Private Function getCustMobile(custNo As String) As String
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Dim cmd = New SqlCommand("select * from quest_application where ID='" & custNo & "'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "appForm")
            If ds.Tables(0).Rows.Count > 0 Then
                Dim dr As DataRow = ds.Tables(0).Rows(0)
                Return dr.Item("PHONE_NO").ToString
            Else
                Return "260"
            End If
        End Using
    End Function
    Private Function SendSMS(ByVal strMsg As String, ByVal MobNo As String) As String
        Dim SmsStatusMsg As String = String.Empty
        Try
            'Sending SMS To User
            Dim client As WebClient = New WebClient()
            Dim URL As String = "http://www.savannacom.zm/smsservices/bms_dot_php_third_party_api.php?customerid=149&from=gfdl&to=" & MobNo & "&message=" & strMsg & ""

            SmsStatusMsg = client.DownloadString(URL)
            If SmsStatusMsg.Contains("<br>") Then
                SmsStatusMsg = SmsStatusMsg.Replace("<br>", ", ")
            End If

        Catch e1 As WebException
            SmsStatusMsg = e1.Message
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- SendSMS_Click()", e1.ToString)
            ' testWrite(e1.ToString)
        Catch e2 As Exception
            SmsStatusMsg = e2.Message
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- SendSMS_Click()", e2.ToString)
            'testWrite(e2.ToString)
        End Try
        Return SmsStatusMsg
    End Function
    Private Function Send_SMSon_Repayment() As Boolean
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Dim cmd = New SqlCommand("select * from SMSCONFIG", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "appForm")
            If ds.Tables(0).Rows.Count > 0 Then
                Dim dr As DataRow = ds.Tables(0).Rows(0)
                If CBool(dr.Item("OnRepayments")) = True Then
                    Return True
                Else
                    Return False
                End If
            Else
                Return False
            End If
        End Using
    End Function

    Sub insertNew_temptable_ZNBS()
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Dim fd As New DataSet
                'fd = ImportExcel_ZNBS()
                ' fd = Import_To_Grid_ZNBS()
                fd = ImportExcel_ZNBS_NEW()
                Dim rowcount = fd.Tables(0).Rows.Count
                Dim colcount = fd.Tables(0).Columns.Count
                Dim fileName As String = FileUpload1.FileName
                Dim comm As New SqlCommand
                If rowcount > 0 Then
                    DeleteRecords()
                    For i = 0 To rowcount - 1
                        Dim ReferenceNo, Rec_no, Acc_No, Branch, ADHOC, ZMW, Namess, CURRENCY, GoodFellowNum, DDACC, NRC_NO As String
                        ReferenceNo = Trim(fileName)
                        Rec_no = "2"
                        Acc_No = Trim(removeNULLString(fd, i, 4))
                        Branch = Trim(removeNULLString(fd, i, 3))
                        ADHOC = txtRepaymentDate.Text
                        ZMW = Trim(removeNULLString(fd, i, 5))
                        Namess = Trim(removeNULLString(fd, i, 0))
                        CURRENCY = "ZMW"
                        GoodFellowNum = Trim(removeNULLString(fd, i, 2))
                        DDACC = Trim(removeNULLString(fd, i, 6))
                        NRC_NO = Trim(removeNULLString(fd, i, 1))

                        Using command As New SqlCommand("INSERT INTO Repayments_Upload([Acc_No],[Branch],[Rec_No],[ADHOC_No],[ZMW],[Names],[CURRENCY],[GoodFellowNo],[DDACC],[ReferenceNo],[CapturedBy],[CaptureDate],[FileType],[NRC_NO])VALUES(@data0,@data1,@data2,@data3,@data4,@data5,@data6,@data7,@data8,@data9,@data10,getdate(),'DDACC',@data11)", con)
                            command.Parameters.AddWithValue("@data0", Acc_No)
                            command.Parameters.AddWithValue("@data1", Branch)
                            command.Parameters.AddWithValue("@data2", Rec_no)
                            command.Parameters.AddWithValue("@data3", ADHOC)
                            command.Parameters.AddWithValue("@data4", ZMW)
                            command.Parameters.AddWithValue("@data5", Namess)
                            command.Parameters.AddWithValue("@data6", CURRENCY)
                            command.Parameters.AddWithValue("@data7", GoodFellowNum)
                            command.Parameters.AddWithValue("@data8", DDACC)
                            command.Parameters.AddWithValue("@data9", ReferenceNo)
                            command.Parameters.AddWithValue("@data10", Session("UserId"))
                            command.Parameters.AddWithValue("@data11", NRC_NO)
                            If (con.State = ConnectionState.Open) Then
                                con.Close()
                            End If
                            con.Open()
                            command.ExecuteNonQuery()
                            con.Close()
                        End Using
                    Next
                    RemoveUndesiredRecords()
                    'insert into temp table
                    Using command As New SqlCommand("INSERT INTO Repayments_temp([Acc_No],[Branch],[Rec_No],[ADHOC_No],[ZMW],[Names],[CURRENCY],[GoodFellowNo],[DDACC],[ReferenceNo],[CapturedBy],[CaptureDate],[Customer_Number],[FileType],[NRC_NO]) select [Acc_No],[Branch],[Rec_No],[ADHOC_No],[ZMW],[Names],[CURRENCY],[GoodFellowNo],[DDACC],[ReferenceNo],[CapturedBy],[CaptureDate],(select Customer_Number from quest_application where ID=convert(numeric(18,0),[GoodFellowNo])),[FileType],[NRC_NO] from Repayments_Upload where CapturedBy='" & Session("UserId") & "'", con)
                        If (con.State = ConnectionState.Open) Then
                            con.Close()
                        End If
                        con.Open()
                        command.ExecuteNonQuery()
                        con.Close()
                    End Using
                    getUploadedRepayments()
                    'insert into into temp table
                Else
                    notify("file has no data", "error")
                End If
            End Using
        Catch ex As Exception
            notify("Error Occured, Check File Format", "error")
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- insertNew_temptable_Banks()", ex.ToString)
        End Try
    End Sub
    Protected Function ImportExcel_ZNBS_NEW() As DataSet
        'Save the uploaded Excel file.
        Dim filePath As String = Server.MapPath("~/Docs/") + Path.GetFileName(FileUpload1.PostedFile.FileName)
        FileUpload1.SaveAs(filePath)

        'Open the Excel file using ClosedXML.
        Using workBook As New XLWorkbook(filePath)
            'Read the first Sheet from Excel file.
            Dim workSheet As IXLWorksheet = workBook.Worksheet(1)

            'Create a new DataTable.
            Dim dt As New DataTable()

            'Loop through the Worksheet rows.
            Dim firstRow As Boolean = True
            Dim k As Long = 0
            For Each row As IXLRow In workSheet.Rows()
                'Use the first row to add columns to DataTable.
                k = k + 1
                If row.RowNumber >= 5 Then
                    If firstRow Then
                        For Each cell As IXLCell In row.Cells()
                            dt.Columns.Add(cell.Value.ToString())
                        Next
                        firstRow = False
                    Else
                        'Add rows to DataTable.
                        dt.Rows.Add()
                        Dim i As Integer = 0
                        For Each cell As IXLCell In row.Cells()
                            dt.Rows(dt.Rows.Count - 1)(i) = cell.Value.ToString()
                            i += 1
                        Next
                    End If
                End If
            Next
            Dim dss As New DataSet()
            dss.Tables.Add(dt)
            Return dss
        End Using
    End Function
    Protected Sub RemoveUndesiredRecords()
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Using cmd As New SqlCommand("delete from [Repayments_Upload] where (Names is NULL OR Names='') and CapturedBy ='" & Session("UserId") & "'", con)
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub
    Sub insertNew_temptable_BANCABC()
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Dim fd As New DataSet
                fd = ImportExcel_BANCABC_NEW()
                ' fd = ImportExcel_BANCABC_An_()
                Dim rowcount = fd.Tables(0).Rows.Count
                Dim colcount = fd.Tables(0).Columns.Count
                Dim fileName As String = FileUpload1.FileName
                Dim comm As New SqlCommand
                If rowcount > 0 Then
                    DeleteRecords()
                    For i = 0 To rowcount - 1
                        Dim ReferenceNo, Rec_no, Acc_No, Branch, ADHOC, ZMW, Namess, CURRENCY, GoodFellowNum, DDACC, NRC_NO As String
                        ReferenceNo = Trim(fileName)
                        Rec_no = "2"
                        Acc_No = Trim(removeNULLString(fd, i, 1))
                        Branch = Trim(removeNULLString(fd, i, 2))
                        ADHOC = Trim(removeNULLString(fd, i, 3))
                        ZMW = Trim(removeNULLString(fd, i, 4))
                        Namess = Trim(removeNULLString(fd, i, 5))
                        CURRENCY = Trim(removeNULLString(fd, i, 6))
                        GoodFellowNum = Trim(removeNULLString(fd, i, 7))
                        DDACC = Trim(removeNULLString(fd, i, 8))
                        NRC_NO = Trim(removeNULLString(fd, i, 9))

                        Using command As New SqlCommand("INSERT INTO Repayments_Upload([Acc_No],[Branch],[Rec_No],[ADHOC_No],[ZMW],[Names],[CURRENCY],[GoodFellowNo],[DDACC],[ReferenceNo],[CapturedBy],[CaptureDate],[FileType],[NRC_NO])VALUES(@data0,@data1,@data2,@data3,@data4,@data5,@data6,@data7,@data8,@data9,@data10,getdate(),'DDACC',@data11)", con)
                            command.Parameters.AddWithValue("@data0", Acc_No)
                            command.Parameters.AddWithValue("@data1", Branch)
                            command.Parameters.AddWithValue("@data2", Rec_no)
                            command.Parameters.AddWithValue("@data3", ADHOC)
                            command.Parameters.AddWithValue("@data4", ZMW)
                            command.Parameters.AddWithValue("@data5", Namess)
                            command.Parameters.AddWithValue("@data6", CURRENCY)
                            command.Parameters.AddWithValue("@data7", GoodFellowNum)
                            command.Parameters.AddWithValue("@data8", DDACC)
                            command.Parameters.AddWithValue("@data9", ReferenceNo)
                            command.Parameters.AddWithValue("@data10", Session("UserId"))
                            command.Parameters.AddWithValue("@data11", NRC_NO)
                            If (con.State = ConnectionState.Open) Then
                                con.Close()
                            End If
                            con.Open()
                            command.ExecuteNonQuery()
                            con.Close()
                        End Using
                    Next
                    RemoveUndesiredRecords()
                    'insert into temp table
                    Using command As New SqlCommand("INSERT INTO Repayments_temp([Acc_No],[Branch],[Rec_No],[ADHOC_No],[ZMW],[Names],[CURRENCY],[GoodFellowNo],[DDACC],[ReferenceNo],[CapturedBy],[CaptureDate],[Customer_Number],[FileType],[NRC_NO]) select [Acc_No],[Branch],[Rec_No],[ADHOC_No],[ZMW],[Names],[CURRENCY],[GoodFellowNo],[DDACC],[ReferenceNo],[CapturedBy],[CaptureDate],(select Customer_Number from quest_application where ID=convert(numeric(18,0),[GoodFellowNo])),[FileType],[NRC_NO] from Repayments_Upload where CapturedBy='" & Session("UserId") & "'", con)
                        If (con.State = ConnectionState.Open) Then
                            con.Close()
                        End If
                        con.Open()
                        command.ExecuteNonQuery()
                        con.Close()
                    End Using
                    getUploadedRepayments()
                    'insert into into temp table
                Else
                    notify("file has no data", "error")
                End If
            End Using
        Catch ex As Exception
            notify("Error Occured, Check File Format", "error")
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- insertNew_temptable_Banks()", ex.ToString)
        End Try
    End Sub
    Protected Function ImportExcel_BANCABC_NEW() As DataSet
        'Save the uploaded Excel file.
        Dim filePath As String = Server.MapPath("~/Docs/") + Path.GetFileName(FileUpload1.PostedFile.FileName)
        FileUpload1.SaveAs(filePath)

        'Open the Excel file using ClosedXML.
        Using workBook As New XLWorkbook(filePath)
            'Read the first Sheet from Excel file.
            Dim workSheet As IXLWorksheet = workBook.Worksheet(1)

            'Create a new DataTable.
            Dim dt As New DataTable()

            'Loop through the Worksheet rows.
            Dim firstRow As Boolean = True
            For Each row As IXLRow In workSheet.Rows()
                'Use the first row to add columns to DataTable.
                If firstRow Then
                    For Each cell As IXLCell In row.Cells()
                        dt.Columns.Add(cell.Value.ToString())
                    Next
                    dt.Rows.Add()
                    Dim k As Integer = 0
                    For Each cell As IXLCell In row.Cells()
                        dt.Rows(dt.Rows.Count - 1)(k) = cell.Value.ToString()
                        k += 1
                    Next
                    firstRow = False
                Else
                    'Add rows to DataTable.
                    dt.Rows.Add()
                    Dim i As Integer = 0
                    For Each cell As IXLCell In row.Cells()
                        dt.Rows(dt.Rows.Count - 1)(i) = cell.Value.ToString()
                        i += 1
                    Next
                End If
            Next
            '  msgbox("test")
            Dim dss As New DataSet()
            dss.Tables.Add(dt)
            Return dss
        End Using
    End Function
End Class