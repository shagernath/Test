﻿Imports System.Data
Imports System.Data.SqlClient
Imports CreditManager
Imports ErrorLogging
Imports BankString
Imports System.Xml
Imports System.Net

Partial Class Credit_Repayment_MultipleLoans
    Inherits System.Web.UI.Page
    Protected Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            If Trim(txtCustNo.Text) = "" Then
                notify("Enter the customer number", "error")
                txtCustNo.Focus()
            ElseIf Not IsNumeric(txtTotalAmount.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", "")) Then
                notify("Enter numeric value for total amount", "error")
                txtTotalAmount.Text = "0"
                txtTotalAmount.Focus()
            ElseIf CDbl(txtTotalAmount.Text.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", "").Replace("ZMW", "")) <= 0 Then
                notify("Enter numeric value for total amount", "error")
                txtTotalAmount.Text = "0"
                txtTotalAmount.Focus()
            ElseIf Not IsDate(txtRepaymentDate.Text) Then
                notify("Enter valid repayment date", "error")
                txtRepaymentDate.Focus()
            ElseIf toMoney(txtTotalAmount.Text) <> CustTotal() Then
                ' msgbox(CustTotal())
                notify("Total Amount not Properly allocated", "error")
                txtTotalAmount.Focus()
            Else
                saveMultipleRepayments()
                UpdateAllRepaidLoans()
                'send SMS=----------------------------------------------------------------------------------
                Try
                    If Send_SMSon_Repayment() = True Then
                        Dim mob_number As String = getCustMobile(txtCustNo.Text)
                        WriteLogFile(Session("UserID"), "RepaymentMultipleLoans.aspx", SendSMS("We have received a repayment Of ZMW" & txtTotalAmount.Text & " from you, thank you For your committment, GOODFELLOW DISTRIBUTORS LIMITED", mob_number))
                    End If
                Catch ex As Exception
                    WriteLogFile(Session("UserId"), Request.Url.ToString & " --- btnSave_Click()", ex.ToString)
                End Try
                Response.Write("<script>alert('Repayment saved') ; location.href='RepaymentMultipleLoans.aspx'</script>")
            End If
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- btnSave_Click()", ex.ToString)
        End Try
    End Sub
    Private Function CustTotal() As Double
        Try
            If repGrpMembers.Items.Count > 0 Then
                Dim tot As Double = 0
                For Each loanRef As RepeaterItem In repGrpMembers.Items
                    Dim allocated As Double = CType(loanRef.FindControl("txtAmountToPay"), TextBox).Text
                    tot = tot + allocated
                Next
                Return tot
            Else
                Return 0
            End If
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- saveRepayment()", ex.ToString)
            Return 0
        End Try
    End Function
    Private Function getCustMobile(custNo As String) As String
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Dim cmd = New SqlCommand("select * from customer_details where Customer_number='" & custNo & "'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "appForm")
            If ds.Tables(0).Rows.Count > 0 Then
                Dim dr As DataRow = ds.Tables(0).Rows(0)
                Return dr.Item("PHONE_NO").ToString
            Else
                Return "260"
            End If
        End Using
    End Function
    Private Function SendSMS(ByVal strMsg As String, ByVal MobNo As String) As String
        Dim SmsStatusMsg As String = String.Empty
        Try
            'Sending SMS To User
            Dim client As WebClient = New WebClient()
            Dim URL As String = "http://www.savannacom.zm/smsservices/bms_dot_php_third_party_api.php?customerid=149&from=gfdl&to=" & MobNo & "&message=" & strMsg & ""

            SmsStatusMsg = client.DownloadString(URL)
            If SmsStatusMsg.Contains("<br>") Then
                SmsStatusMsg = SmsStatusMsg.Replace("<br>", ", ")
            End If

        Catch e1 As WebException
            SmsStatusMsg = e1.Message
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- SendSMS_Click()", e1.ToString)
            ' testWrite(e1.ToString)
        Catch e2 As Exception
            SmsStatusMsg = e2.Message
            ErrorLogging.WriteLogFile(Session("UserId"), Request.Url.ToString & " --- SendSMS_Click()", e2.ToString)
            'testWrite(e2.ToString)
        End Try
        Return SmsStatusMsg
    End Function
    Private Function Send_SMSon_Repayment() As Boolean
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Dim cmd = New SqlCommand("select * from SMSCONFIG", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "appForm")
            If ds.Tables(0).Rows.Count > 0 Then
                Dim dr As DataRow = ds.Tables(0).Rows(0)
                If CBool(dr.Item("OnRepayments")) = True Then
                    Return True
                Else
                    Return False
                End If
            Else
                Return False
            End If
        End Using
    End Function

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True

        If Not IsPostBack Then
        End If
    End Sub
    Protected Function toMoney(inp As String) As Double
        If inp = "" Then
            inp = 0
        End If
        Return inp.Replace("US", "").Replace("$", "").Replace(",", "").Replace("Z", "")
    End Function
    Protected Sub UpdateAllRepaidLoans()
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Using cmd As New SqlCommand("update QUEST_APPLICATION set status='REPAID' where convert(varchar,id) in (select refrence from Accounts_Transactions acct where account in (select customer_number from CUSTOMER_DETAILS) group by Refrence having sum(debit-credit)<=0)", con)
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub
    Sub cleardata()
        repGrpMembers.DataSource = Nothing
        repGrpMembers.DataBind()
        txtTotalAmount.Text = "0"
        txtRepaymentDate.Text = ""
    End Sub
    Protected Sub getNameBy_CustNo(cust As String)
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Dim cmd = New SqlCommand("select CUSTOMER_NUMBER,isnull([SURNAME],' ') + ' ' + isnull([FORENAMES],' ') + ' - ' + isnull([CUSTOMER_NUMBER],' ') as namess from CUSTOMER_DETAILS where CUSTOMER_NUMBER='" & cust & "'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "QGM")
            If ds.Tables(0).Rows.Count > 0 Then
                lstLoans.DataSource = ds.Tables(0)
                lstLoans.DataTextField = "Namess"
                lstLoans.DataValueField = "CUSTOMER_NUMBER"
                lstLoans.Visible = True
            Else
                lstLoans.DataSource = Nothing
                lstLoans.Visible = False
            End If
            lstLoans.DataBind()
        End Using
    End Sub
    Protected Sub getNameBy_Names(namess As String)
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Dim cmd = New SqlCommand("select CUSTOMER_NUMBER,isnull([SURNAME],' ') + ' ' + isnull([FORENAMES],' ') + ' - ' + isnull([CUSTOMER_NUMBER],' ') as namess from CUSTOMER_DETAILS where isnull([SURNAME],' ') + ' ' + isnull([FORENAMES],' ') like '%" & namess & "%'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "QGM")
            If ds.Tables(0).Rows.Count > 0 Then
                lstLoans.DataSource = ds.Tables(0)
                lstLoans.DataTextField = "Namess"
                lstLoans.DataValueField = "CUSTOMER_NUMBER"
                lstLoans.Visible = True
            Else
                lstLoans.DataSource = Nothing
                lstLoans.Visible = False
            End If
            lstLoans.DataBind()
        End Using
    End Sub
    Protected Sub getCustomerLoans(cust As String)
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Dim cmd = New SqlCommand("select q.ID AS [Loan ID],q.FIN_AMT AS [Loan Amount],convert(varchar(24),q.DISBURSED_DATE,106) as [Disbursed Date],(select isnull(sum(x.payment),0) from AMORTIZATION_SCHEDULE x where x.LOANID=q.ID)-(select isnull(sum(z.TotalAmount),0) from Repayments z where z.LOANID=q.ID) as Installment  from QUEST_APPLICATION q where q.CUSTOMER_NUMBER='" & cust & "' and q.STATUS<>'REPAID' and disbursed=1 order by q.DISBURSED_DATE asc", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "QGM")
            If ds.Tables(0).Rows.Count > 0 Then
                repGrpMembers.DataSource = ds.Tables(0)
            Else
                repGrpMembers.DataSource = Nothing
            End If
            repGrpMembers.DataBind()
        End Using
    End Sub
    Protected Sub btnSearchCustNo_Click(sender As Object, e As EventArgs) Handles btnSearchCustNo.Click
        If txtCustNo.Text <> "" Then
            cleardata()
            getNameBy_CustNo(Trim(txtCustNo.Text))
        Else
            msgbox("Enter Customer Number")
        End If
    End Sub
    Protected Sub btnSearchName_Click(sender As Object, e As EventArgs) Handles btnSearchName.Click
        If txtApplicantName.Text <> "" Then
            cleardata()
            getNameBy_Names(Trim(txtApplicantName.Text))
        Else
            msgbox("Enter Search Name")
        End If
    End Sub
    Protected Sub lstLoans_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstLoans.SelectedIndexChanged
        txtCustNo.Text = lstLoans.SelectedValue
        getCustomerLoans(lstLoans.SelectedValue)
    End Sub
    Protected Sub saveMultipleRepayments()
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            For Each loanRef As RepeaterItem In repGrpMembers.Items
                Dim LoanID As String = CType(loanRef.FindControl("lblLoanID"), Label).Text
                Dim amt As String = CType(loanRef.FindControl("txtAmountToPay"), TextBox).Text
                If toMoney(amt) > 0 Then
                    saveRepayment(LoanID, toMoney(amt), 0, 0, toMoney(amt))
                    save_Transaction(LoanID, "Capital Repayment", toMoney(amt), 0, "LO/" & Session("ID").ToString(), txtCustNo.Text, "1", "Cash Receipting " & Session("UserID"), "", "", "", txtRepaymentDate.Text)
                End If
            Next
        End Using
    End Sub
    Protected Sub txtTotalAmount_TextChanged(sender As Object, e As EventArgs) Handles txtTotalAmount.TextChanged
        allocateTotalAmount()
    End Sub
    Protected Sub saveRepayment(ByVal loanid As String, ByVal principal As Double, ByVal interest As Double, ByVal penalty As Double, ByVal totalAmount As Double)
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd As New SqlCommand("SaveRepayment", con)
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@loanID", loanid)
                    cmd.Parameters.AddWithValue("@CustNo", txtCustNo.Text)
                    cmd.Parameters.AddWithValue("@TrxnDate", txtRepaymentDate.Text)
                    cmd.Parameters.AddWithValue("@Interest", interest)
                    cmd.Parameters.AddWithValue("@Principal", principal)
                    cmd.Parameters.AddWithValue("@Penalty", penalty)
                    cmd.Parameters.AddWithValue("@TotalAmount", totalAmount)
                    cmd.Parameters.AddWithValue("@RolloverBalance", 0)
                    cmd.Parameters.AddWithValue("@InterestNextPmt", 0)
                    cmd.Parameters.AddWithValue("@NextPmtTotal", 0)
                    cmd.Parameters.AddWithValue("@CapturedBy", Session("UserId"))
                    If con.State = ConnectionState.Open Then
                        con.Close()
                    End If
                    con.Open()
                    If cmd.ExecuteNonQuery() Then
                    Else
                        notify("Error saving repayment", "error")
                    End If
                    con.Close()
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- saveRepayment()", ex.ToString)
        End Try
    End Sub
    Protected Sub save_Transaction(reference As String, description As String, debit As Double, credit As Double, account As String, contra As String, status As String, other As String, bankAccId As String, bankAccName As String, batchRef As String, trxnDate As Date)
        Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            Using cmd As New SqlCommand("SaveAccountsTrxnsTempWithContra", con)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Parameters.AddWithValue("@Type", "System Entry")
                cmd.Parameters.AddWithValue("@Category", "Loan Repayment")
                cmd.Parameters.AddWithValue("@Ref", reference)
                cmd.Parameters.AddWithValue("@Desc", description)
                cmd.Parameters.AddWithValue("@Debit", debit)
                cmd.Parameters.AddWithValue("@Credit", credit)
                cmd.Parameters.AddWithValue("@Account", account)
                cmd.Parameters.AddWithValue("@ContraAccount", contra)
                cmd.Parameters.AddWithValue("@Status", status)
                cmd.Parameters.AddWithValue("@Other", other)
                cmd.Parameters.AddWithValue("@BankAccID", bankAccId)
                cmd.Parameters.AddWithValue("@BankAccName", bankAccName)
                cmd.Parameters.AddWithValue("@BatchRef", batchRef)
                cmd.Parameters.AddWithValue("@TrxnDate", trxnDate)
                cmd.Parameters.AddWithValue("@CaptureBy", Session("UserId"))

                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        End Using
    End Sub
    Sub allocateTotalAmount()
        Try
            If repGrpMembers.Items.Count > 0 Then
                If Trim(txtTotalAmount.Text) <> "" Then
                    If IsNumeric(Trim(txtTotalAmount.Text)) = True Then
                        If CDbl(Trim(txtTotalAmount.Text)) > 0 Then
                            Dim RemBal As Double = toMoney(txtTotalAmount.Text)
                            For Each loanRef As RepeaterItem In repGrpMembers.Items
                                Dim installment As Double = CType(loanRef.FindControl("lblInstallment"), Label).Text
                                If RemBal > installment Then
                                    CType(loanRef.FindControl("txtAmountToPay"), TextBox).Text = installment
                                    RemBal = RemBal - installment
                                Else
                                    CType(loanRef.FindControl("txtAmountToPay"), TextBox).Text = RemBal
                                    RemBal = 0
                                End If
                            Next
                        End If
                    End If
                End If
            Else
                msgbox("Select Client First")
                Exit Sub
            End If
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- allocateTotalAmount()", ex.ToString)
        End Try
    End Sub
End Class