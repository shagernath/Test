﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports ClosedXML.Excel
Imports ErrorLogging
Imports CreditManager
Partial Class Credit_Amortization
    Inherits System.Web.UI.Page
    Public Shared firstPayDate, paymentDate As Date
    Public Shared intRate, monthlyPrincipal, loanAmount, paymentPeriod, finalMonthlyPayment, interest As Double
    Public Shared isApproval As Double = 0
    Shared adp As New SqlDataAdapter
    Shared cmd As SqlCommand
    Shared con As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
    Public Shared Function convertToSaveFormat(ByVal dbl As String) As String
        If dbl.ToString.Contains(",") Then
            dbl = dbl.ToString.Replace(",", ".")
        End If
        Return dbl
    End Function
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True
        If Not IsPostBack Then
            loadBanks(cmbBanks)
            loadBranches_local()
            'loadLOOfficers()
        End If
    End Sub
    Protected Sub loadLOOfficers()
        Try
            cmd = New SqlCommand("select USERID,USER_LOGIN from MASTER_USERS order by user_Login asc", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "MASTER_USERS")
            If ds.Tables(0).Rows.Count > 0 Then
                cmbLoanOfficer.DataSource = ds.Tables(0)
                cmbLoanOfficer.DataTextField = "USER_LOGIN"
                cmbLoanOfficer.DataValueField = "USERID"
            Else
                cmbLoanOfficer.DataSource = Nothing
            End If
            cmbLoanOfficer.DataBind()
            loadLOOfficers_SpecBranch()
        Catch ex As Exception
        End Try
    End Sub
    Protected Sub loadBranches_local()
        Try
            cmd = New SqlCommand("select * from BNCH_DETAILS", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "bnch")
            If ds.Tables(0).Rows.Count > 0 Then
                cmbBranch.DataSource = ds.Tables(0)
                cmbBranch.DataTextField = "BNCH_NAME"
                cmbBranch.DataValueField = "BNCH_CODE"
            Else
                cmbBranch.DataSource = Nothing
            End If
            cmbBranch.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Sub addall()
        Dim l As New ListItem("All", "All", True)
        l.Selected = True
        cmbBranch.Items.Add(l)
    End Sub
    Protected Sub loadBanks(cmbBank As DropDownList)
        Try
            cmd = New SqlCommand("select * from para_bank", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "BANK")
            CreditManager.loadCombo(ds.Tables(0), cmbBank, "BANK_NAME", "BANK")
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            'exportdata_Udean()
            If cmbBranch.Text = "" Then
                notify("Select Branch", "error")
                Exit Sub
            ElseIf cmbLoanOfficer.Text = "" Then
                notify("Select Loan Officer", "error")
                Exit Sub
            Else
                ExportData_Excel()
            End If
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & "Button1_Click()", ex.ToString)
            msgbox(ex.Message.ToString)
        End Try
    End Sub
    Protected Sub GetBank_OtherDetails(Bankk As String)
        Try
            cmd = New SqlCommand("select * from para_bank where bank_name='" & Bankk & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "para_bank")
            If ds.Tables(0).Rows.Count > 0 Then
                ViewState("MainAccount") = ds.Tables(0).Rows(0).Item("MainAccount").ToString
                ViewState("MainBranch") = ds.Tables(0).Rows(0).Item("MainBranch").ToString
            Else
                ViewState("MainAccount") = ""
                ViewState("MainBranch") = ""
            End If
        Catch ex As Exception
            ViewState("MainAccount") = ""
            ViewState("MainBranch") = ""
        End Try
    End Sub
    Sub ExportData_Excel()
        If bdpfrom.Text = "" Then
            notify("From Date is required", "error")
            bdpfrom.Focus()
            Exit Sub
        ElseIf bdpTo.Text = "" Then
            notify("To Date is required", "error")
            bdpTo.Focus()
            Exit Sub
        End If
        If rdbFinReqDisburseOption.SelectedIndex < 0 Then
            notify("Please select a transaction type", "error")
            Exit Sub
        End If
        Dim additional_Str As String = ""
        If cmbBranch.SelectedItem.Value = "All" Then
            additional_Str = ""
        Else
            additional_Str = " And QUEST_APPLICATION.BRANCH_CODE='" & cmbBranch.SelectedItem.Value & "'"
        End If

        If cmbLoanOfficer.SelectedItem.Value = "All" Then
            additional_Str = additional_Str & ""
        Else
            additional_Str = additional_Str & " And QUEST_APPLICATION.CREATED_BY='" & cmbLoanOfficer.SelectedItem.Text & "'"
        End If


        If rdbFinReqDisburseOption.SelectedIndex = 1 Then
            If cmbBanks.Text = "" Then
                notify("Select Bank", "error")
                Exit Sub
            Else
                GetBank_OtherDetails(cmbBanks.SelectedItem.Text)
                Dim constr As String = ConfigurationManager.ConnectionStrings("Constring").ConnectionString
                Using con As New SqlConnection(constr)
                    Dim Date1 As Date = CDate(bdpfrom.Text).ToString("dd MMM yyyy")
                    Dim Date2 As Date = CDate(bdpTo.Text).ToString("dd MMM yyyy")
                    Dim bank As String = cmbBanks.SelectedItem.Text.ToUpper ','D' As BATCH,'" & cmbBanks.SelectedItem.Text & "' As DestinationBank,'001' as SPID,Quest_Application.CUSTOMER_NUMBER AS CUSTNO
                    Using cmd As New SqlCommand("select '2',(CASE WHEN Quest_Application.BankAccountNo='' THEN Customer_Details.BankAccountNo ELSE Quest_Application.BankAccountNo END) As DestinationAccount,(CASE WHEN Quest_Application.BranchCode='' THEN CUSTOMER_DETAILS.BranchCode ELSE Quest_Application.BranchCode END) AS DestinationBranch,FORMAT(GETDATE(),'ddMMyyyy', 'en-us') As SPIDDATE,(select top 1 PAYMENT FROM AMORTIZATION_SCHEDULE a where a.loanid=Quest_Application.ID order by a.id asc) as Amount,CUSTOMER_DETAILS.FORENAMES +' '+ CUSTOMER_DETAILS.SURNAME AS BenificiaryName,'ZMW' as Currency,(Case when len(CONVERT(VARCHAR,QUEST_APPLICATION.ID))<=8 then RIGHT('00000000'+CONVERT(VARCHAR,QUEST_APPLICATION.ID),8) else CONVERT(VARCHAR,QUEST_APPLICATION.ID) end) as loanid,UPPER('GF '+ UPPER(DATENAME(MM, (select top 1 p.PAYMENT_DATE FROM AMORTIZATION_SCHEDULE p where p.loanid=Quest_Application.ID AND p.PAYMENT_DATE BETWEEN '" & bdpfrom.Text & "' And '" & bdpTo.Text & "' order by p.id asc))) +' DDACC') As Ref from Quest_Application inner join Customer_Details on Quest_Application.CUSTOMER_NUMBER=Customer_Details.CUSTOMER_NUMBER where Quest_Application.Bank='" & cmbBanks.SelectedItem.Text & "' and QUEST_APPLICATION.DISBURSED=1 And QUEST_APPLICATION.ID IN(SELECT k.LOANID from AMORTIZATION_SCHEDULE k where k.PAYMENT_DATE BETWEEN '" & bdpfrom.Text & "' And '" & bdpTo.Text & "') And QUEST_APPLICATION.DISBURSE_OPTION='DDebit' AND isnull(QUEST_APPLICATION.ExportedFileTimes,0)<>0 " & additional_Str, con)
                        Using sda As New SqlDataAdapter()
                            cmd.Connection = con
                            sda.SelectCommand = cmd
                            Dim sw As New StringWriter()
                            Using dt As New DataTable()
                                sda.Fill(dt)
                                If dt.Rows.Count <= 0 Then
                                    msgbox("No disbursed loans to export")
                                Else
                                    Dim totAMT As Double = 0
                                    For Each dr As DataRow In dt.Rows
                                        totAMT = totAMT + CDbl(dr.Item("Amount"))
                                        Exporter(dr.Item("loanid"))
                                        Exporter_InsertHistory(dr.Item("loanid").ToString, "DDACC", dr.Item("Ref").ToString, "0")
                                    Next
                                    Using wb As New XLWorkbook()
                                        Dim Coverpage_dset = dt
                                        Dim ws = wb.Worksheets.Add(bank)
                                        ws.FirstRow().FirstCell().InsertData(dt.Rows).InsertRowsAbove(1)
                                        'wb.Worksheets.Add(Coverpage_dset, bank).Row(1).InsertRowsAbove(1)
                                        'wb.FirstRow().FirstCell().InsertData(dt.Rows);
                                        wb.Worksheet(bank).Row(1).Cell("A").SetValue("1")
                                        wb.Worksheet(bank).Row(1).Cell("B").SetValue(ViewState("MainAccount"))
                                        wb.Worksheet(bank).Row(1).Cell("C").SetValue(ViewState("MainBranch"))
                                        wb.Worksheet(bank).Row(1).Cell("D").SetValue("ADHOC")
                                        wb.Worksheet(bank).Row(1).Cell("E").SetValue("ZMW")
                                        wb.Worksheet(bank).Row(1).Cell("F").SetValue(Date1.ToString("MMMM").ToUpper & " DDACC")
                                        wb.Worksheet(bank).Row(1).Cell("G").SetValue(totAMT)
                                        wb.Worksheet(bank).Row(1).Cell("H").SetValue("Good fellow")
                                        wb.Worksheet(bank).Row(1).Cell("I").SetValue("Lusaka")
                                        wb.Worksheet(bank).Row(1).Cell("J").SetValue("0002")
                                        Response.Clear()
                                        Response.Buffer = True
                                        Response.Charset = ""
                                        Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                        Response.AddHeader("content-disposition", "attachment;filename=" & Date1.ToString("MMMyyyy").ToUpper & "_" & bank.Replace(" ", "_") & "_GFDL.xlsx")
                                        Using MyMemoryStream As New MemoryStream()
                                            wb.SaveAs(MyMemoryStream)
                                            MyMemoryStream.WriteTo(Response.OutputStream)
                                            Response.Flush()
                                            Response.End()
                                        End Using
                                    End Using
                                End If
                            End Using
                        End Using
                    End Using
                End Using
            End If
        Else
            'download PMEC
            Dim constr As String = ConfigurationManager.ConnectionStrings("Constring").ConnectionString
            Dim csv As String = String.Empty
            Using con As New SqlConnection(constr)
                Dim Date1 As Date = bdpfrom.Text
                Dim Date2 As Date = bdpTo.Text
                Dim bank As String = Date1.ToString("MMMM") & "_PMEC" 'Quest_Application.ID as loanid,
                'Using cmd As New SqlCommand("select CUSTOMER_DETAILS.CUSTOMER_NUMBER As PERNR,'' AS [OLD WAGE TYPE],'8000' As LGART,FORMAT((SELECT TOP 1 DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,CONVERT(date,PAYMENT_DATE,6))+1,0)) FROM AMORTIZATION_SCHEDULE where LOANID=Quest_Application.ID ORDER BY ID DESC),'dd.M.yyyy', 'en-us') AS ENDDA,FORMAT(Quest_Application.FIN_REPAY_DATE,'dd.M.yyyy', 'en-us') As BEGDA ,Quest_Application.Amt_Applied As BETRG,'E275' As EMFSL,'E' As ZLSCH,CUSTOMER_DETAILS.SURNAME+' '+CUSTOMER_DETAILS.FORENAMES AS BenificiaryName,CUSTOMER_DETAILS.IDNO as NCR  from Customer_Details inner join Quest_Application on CUSTOMER_DETAILS.CUSTOMER_NUMBER=Quest_Application.CUSTOMER_NUMBER where Quest_Application.DISBURSED='1' And Quest_Application.Issue_DATE>='" + Date1.ToString("dd MMM yyyy") + "' And Quest_Application.Issue_DATE<=DATEADD(day,1,'" + Date2.ToString("dd MMM yyyy") + "') And  DISBURSE_OPTION<>'DDebit' And QUEST_APPLICATION.ExportedFile<>'1' ", con)
                Using cmd As New SqlCommand("select Quest_Application.ID As PERNR,'' AS [OLD WAGE TYPE],'8000' As LGART,FORMAT((SELECT TOP 1 DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,CONVERT(date,PAYMENT_DATE,6))+1,0)) FROM AMORTIZATION_SCHEDULE where LOANID=Quest_Application.ID ORDER BY ID DESC),'dd.M.yyyy', 'en-us') AS ENDDA,FORMAT((SELECT TOP 1 DATEADD(month, DATEDIFF(month, 0,PAYMENT_DATE), 0) FROM AMORTIZATION_SCHEDULE where LOANID=Quest_Application.ID ORDER BY ID ASC),'dd.M.yyyy', 'en-us') AS BEGDA,(SELECT TOP 1 PAYMENT FROM AMORTIZATION_SCHEDULE where LOANID=Quest_Application.ID ORDER BY ID ASC) As BETRG,'E275' As EMFSL,'E' As ZLSCH,CUSTOMER_DETAILS.FORENAMES+' '+CUSTOMER_DETAILS.SURNAME AS [NAME],CUSTOMER_DETAILS.IDNO as [NCR NUMBER]  from Customer_Details inner join Quest_Application on CUSTOMER_DETAILS.CUSTOMER_NUMBER=Quest_Application.CUSTOMER_NUMBER where Quest_Application.DISBURSED='1' And Quest_Application.FIN_REPAY_DATE BETWEEN '" & bdpfrom.Text & "' AND '" & bdpTo.Text & "' And  DISBURSE_OPTION<>'DDebit' and DISBURSE_OPTION<>'Cash' And Quest_Application.ExportedFile<>1 " & additional_Str, con)
                    Using sda As New SqlDataAdapter()
                        cmd.Connection = con
                        sda.SelectCommand = cmd
                        Dim sw As New StringWriter()
                        Using dt As New DataTable()
                            sda.Fill(dt)
                            If dt.Rows.Count <= 0 Then
                                notify("No disbursed loans to export", "error")
                            Else
                                For Each dr As DataRow In dt.Rows
                                    Exporter(dr.Item("PERNR"))
                                    Exporter_InsertHistory(dr.Item("PERNR").ToString, "PMEC", bank, "0")
                                Next
                                Using wb As New XLWorkbook()
                                    Dim Coverpage_dset = dt
                                    wb.Worksheets.Add(Coverpage_dset, bank).Row(1).InsertRowsAbove(10)
                                    wb.Worksheet(bank).Row(1).Cell("A").SetValue("Date: " & Date.Now.ToString("dd MMMM yyyy"))
                                    wb.Worksheet(bank).Row(2).Cell("E").SetValue("THIRD PARTY SUBMISSION")
                                    wb.Worksheet(bank).Row(4).Cell("A").SetValue("PMEC OFFICE:___________________________________________")
                                    wb.Worksheet(bank).Row(6).Cell("A").SetValue("NAME OF INSTITUTION(THIRD PARTY):  GOODFELLOW DISTRIBUTORS")
                                    wb.Worksheet(bank).Row(8).Cell("A").SetValue("MONTH :")
                                    wb.Worksheet(bank).Row(8).Cell("B").SetValue(Date1.ToString("MMM-yyyy"))
                                    Dim k = wb.Worksheet(bank).LastRowUsed.RowNumber
                                    wb.Worksheet(bank).Row(k + 4).Cell("A").SetValue("PREPARED BY…………………………………………………………………………………………………………………..")
                                    wb.Worksheet(bank).Row(k + 6).Cell("A").SetValue("CHECKED BY…………………………………………………………………………………………………………………….")
                                    wb.Worksheet(bank).Row(k + 8).Cell("A").SetValue("RECEIVED BY…………………………………………………………………………………………………………………….")
                                    Response.Clear()
                                    Response.Buffer = True
                                    Response.Charset = ""
                                    Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                    Response.AddHeader("content-disposition", "attachment;filename=GOODFELLOW_DISTRIBUTORS_LTD_" & Date1.ToString("MMM_yyyy").ToUpper & "_SUBMISSION_file.xlsx")
                                    Using MyMemoryStream As New MemoryStream()
                                        wb.SaveAs(MyMemoryStream)
                                        MyMemoryStream.WriteTo(Response.OutputStream)
                                        Response.Flush()
                                        Response.End()
                                    End Using
                                End Using
                            End If
                        End Using
                    End Using
                End Using
            End Using
        End If
    End Sub
    Public Sub msgbox(ByVal strMessage As String)

        'finishes server processing, returns to client.
        Dim strScript As String = "<script language=JavaScript>"
        strScript += "window.alert(""" & strMessage & """);"
        strScript += "</script>"
        Dim lbl As New System.Web.UI.WebControls.Label
        lbl.Text = strScript
        Page.Controls.Add(lbl)
    End Sub
    Public Sub Exporter_InsertHistory(s As String, ftype As String, ppdddate As String, fileNo As String)
        cmd = New SqlCommand("insert into Downloads(LoanID, FileType, PMECDDACCDate, DownloadBy, FileNo)values('" & s & "','" & ftype & "','" & ppdddate & "','" & Session("UserId") & "','" & fileNo & "')", con)
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
    End Sub
    Public Sub Exporter(s As String)
        cmd = New SqlCommand("Update Quest_Application set ExportedFile=1,ExportedFileTimes=ExportedFileTimes-1,ExportedFileDate=getdate(),MarkedForredownload=0 where ID='" & s & "' ", con)
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
    End Sub
    Protected Sub rdbFinReqDisburseOption_SelectedIndexChanged(sender As Object, e As EventArgs) Handles rdbFinReqDisburseOption.SelectedIndexChanged
        If rdbFinReqDisburseOption.SelectedIndex = 0 Then
            cmbBanks.Visible = False
            Label2.Visible = False
        ElseIf rdbFinReqDisburseOption.SelectedIndex = 1 Then
            cmbBanks.Visible = True
            Label2.Visible = True
        End If
    End Sub
    Private Function getlastDay(ByVal lastday As Date) As Date
        cmd = New SqlCommand("select DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,CONVERT(date,'" & lastday & "',6))+1,0)) as newdate", con)
        Dim ds As New DataSet
        adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "AMORT")
        Return CDate(ds.Tables(0).Rows(0).Item("newdate"))
    End Function
    Private Function getFirstDay(ByVal firstday As Date) As Date
        cmd = New SqlCommand("select DATEADD(m, DATEDIFF(m, 0, '" & firstday & "'), 0) as newdate", con)
        Dim ds As New DataSet
        adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "AMORT")
        Return CDate(ds.Tables(0).Rows(0).Item("newdate"))
    End Function
    Protected Sub cmbBranch_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbBranch.SelectedIndexChanged
        loadLOOfficers_SpecBranch()
    End Sub
    Protected Sub loadLOOfficers_SpecBranch()
        cmbLoanOfficer.ClearSelection()
        cmbLoanOfficer.Items.Clear()
        cmbLoanOfficer.Items.Add(New ListItem("All", "All"))
        Try
            If cmbBranch.SelectedItem.Value = "All" Then
                cmbLoanOfficer.DataSource = Nothing
                cmbLoanOfficer.DataBind()
            Else
                cmd = New SqlCommand("select USERID,USER_LOGIN from MASTER_USERS where USER_BRANCH='" & cmbBranch.SelectedItem.Value & "' order by user_Login asc", con)
                Dim ds As New DataSet
                adp = New SqlDataAdapter(cmd)
                adp.Fill(ds, "MASTER_USERS")
                If ds.Tables(0).Rows.Count > 0 Then
                    cmbLoanOfficer.DataSource = ds.Tables(0)
                    cmbLoanOfficer.DataTextField = "USER_LOGIN"
                    cmbLoanOfficer.DataValueField = "USERID"
                Else
                    cmbLoanOfficer.DataSource = Nothing
                End If
                cmbLoanOfficer.DataBind()
            End If

        Catch ex As Exception
        End Try
    End Sub
End Class