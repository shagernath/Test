﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Partial Class Credit_ApplicationApprovalBank
    Inherits System.Web.UI.Page
    Public Shared globLoanID = 0
    Public Shared prevUser As String = ""
    Dim adp As SqlDataAdapter
    Dim cmd As SqlCommand
    Dim con As New SqlConnection
    Dim connection As String
    Shared Sub approveJQuery(ByVal roleID As String, ByVal appID As String)
        Try
            Dim comm As New SqlCommand
            Dim con As New SqlConnection
            con = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            If roleID = "4042" Then
                comm = New SqlCommand("update QUEST_APPLICATION set STATUS='RECOMMENDED',SEND_TO='4043',RECOMMENDED='1',REC_DATE=GETDATE() where ID='" & appID & "'", con)
            ElseIf roleID = "4043" Then
                comm = New SqlCommand("update QUEST_APPLICATION set STATUS='APPROVED1',SEND_TO='4044',APP1_APPROVED='1',APP1_DATE=GETDATE() where ID='" & appID & "'", con)
            ElseIf roleID = "4044" Then
                comm = New SqlCommand("update QUEST_APPLICATION set STATUS='APPROVED2',SEND_TO='1024',APP2_APPROVED='1',APP2_DATE=GETDATE() where ID='" & appID & "'", con)
            ElseIf roleID = "1024" Then
                comm = New SqlCommand("update QUEST_APPLICATION set STATUS='DISBURSED',SEND_TO='',DISBURSED='1',DISBURSED_DATE=GETDATE() where ID='" & appID & "'", con)
            End If
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            comm.ExecuteNonQuery()
            con.Close()
        Catch ex As Exception

        End Try
    End Sub

    Shared Sub approveJQuery2(ByVal appID As String)
        Try
            Dim comm As New SqlCommand
            Dim con As New SqlConnection
            con = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            comm = New SqlCommand("update QUEST_APPLICATION set STATUS='RECOMMENDED',SEND_TO='4043',RECOMMENDED='1',REC_DATE=GETDATE() where ID='" & appID & "'", con)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            comm.ExecuteNonQuery()
            con.Close()
        Catch ex As Exception

        End Try
    End Sub

    Public Sub clearAmortization(ByVal loanID As Double)
        Try
            cmd = New SqlCommand("select * from amortization_schedule where LOANID='" & loanID & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "AMORT")
            If ds.Tables(0).Rows.Count > 0 Then
                cmd = New SqlCommand("delete from amortization_schedule where LOANID='" & loanID & "'", con)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            Else

            End If
        Catch ex As Exception

        End Try
    End Sub

    Public Function isAmortized(ByVal loanID As Double) As Boolean
        Try
            cmd = New SqlCommand("select * from amortization_schedule where LOANID='" & loanID & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "AMORT")
            If ds.Tables(0).Rows.Count > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Sub msgbox(ByVal strMessage As String)

        'finishes server processing, returns to client.
        Dim strScript As String = "<script language=JavaScript>"
        strScript += "window.alert(""" & strMessage & """);"
        strScript += "</script>"
        Dim lbl As New System.Web.UI.WebControls.Label
        lbl.Text = strScript
        Page.Controls.Add(lbl)
    End Sub

    Protected Function amortizationAlreadyCreated(loanID As String) As Boolean
        cmd = New SqlCommand("select * from AMORTIZATION_SCHEDULE where LOANID='" & loanID & "'", con)
        Dim ds As New DataSet
        adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "AMO")
        If ds.Tables(0).Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Protected Sub amortizeNormal(ByVal loanID As String)
        clearAmortization(loanID)
        Dim cumPrincipal, cumInterest, cumAdmin As Double
        cmd = New SqlCommand("select * from QUEST_APPLICATION where ID='" & loanID & "'", con)
        Dim ds As New DataSet
        Dim firstPayDate, paymentDate As Date
        adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "LOANS")
        If ds.Tables(0).Rows.Count > 0 Then
            'Declare variables
            Dim intYears As Integer
            Dim dblMonthlyPayment As Double
            Dim dblRate As Double
            Dim dblAdmin As Double
            Dim intNumOfPayments As Integer
            Dim dblPrincipal As Double
            Dim dblConvertInterest As Double
            Dim dblConvertAdmin As Double
            'convert to monthly interest
            Dim intPmt As Integer = 1 'initialize integer
            Dim decDeductBalance As Decimal
            Dim interestPaid As Decimal
            Dim AdminPaid As Decimal
            Dim decNewBalance As Decimal
            Dim dblTotalPayments As Double
            Dim dblInterestToDecimal As Double 'convert interest % to decimal
            Dim dblAdminToDecimal As Double 'convert interest % to decimal
            'Dim table As DataTable = new DataTable("ParentTable")
            Dim tblAmort As DataTable = New DataTable("AmortizationTable")
            'dblPrincipal = ds.Tables(0).Rows(0).Item("CLIENT_CREDITAPPLIED")
            'dblRate = ds.Tables(0).Rows(0).Item("INTEREST_RATE")
            'firstPayDate = ds.Tables(0).Rows(0).Item("FIRST_REPAYMENT_DATE") '.ToShortDateString()
            'intYears = ds.Tables(0).Rows(0).Item("REPAYMENT_PERIOD")
            dblPrincipal = ds.Tables(0).Rows(0).Item("FIN_AMT")
            dblRate = ds.Tables(0).Rows(0).Item("FIN_INT_RATE")
            dblAdmin = ds.Tables(0).Rows(0).Item("FIN_ADMIN")
            firstPayDate = ds.Tables(0).Rows(0).Item("FIN_REPAY_DATE") '.ToShortDateString()
            intYears = ds.Tables(0).Rows(0).Item("FIN_TENOR")
            'intMonths = ds.Tables(0).Rows(0).Item("FIN_TENOR")

            ''get user input
            'dblPrincipal = Val(txtPrincipal.Text)
            'dblRate = Val(txtInterest.Text)

            'intYears = Val(txtYears.Text)

            ''''''''''''''''''process monthly payment lines 36 - 41'''''''''''''''''
            '***********************************************************************
            '1. convert the interest rate to decimal form                          *
            '2. Calculate the interest ( i / 12 )                                  *
            '3. Calculate the total number of loan payments (n * 12)               *
            '4. Calculate monthly payment using formula:                           *
            '   M = P * i / ( 1 - ( 1 + i ) ^ -n)                                  *
            '***********************************************************************
            '1. convert interest rate to decimal form
            dblInterestToDecimal = dblRate / 100 'interest % to decimal form
            dblAdminToDecimal = dblAdmin '/ 100 'interest % to decimal form

            '2. calculate interest
            dblConvertInterest = dblInterestToDecimal ' / 12
            dblConvertAdmin = dblAdminToDecimal / intYears  ' / 12

            '3. calculate the total number of payments (n * 12)
            ''change intNumOfPayments to months
            ''''''''''''''''''''''''''''''''''''
            'intNumOfPayments = intYears * 12
            intNumOfPayments = intYears
            dblConvertAdmin = dblAdmin / intNumOfPayments
            '4. Calculate monthly payment using formula
            'dblMonthlyPayment = dblPrincipal * dblConvertInterest / (1 - (1 + dblConvertInterest) ^ -intNumOfPayments) 'end monthtly payment
            'dblMonthlyPayment = dblPrincipal * (dblConvertInterest + dblConvertAdmin) / (1 - (1 + (dblConvertInterest + dblConvertAdmin)) ^ -intNumOfPayments) 'end monthtly payment

            dblMonthlyPayment = (dblPrincipal * (dblConvertInterest) / (1 - (1 + (dblConvertInterest)) ^ -intNumOfPayments)) + dblConvertAdmin 'end monthtly payment
            'dblMonthlyPayment = Math.Round(dblMonthlyPayment, 2)

            'output monthly payment to user
            'lblMonthly.Text = "Monthly Payment: " & String.Format("{0:C}", dblMonthlyPayment)
            dblTotalPayments = intNumOfPayments * dblMonthlyPayment 'total amount of payments
            'lblTotal.Text = "Total Payment: " & String.Format("{0:C}", dblTotalPayments)
            decNewBalance = dblPrincipal 'initialize principle balance
            paymentDate = firstPayDate

            Do While intPmt <= intNumOfPayments
                interestPaid = decNewBalance * dblConvertInterest
                AdminPaid = dblConvertAdmin
                'decDeductBalance = dblMonthlyPayment - interestPaid
                decDeductBalance = dblMonthlyPayment - interestPaid - AdminPaid
                decNewBalance = decNewBalance - decDeductBalance
                cumPrincipal = cumPrincipal + decDeductBalance
                cumInterest = cumInterest + interestPaid
                cumAdmin = cumAdmin + AdminPaid

                'cmd = New SqlCommand("insert into AMORTIZATION_SCHEDULE(LOANID,PAYMENT_NO,PAYMENT_DATE,PRINCIPAL,INTEREST,CUMULATIVE_PRINCIPAL,CUMULATIVE_INTEREST,PRINCIPAL_BALANCE,PAYMENT) values ('" & loanID & "','" & intPmt & "','" & DateFormat.getSaveDate(paymentDate) & "','" & convertToSaveFormat(decDeductBalance) & "','" & convertToSaveFormat(interestPaid) & "','" & convertToSaveFormat(cumPrincipal) & "','" & convertToSaveFormat(cumInterest) & "','" & convertToSaveFormat(decNewBalance) & "','" & convertToSaveFormat(dblMonthlyPayment) & "')", con)
                cmd = New SqlCommand("insert into AMORTIZATION_SCHEDULE(LOANID,PAYMENT_NO,PAYMENT_DATE,PRINCIPAL,INTEREST,ADMIN_CHARGE,CUMULATIVE_PRINCIPAL,CUMULATIVE_INTEREST,PRINCIPAL_BALANCE,PAYMENT,CUMULATIVE_ADMIN) values ('" & loanID & "','" & intPmt & "','" & DateFormat.getSaveDate(paymentDate) & "','" & decDeductBalance & "','" & interestPaid & "','" & AdminPaid & "','" & cumPrincipal & "','" & cumInterest & "','" & decNewBalance & "','" & dblMonthlyPayment & "','" & cumAdmin & "')", con)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                'msgbox(cmd.CommandText)
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()

                paymentDate = DateAdd(DateInterval.Month, 1, paymentDate).ToShortDateString()
                'tblAmort.Rows.Add(tRow)
                intPmt += 1
            Loop
        End If
    End Sub

    Protected Sub amortizeSimple(ByVal loanID As String)
        clearAmortization(loanID)
        Dim cumPrincipal, principalBalance, cumInterest, cumAdmin As Double
        Dim firstPayDate, paymentDate As Date
        cmd = New SqlCommand("select * from QUEST_APPLICATION where ID='" & loanID & "'", con)
        Dim ds As New DataSet
        adp = New SqlDataAdapter(cmd)
        adp.Fill(ds, "LOANS")
        If ds.Tables(0).Rows.Count > 0 Then
            'Declare variables
            'Dim intYears As Integer
            Dim intMonths As Integer
            Dim dblMonthlyPayment As Double
            Dim dblRate As Double
            Dim dblAdmin As Double
            Dim intNumOfPayments As Integer
            Dim dblPrincipal As Double
            Dim dblConvertInterest As Double
            Dim dblConvertAdmin As Double
            'convert to monthly interest
            Dim intPmt As Integer = 1 'initialize integer
            Dim decDeductBalance As Decimal
            Dim interestPaid As Decimal
            Dim adminPaid As Decimal
            Dim decNewBalance As Decimal
            Dim dblTotalPayments As Double
            Dim dblInterestToDecimal As Double 'convert interest % to decimal
            Dim dblAdminToDecimal As Double 'convert admin charge % to decimal
            'Dim table As DataTable = new DataTable("ParentTable")
            Dim tblAmort As DataTable = New DataTable("AmortizationTable")

            dblPrincipal = ds.Tables(0).Rows(0).Item("FIN_AMT")
            dblRate = ds.Tables(0).Rows(0).Item("FIN_INT_RATE")
            firstPayDate = ds.Tables(0).Rows(0).Item("FIN_REPAY_DATE") '.ToShortDateString()
            'intYears = ds.Tables(0).Rows(0).Item("FIN_TENOR")
            intMonths = ds.Tables(0).Rows(0).Item("FIN_TENOR")
            dblAdmin = ds.Tables(0).Rows(0).Item("FIN_ADMIN")

            'Dim totalInterest = (dblPrincipal / dblRate) * intMonths
            'Dim totalAdmin = (dblPrincipal / dblAdmin) * intMonths
            Dim totalInterest = (dblPrincipal * (dblRate / 100)) * intMonths
            Dim totalAdmin = dblAdmin '(dblPrincipal * (dblAdmin / 100)) * intMonths
            'Dim totalPayment = dblPrincipal + totalInterest
            Dim totalPayment = dblPrincipal + totalInterest + totalAdmin
            interestPaid = totalInterest / intMonths
            adminPaid = totalAdmin / intMonths
            ''get user input
            'dblPrincipal = Val(txtPrincipal.Text)
            'dblRate = Val(txtInterest.Text)

            'intYears = Val(txtYears.Text)

            ''''''''''''''''''process monthly payment lines 36 - 41'''''''''''''''''
            '***********************************************************************
            '1. convert the interest rate to decimal form                          *
            '2. Calculate the interest ( i / 12 )                                  *
            '3. Calculate the total number of loan payments (n * 12)               *
            '4. Calculate monthly payment using formula:                           *
            '   M = P * i / ( 1 - ( 1 + i ) ^ -n)                                  *
            '***********************************************************************
            '1. convert interest rate to decimal form
            dblInterestToDecimal = dblRate / 100 'interest % to decimal form
            dblAdminToDecimal = adminPaid ' dblAdmin / 100 'interest % to decimal form

            '2. calculate interest
            'dblConvertInterest = dblInterestToDecimal / 12
            'per month
            dblConvertInterest = dblInterestToDecimal
            dblConvertAdmin = dblAdminToDecimal

            '3. calculate the total number of payments (n * 12)
            ''change intNumOfPayments to months
            ''''''''''''''''''''''''''''''''''''
            'intNumOfPayments = intYears * 12
            intNumOfPayments = intMonths

            '4. Calculate monthly payment using formula
            dblMonthlyPayment = totalPayment / intMonths
            'dblMonthlyPayment = Math.Round(dblMonthlyPayment, 2)

            'output monthly payment to user
            'lblMonthly.Text = "Monthly Payment: " & String.Format("{0:C}", dblMonthlyPayment)
            dblTotalPayments = intNumOfPayments * dblMonthlyPayment 'total amount of payments
            'lblTotal.Text = "Total Payment: " & String.Format("{0:C}", dblTotalPayments)
            decNewBalance = dblPrincipal 'initialize principle balance
            paymentDate = firstPayDate

            Do While intPmt <= intNumOfPayments
                'interestPaid = decNewBalance * dblConvertInterest
                'decDeductBalance = dblMonthlyPayment - interestPaid
                decDeductBalance = dblMonthlyPayment - interestPaid - adminPaid
                decNewBalance = decNewBalance - decDeductBalance
                cumPrincipal = cumPrincipal + decDeductBalance
                'cumInterest = cumInterest + interestPaid
                cumInterest = cumInterest + interestPaid
                cumAdmin = cumAdmin + adminPaid

                cmd = New SqlCommand("insert into AMORTIZATION_SCHEDULE(LOANID,PAYMENT_NO,PAYMENT_DATE,PRINCIPAL,INTEREST,ADMIN_CHARGE,CUMULATIVE_PRINCIPAL,CUMULATIVE_INTEREST,PRINCIPAL_BALANCE,PAYMENT,CUMULATIVE_ADMIN) values ('" & loanID & "','" & intPmt & "','" & DateFormat.getSaveDate(paymentDate) & "','" & decDeductBalance & "','" & interestPaid & "','" & adminPaid & "','" & cumPrincipal & "','" & cumInterest & "','" & decNewBalance & "','" & dblMonthlyPayment & "','" & cumAdmin & "')", con)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                'msgbox(cmd.CommandText)
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                paymentDate = DateAdd(DateInterval.Month, 1, paymentDate).ToShortDateString()
                'tblAmort.Rows.Add(tRow)
                intPmt += 1
            Loop
        End If
    End Sub

    Protected Sub btnDisburse_Click(sender As Object, e As EventArgs) Handles btnDisburse.Click
        If Not chkPartial.Checked Then
            txtAmtToDisburse.Text = txtFinReqAmt.Text
        End If
        If Convert.ToDouble(txtAmtToDisburse.Text) > Convert.ToDouble(txtFinReqAmt.Text) Then
            msgbox("Amount to disburse is greater than amount applied")
        Else
            '''''''''''''''''''''''first save amt to disburse********************
            '''''''''''''''''''''''RUN IN STORED PROCEDURE************************
            cmd = New SqlCommand("sp_disburse", con)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@loanID", Request.QueryString("id"))
            cmd.Parameters.AddWithValue("@amtToDisburse", txtAmtToDisburse.Text)
            cmd.Parameters.AddWithValue("@disburseDate", txtDisburseDate.Text)
            cmd.Parameters.AddWithValue("@userID", Session("ID"))
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            If cmd.ExecuteNonQuery() Then
                'Dim accToSave As String = ""
                'accToSave = lstAccToKeep1.SelectedValue.Substring(0, 4)
                'If Session("ROLE") = "4041" And btnSubmit.Text = "Disburse" Then
                saveComment()
                'recordDisbursalTrans(txtCustNo.Text, Request.QueryString("id"), txtFinReqAmt.Text)
                recordDisbursalTrans(txtCustNo.Text, Request.QueryString("id"), txtAmtToDisburse.Text)
                'If Not isAmortized(Request.QueryString("id")) Then
                createAmortizationOptions(Request.QueryString("id"))
                'End If

                Dim cmdAcc = New SqlCommand("SaveAccountsTrxns", con)
                cmdAcc.CommandType = CommandType.StoredProcedure
                cmdAcc.Parameters.AddWithValue("@Type", "System Entry")
                cmdAcc.Parameters.AddWithValue("@Category", "Disbursment")
                'cmd.Parameters.AddWithValue("@Date", Today.Date.ToString)
                'cmd.Parameters.AddWithValue("@Ref", [Refrence])
                cmdAcc.Parameters.AddWithValue("@Ref", Request.QueryString("id"))
                cmdAcc.Parameters.AddWithValue("@Desc", "Disbursement")
                'cmd.Parameters.AddWithValue("@Debit", txtFinReqAmt.Text)
                cmdAcc.Parameters.AddWithValue("@Debit", txtAmtToDisburse.Text)
                cmdAcc.Parameters.AddWithValue("@Credit", 0.0)
                cmdAcc.Parameters.AddWithValue("@Account", "213/1") 'loan debtor
                cmdAcc.Parameters.AddWithValue("@ContraAccount", cmbddlist.SelectedItem) 'cash
                cmdAcc.Parameters.AddWithValue("@Status", 1)
                'cmd.Parameters.AddWithValue("@Other", [Loan Debtor Account Number])
                cmdAcc.Parameters.AddWithValue("@Other", txtCustNo.Text)
                cmdAcc.Parameters.AddWithValue("@BankAccID", "")
                cmdAcc.Parameters.AddWithValue("@BankAccName", "")
                'cmd.Parameters.AddWithValue("@BatchRef", cmbBatchNo.SelectedItem.Text)
                cmdAcc.Parameters.AddWithValue("@BatchRef", "")
                cmdAcc.Parameters.AddWithValue("@TrxnDate", txtDisburseDate.Text)

                Dim cmd1 = New SqlCommand("SaveAccountsTrxns", con)
                cmd1.CommandType = CommandType.StoredProcedure
                cmd1.Parameters.AddWithValue("@Type", "System Entry")
                cmd1.Parameters.AddWithValue("@Category", "Disbursment")
                'cmd1.Parameters.AddWithValue("@Date", Today.Date.ToString)
                'cm1d.Parameters.AddWithValue("@Ref", [Refrence])
                cmd1.Parameters.AddWithValue("@Ref", Request.QueryString("id"))
                cmd1.Parameters.AddWithValue("@Desc", "Disbursement")
                'cmd1.Parameters.AddWithValue("@Debit", txtFinReqAmt.Text)
                cmd1.Parameters.AddWithValue("@Debit", 0.0)
                cmd1.Parameters.AddWithValue("@Credit", txtAmtToDisburse.Text)
                cmd1.Parameters.AddWithValue("@Account", "211/1")
                cmd1.Parameters.AddWithValue("@ContraAccount", "213/1")
                cmd1.Parameters.AddWithValue("@Status", 1)
                'cm1d.Parameters.AddWithValue("@Other", [Loan Debtor Account Number])
                cmd1.Parameters.AddWithValue("@Other", txtCustNo.Text)
                cmd1.Parameters.AddWithValue("@BankAccID", "")
                cmd1.Parameters.AddWithValue("@BankAccName", "")
                'cm1d.Parameters.AddWithValue("@BatchRef", cmbBatchNo.SelectedItem.Text)
                cmd1.Parameters.AddWithValue("@BatchRef", "")
                cmd1.Parameters.AddWithValue("@TrxnDate", txtDisburseDate.Text)

                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                cmdAcc.ExecuteNonQuery()
                cmd1.ExecuteNonQuery()
                con.Close()

                'new function to insert interest to maturity on disbursement
                insertInterestAccounts(Request.QueryString("id"))

                If Session("ROLE") = "4042" Then
                    Response.Write("<script>alert('Loan successfully recommended') ; location.href='ApplicationView.aspx'</script>")
                Else
                    Response.Write("<script>alert('Loan successfully approved') ; location.href='ApplicationView.aspx'</script>")
                End If
                Dim strEmail As String
                Dim SignatoryEMail As String
                'SignatoryEMail = Mailhelper.GetEMailID(ddl_SendTo.SelectedValue.ToString())

                strEmail = "<Strong>Dear Sir/Madam,</strong><br>You Have Received A New Loan Application Request. Details are as follows<br><br>"
                strEmail = strEmail & "<Table bgcolor='444444'><font forecolor='ffffff'>"
                strEmail = strEmail & "<tr bgcolor='999999'><td>Date:</td><td>" & Now & "</td></tr>"
                strEmail = strEmail & "<tr bgcolor='eeeeee'><td>Applicant Type:</td><td>" & rdbClientType.SelectedValue & "</td></tr>"
                strEmail = strEmail & "<tr bgcolor='999999'><td>Branch:</td><td>" & lblBranchCode.Text.Trim() & " - " & lblBranchName.Text.Trim() & "</td></tr>"
                'strEmail = strEmail & "<tr bgcolor='999999'><td>Branch Name:</td><td>" & txt_BranchName.Text.Trim() & "</td></tr>"
                strEmail = strEmail & "<tr bgcolor='999999'><td>Client Name:</td><td>" & txtForenames.Text & " " & txtSurname.Text & "</td></tr>"
                'strEmail = strEmail & "<tr bgcolor='999999'><td>Transaction Type:</td><td>" & ddl_TransactionTy.SelectedItem.Text.Trim() & "</td></tr>"
                strEmail = strEmail & "<tr bgcolor='999999'><td>Amount:</td><td>" & txtFinReqAmt.Text & "</td></tr>"
                strEmail = strEmail & "</font></Table>"
                strEmail = strEmail & "<br><Strong>Thanks & Regards,<br>IT Support Team</strong>"
                If Session("ROLE") = "4042" Then
                    SignatoryEMail = Mailhelper.GetMultiBranchRoleEMailID(Session("BRANCHCODE"), "4043")
                    If Trim(SignatoryEMail) = "" Then
                        SignatoryEMail = Mailhelper.GetMultipleEMailID("4043")
                    End If
                    Mailhelper.SendMailMessage("administrator", SignatoryEMail, "", "", "Escrow Credit Management - Loan Application", strEmail)
                ElseIf Session("ROLE") = "4043" Then
                    SignatoryEMail = Mailhelper.GetMultiBranchRoleEMailID(Session("BRANCHCODE"), "4044")
                    If Trim(SignatoryEMail) = "" Then
                        SignatoryEMail = Mailhelper.GetMultipleEMailID("4044")
                    End If
                    Mailhelper.SendMailMessage("administrator", SignatoryEMail, "", "", "Escrow Credit Management - Loan Application", strEmail)
                End If
            End If

        End If
    End Sub

    Protected Sub btnGenAgrmt_Click(sender As Object, e As EventArgs) Handles btnGenAgrmt.Click
        Try
            Dim strscript As String = "<script langauage=JavaScript>"
            strscript += "window.open('rptAcknowledgement.aspx?ID=" & Request.QueryString("id") & "');"
            strscript += "</script>"
            ClientScript.RegisterStartupScript(Me.GetType(), "newwin", strscript)
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub btnNavBack_Click(sender As Object, e As EventArgs) Handles btnNavBack.Click
        Dim ViewCount As Integer = Me.mltAppForm.Views.Count
        Dim ActiveIndex As Integer = Me.mltAppForm.ActiveViewIndex
        If ActiveIndex = (ViewCount - 1) Then
            Me.mltAppForm.ActiveViewIndex = ViewCount - 2
            btnNavNext.Enabled = True
            btnNavNext.CssClass = "navButton"
        ElseIf ActiveIndex = 1 Then
            btnNavBack.Enabled = False
            btnNavBack.CssClass = "disabledNavButton"
            Me.mltAppForm.ActiveViewIndex = 0
        Else
            Me.mltAppForm.ActiveViewIndex = ActiveIndex - 1
            btnNavNext.Enabled = True
            btnNavBack.Enabled = True
            btnNavNext.CssClass = "navButton"
            btnNavBack.CssClass = "navButton"
        End If
        loadClasses()
    End Sub

    Protected Sub btnNavNext_Click(sender As Object, e As EventArgs) Handles btnNavNext.Click
        Dim ViewCount As Integer = Me.mltAppForm.Views.Count
        Dim ActiveIndex As Integer = Me.mltAppForm.ActiveViewIndex
        If ActiveIndex = (ViewCount - 1) Then
            Me.mltAppForm.ActiveViewIndex = 0
        ElseIf ActiveIndex = ViewCount - 2 Then
            Me.mltAppForm.ActiveViewIndex = ViewCount - 1
            btnNavNext.Enabled = False
            btnNavNext.CssClass = "disabledNavButton"
            'ElseIf ActiveIndex = 0 Then
            '    btnNavBack.Enabled = False
        Else
            btnNavNext.Enabled = True
            btnNavBack.Enabled = True
            btnNavNext.CssClass = "navButton"
            btnNavBack.CssClass = "navButton"
            Me.mltAppForm.ActiveViewIndex = ActiveIndex + 1
        End If
        loadClasses()
    End Sub

    Protected Sub btnReject_Click(sender As Object, e As EventArgs) Handles btnReject.Click
        Try
            Dim retRole = ""
            If Session("ROLE") = "4044" Then
                retRole = "4043"
            ElseIf Session("ROLE") = "4043" Then
                retRole = "4042"
            ElseIf Session("ROLE") = "4042" Then
                retRole = "4041"
            ElseIf Session("ROLE") = "1024" Then
                retRole = "4044"
            End If
            cmd = New SqlCommand("update QUEST_APPLICATION set STATUS='REJECTED', SEND_TO='" & retRole & "',LAST_ID='" & Session("ID") & "' where ID='" & globLoanID & "'", con)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            'msgbox(cmd.CommandText)
            If cmd.ExecuteNonQuery Then
                Dim comm = ""
                If Trim(txtComment.Text) = "" Then
                    comm = "REJECTED"
                Else
                    comm = txtComment.Text
                End If
                'If Not (Trim(txtComment.Text) = "" Or Trim(txtRecAmt.Text) = "") Then
                cmd = New SqlCommand("insert into REQUEST_HISTORY (LOANID,COMMENT_DATE,USERID,COMMENT,RECOMMENDED_AMT) values('" & Request.QueryString("id") & "',GETDATE(),'" & Session("UserID") & "','" & BankString.removeSpecialCharacter(comm) & "','" & txtRecAmt.Text & "')", con)
                cmd.ExecuteNonQuery()
                con.Close()
                Dim strEmail As String
                Dim SignatoryEMail As String
                'SignatoryEMail = Mailhelper.GetEMailID(ddl_SendTo.SelectedValue.ToString())

                strEmail = "<Strong>Dear Sir/Madam,</strong><br>The loan application you forwarded has been rejected. Details are as follows<br><br>"
                strEmail = strEmail & "<Table bgcolor='444444'><font forecolor='ffffff'>"
                strEmail = strEmail & "<tr bgcolor='999999'><td>Date:</td><td>" & Now & "</td></tr>"
                strEmail = strEmail & "<tr bgcolor='eeeeee'><td>Applicant Type:</td><td>" & rdbClientType.SelectedValue & "</td></tr>"
                strEmail = strEmail & "<tr bgcolor='999999'><td>Branch:</td><td>" & lblBranchCode.Text.Trim() & " - " & lblBranchName.Text.Trim() & "</td></tr>"
                'strEmail = strEmail & "<tr bgcolor='999999'><td>Branch Name:</td><td>" & txt_BranchName.Text.Trim() & "</td></tr>"
                strEmail = strEmail & "<tr bgcolor='999999'><td>Client Name:</td><td>" & txtForenames.Text & " " & txtSurname.Text & "</td></tr>"
                'strEmail = strEmail & "<tr bgcolor='999999'><td>Transaction Type:</td><td>" & ddl_TransactionTy.SelectedItem.Text.Trim() & "</td></tr>"
                strEmail = strEmail & "<tr bgcolor='999999'><td>Amount:</td><td>" & txtFinReqAmt.Text & "</td></tr>"
                strEmail = strEmail & "</font></Table>"
                strEmail = strEmail & "<br><Strong>Thanks & Regards,<br>IT Support Team</strong>"
                If Session("ROLE") = "4042" Then
                    SignatoryEMail = Mailhelper.GetEMailID(prevUser)
                    If Trim(SignatoryEMail) = "" Then
                        SignatoryEMail = Mailhelper.GetEMailID(prevUser)
                    End If
                    Mailhelper.SendMailMessage("administrator", SignatoryEMail, "", "", "Escrow Credit Management - Loan Application", strEmail)
                ElseIf Session("ROLE") = "4043" Then
                    SignatoryEMail = Mailhelper.GetEMailID(prevUser)
                    If Trim(SignatoryEMail) = "" Then
                        SignatoryEMail = Mailhelper.GetEMailID(prevUser)
                    End If
                    Mailhelper.SendMailMessage("administrator", SignatoryEMail, "", "", "Escrow Credit Management - Loan Application", strEmail)
                End If
                Response.Write("<script>alert('Loan successfully rejected'); location.href='ApplicationView.aspx';</script>")
                'ClientScript.RegisterStartupScript(Me.GetType(), "Gritter", "<script type=""text/javascript"">location.href='ApplicationView.aspx'; $.gritter.add({title: 'Loan Added Successfully!',text: 'The loan has been added successfully.',image: 'images/thumbs3.jpg'});</script>")
            Else
                msgbox("Error saving")
            End If
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Try
            If Session("ROLE") = "1024" And btnSubmit.Text = "Disburse" Then
                'ClientScript.RegisterStartupScript(Me.GetType, "disburse", "<script type=""text/javascript"">showDisburseAmt();</script>")
                'If chkPartial.Checked Then
                btnDisburse_Click(sender, New EventArgs)
                'Else

                'End If
            Else
                'if is final disbursal then create armotization schedule'
                'cmd = New SqlCommand("update QUEST_APPLICATION set STATUS='RECOMMENDED',SEND_TO='4043',APP1_APPROVED='1',APP1_DATE=GETDATE() where ID='" & Request.QueryString("id") & "'", con)
                cmd = getCommand(Session("ROLE"))
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                If cmd.ExecuteNonQuery() Then
                    'If Session("ROLE") = "4041" And btnSubmit.Text = "Disburse" Then
                    saveComment()
                    If Session("ROLE") = "4042" Then
                        Response.Write("<script>alert('Loan successfully recommended') ; location.href='ApplicationView.aspx'</script>")
                    Else
                        Response.Write("<script>alert('Loan successfully approved') ; location.href='ApplicationView.aspx'</script>")
                    End If
                    Dim strEmail As String
                    Dim SignatoryEMail As String
                    'SignatoryEMail = Mailhelper.GetEMailID(ddl_SendTo.SelectedValue.ToString())

                    strEmail = "<Strong>Dear Sir/Madam,</strong><br>You Have Received A New Loan Application Request. Details are as follows<br><br>"
                    strEmail = strEmail & "<Table bgcolor='444444'><font forecolor='ffffff'>"
                    strEmail = strEmail & "<tr bgcolor='999999'><td>Date:</td><td>" & Now & "</td></tr>"
                    strEmail = strEmail & "<tr bgcolor='eeeeee'><td>Applicant Type:</td><td>" & rdbClientType.SelectedValue & "</td></tr>"
                    strEmail = strEmail & "<tr bgcolor='999999'><td>Branch:</td><td>" & lblBranchCode.Text.Trim() & " - " & lblBranchName.Text.Trim() & "</td></tr>"
                    'strEmail = strEmail & "<tr bgcolor='999999'><td>Branch Name:</td><td>" & txt_BranchName.Text.Trim() & "</td></tr>"
                    strEmail = strEmail & "<tr bgcolor='999999'><td>Client Name:</td><td>" & txtForenames.Text & " " & txtSurname.Text & "</td></tr>"
                    'strEmail = strEmail & "<tr bgcolor='999999'><td>Transaction Type:</td><td>" & ddl_TransactionTy.SelectedItem.Text.Trim() & "</td></tr>"
                    strEmail = strEmail & "<tr bgcolor='999999'><td>Amount:</td><td>" & txtFinReqAmt.Text & "</td></tr>"
                    strEmail = strEmail & "</font></Table>"
                    strEmail = strEmail & "<br><Strong>Thanks & Regards,<br>IT Support Team</strong>"
                    If Session("ROLE") = "4042" Then
                        SignatoryEMail = Mailhelper.GetMultiBranchRoleEMailID(Session("BRANCHCODE"), "4043")
                        If Trim(SignatoryEMail) = "" Then
                            SignatoryEMail = Mailhelper.GetMultipleEMailID("4043")
                        End If
                        Mailhelper.SendMailMessage("administrator", SignatoryEMail, "", "", "Escrow Credit Management - Loan Application", strEmail)
                    ElseIf Session("ROLE") = "4043" Then
                        SignatoryEMail = Mailhelper.GetMultiBranchRoleEMailID(Session("BRANCHCODE"), "4044")
                        If Trim(SignatoryEMail) = "" Then
                            SignatoryEMail = Mailhelper.GetMultipleEMailID("4044")
                        End If
                        Mailhelper.SendMailMessage("administrator", SignatoryEMail, "", "", "Escrow Credit Management - Loan Application", strEmail)
                    End If

                End If
                'clearAll()
            End If
            con.Close()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub chkPartial_CheckedChanged(sender As Object, e As EventArgs) Handles chkPartial.CheckedChanged
        If chkPartial.Checked Then
            modalDisburse.Visible = True
        Else
            modalDisburse.Visible = False
        End If
    End Sub

    Protected Sub copyToRepaymentSchedule(loanID As String)
        cmd = New SqlCommand("", con)
    End Sub

    Protected Sub createAmortizationOptions(ByVal loanID As String)
        Try
            cmd = New SqlCommand("select * from QUEST_APPLICATION where ID='" & loanID & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "LOANS")
            Dim repOpt As String = ""
            Dim intSett As String = ""
            If ds.Tables(0).Rows.Count > 0 Then
                If ds.Tables(0).Rows(0).Item("FIN_REPAY_OPT") = "Interest" Then
                    'amortizeSimple(loanID)
                    cmd = New SqlCommand("sp_amortize_simple_daily", con)
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@loanID", loanID)
                ElseIf ds.Tables(0).Rows(0).Item("FIN_REPAY_OPT") = "Balance" Then
                    'amortizeNormal(loanID)
                    cmd = New SqlCommand("sp_amortize_normal_daily", con)
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@loanID", loanID)
                    'amortizeInterestFixed(loanID)
                Else
                    'amortizeNormal(loanID)
                    cmd = New SqlCommand("sp_amortize_normal_daily", con)
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@loanID", loanID)
                End If
                If con.State <> ConnectionState.Closed Then
                    con.Close()
                End If
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
                'msgbox("Amortization schedule successfully created")
                'lblViewSchedule.Text = "<a href='rptAmortizationSchedule.aspx?loanID=" & loanID & "' target='new'>View Schedule</a>"
                'ClientScript.RegisterStartupScript(Me.GetType(), "Gritter", "<script type=""text/javascript"">$.gritter.add({title: 'Amortization Schedule Created!',text: 'The amortization schedule has been successfully created. Click ""View Schedule"" to view the created schedule.',image: 'images/thumbs3.jpg'});</script>")
            End If
        Catch ex As Exception
            msgbox("Unable to create amortization schedule. Make sure all parameters are entered")
            'ClientScript.RegisterStartupScript(Me.GetType(), "Gritter", "<script type=""text/javascript"">$.gritter.add({title: 'Amortization Failure!',text: 'An error occurred while creating the amortization schedule. Please make sure all parameters are entered correctly with the right format and try again.',image: 'images/error_button.png'});</script>")
        End Try
    End Sub

    Protected Sub getAppDetails(ByVal loanID As String)
        Try
            cmd = New SqlCommand("select * from QUEST_APPLICATION where ID='" & loanID & "'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "APP")
            If ds.Tables(0).Rows.Count > 0 Then
                Try
                    If ds.Tables(0).Rows(0).Item("STATUS") = "REJECTED" Then
                        If Session("ROLE") = "4042" Then
                            prevUser = ds.Tables(0).Rows(0).Item("LO_ID")
                        ElseIf Session("ROLE") = "4043" Then
                            prevUser = ds.Tables(0).Rows(0).Item("LM_ID")
                        ElseIf Session("ROLE") = "4044" Then
                            prevUser = ds.Tables(0).Rows(0).Item("HL_ID")
                        End If
                    Else
                        prevUser = ds.Tables(0).Rows(0).Item("LAST_ID")
                    End If
                Catch ex As Exception
                    prevUser = ""
                End Try
                txtCustNo.Text = ds.Tables(0).Rows(0).Item("CUSTOMER_NUMBER")
                txtSurname.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SURNAME"))
                txtForenames.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FORENAMES"))
                lblBranchCode.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("BRANCH_CODE"))
                lblBranchName.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("BRANCH_NAME"))
                txtAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ADDRESS"))
                'txtCreditLimit.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CREDIT_LIMIT"))
                txtPhoneNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PHONE_NO"))
                txtCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CITY"))
                txtCurrEmployer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMPLOYER"))
                txtEducationOther.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("EDUCATION"))
                txtEmpAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_ADD"))
                txtEmpCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_CITY"))
                txtEmpEmail.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_EMAIL"))
                txtEmpFax.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_FAX"))
                txtEmpHowLong.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_LENGTH")), 0)
                txtEmpOtherIncome.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_INCOME")), 2)
                txtEmpPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_PHONE"))
                txtEmpPosition.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_POSITION"))
                txtEmpSalary.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_SALARY")), 2)
                txtHouseHowLong.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("HOME_LENGTH")), 0)
                txtIDNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("IDNO"))
                txtNationality.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("NATIONALITY"))
                txtNoChildren.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("NO_CHILDREN"))
                txtNoDependant.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("NO_DEPENDANTS"))
                txtPrevEmpAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_ADD"))
                txtPrevEmpAnnualIncome.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_INCOME")), 2)
                txtPrevEmpCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_CITY"))
                txtPrevEmpEmail.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_EMAIL"))
                txtPrevEmpFax.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_FAX"))
                txtPrevEmpHowLong.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_LENGTH")), 0)
                txtPrevEmployer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMPLOYER"))
                txtPrevEmpPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_PHONE"))
                txtPrevEmpPosition.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_POSITION"))
                txtPrevEmpSalary.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_SALARY")), 2)
                txtRent.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("MONTHLY_RENT")), 2)
                txtSpouse.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_NAME"))
                txtSpouseEmployer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_EMPLOYER"))
                txtSpouseOccupation.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_OCCUPATION"))
                txtSpousePhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_PHONE"))
                txtTradeRef1.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("TRADE_REF1"))
                txtTradeRef2.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("TRADE_REF2"))
                txtGuarCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_CITY"))
                txtGuarCurrAdd.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_ADD"))
                txtGuarCurrEmp.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMPLOYER"))
                txtGuarEmpAdd.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_ADD"))
                txtGuarEmpEmail.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_EMAIL"))
                txtGuarEmpFax.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_FAX"))
                txtGuarEmpIncome.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_INCOME")), 2)
                txtGuarEmpLength.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_LENGTH")), 0)
                txtGuarEmpPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_PHONE"))
                txtGuarEmpPosition.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_POSTN"))
                txtGuarEmpSalary.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_SALARY")), 2)
                txtGuarHomeLength.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_HOME_LENGTH")), 0)
                txtGuarIDNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_IDNO"))
                txtGuarMonthRent.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_RENT")), 2)
                txtGuarName.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_NAME"))
                txtGuarNameRelative.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_NAME"))
                txtGuarPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_PHONE"))
                txtGuarRelAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_ADD"))
                txtGuarRelCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_CITY"))
                txtGuarRelPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_PHONE"))
                txtGuarRelReltnship.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_RELTNSHP"))
                txtFinReqAccNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_ACCNO"))
                txtFinReqAmt.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("AMT_APPLIED")), 2)
                txtRecAmt.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_AMT")), 2)
                txtAmtToDisburse.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_AMT")), 2)
                txtFinReqBank.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_BANK"))
                txtFinReqBranchCode.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_BRANCH_CODE"))
                txtFinReqBranchName.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_BRANCH"))
                txtFinReqIntRate.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_INT_RATE")), 2)
                txtFinReqPurpose.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_PURPOSE"))
                txtFinReqSecOffer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_SEC_OFFER"))
                txtFinReqSource.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_SRC_REPAYMT"))
                txtFinReqTenor.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_TENOR")), 0)
                txtOtherAccNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("OTHER_ACCNO"))
                txtOtherAmt.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("OTHER_AMT")), 2)
                txtOtherDesc.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("OTHER_DESC"))
                txtQuesAgent.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("QUES_AGENT"))
                txtQuesEmployee.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("QUES_EMPLOYEE"))

                loadOtherLoans()
                Try
                    rdbClientType.SelectedValue = ds.Tables(0).Rows(0).Item("CUSTOMER_TYPE")
                    rdbGender.SelectedValue = ds.Tables(0).Rows(0).Item("GENDER")
                    rdbHouse.SelectedValue = ds.Tables(0).Rows(0).Item("HOME_TYPE")
                    rdbGuarHomeType.SelectedValue = ds.Tables(0).Rows(0).Item("GUARANTOR_HOME_TYPE")
                    rdbQuesHow.SelectedValue = ds.Tables(0).Rows(0).Item("QUES_HOW")
                    rdbFinReqDisburseOption.SelectedValue = ds.Tables(0).Rows(0).Item("DISBURSE_OPTION")

                    cmbEducation.SelectedValue = ds.Tables(0).Rows(0).Item("EDUCATION")
                    cmbMaritalStatus.SelectedValue = ds.Tables(0).Rows(0).Item("MARITAL_STATUS")
                Catch ex As Exception

                End Try

                bdpDOB.SelectedDate = ds.Tables(0).Rows(0).Item("DOB")
                bdpIssDate.SelectedDate = ds.Tables(0).Rows(0).Item("ISSUE_DATE")
                bdpGuarDOB.SelectedDate = ds.Tables(0).Rows(0).Item("GUARANTOR_DOB")
                If rdbClientType.SelectedValue = "Individual" Then
                    Try
                        rdbSubIndividual.Visible = True
                        rdbSubIndividual.SelectedValue = ds.Tables(0).Rows(0).Item("SUB_INDIVIDUAL")
                    Catch ex As Exception

                    End Try
                    If Session("ROLE") = "4042" Then
                        tickSSB()
                    End If
                    lblSurname.Text = "Surname"
                    lblForenames.Text = "Forenames"
                    lblForenames.Visible = True
                    txtForenames.Visible = True
                ElseIf rdbClientType.SelectedValue = "Business" Then
                    lblSurname.Text = "Name"
                    lblForenames.Visible = False
                    txtForenames.Visible = False
                    txtForenames.Text = ""
                End If
                If rdbSubIndividual.SelectedValue = "SSB" Then
                    txtMinDept.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("MIN_DEPT"))
                    txtMinDeptNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("MIN_DEPT_NO"))
                    txtECNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ECNO"))
                    txtECNoCD.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CD"))

                    lblMinDept.Visible = True
                    lblMinDeptNo.Visible = True
                    lblEmpCode.Visible = True
                    txtMinDept.Visible = True
                    txtMinDeptNo.Visible = True
                    txtECNo.Visible = True
                    txtECNoCD.Visible = True
                End If

                If rdbFinReqDisburseOption.SelectedValue = "Ecocash" Then
                    lblEcocashNumber.Visible = True
                    txtEcocashNumber.Visible = True
                    txtEcocashNumber.Text = ds.Tables(0).Rows(0).Item("ECOCASH_NUMBER")
                End If
            Else
            End If
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub getAppHistory()
        Try
            cmd = New SqlCommand("select COMMENT_DATE as [DATE], USERID as [USER],CONVERT(DECIMAL(30,2),[RECOMMENDED_AMT]) as [RECOMMENDED AMOUNT],COMMENT from REQUEST_HISTORY where LOANID='" & Request.QueryString("id") & "' order by COMMENT_DATE", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "COMMENT")
            If ds.Tables(0).Rows.Count > 0 Then
                grdAppHistory.DataSource = ds.Tables(0)
            Else
                grdAppHistory.DataSource = Nothing
            End If
            grdAppHistory.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Function getCommand(ByVal roleID As String) As SqlCommand
        Dim comm As New SqlCommand
        If roleID = "4042" Then
            comm = New SqlCommand("update QUEST_APPLICATION set STATUS='RECOMMENDED',SEND_TO='4043',RECOMMENDED='1',REC_DATE=GETDATE(),FIN_AMT='" & txtRecAmt.Text & "',LM_ID='" & Session("ID") & "',LAST_ID='" & Session("ID") & "' where ID='" & Request.QueryString("id") & "'", con)
        ElseIf roleID = "4043" Then
            comm = New SqlCommand("update QUEST_APPLICATION set STATUS='APPROVED1',SEND_TO='4044',APP1_APPROVED='1',APP1_DATE=GETDATE(),FIN_AMT='" & txtRecAmt.Text & "',HL_ID='" & Session("ID") & "',LAST_ID='" & Session("ID") & "' where ID='" & Request.QueryString("id") & "'", con)
        ElseIf roleID = "4044" Then
            comm = New SqlCommand("update QUEST_APPLICATION set STATUS='APPROVED2',SEND_TO='1024',APP2_APPROVED='1',APP2_DATE=GETDATE(),FIN_AMT='" & txtRecAmt.Text & "',MD_ID='" & Session("ID") & "',LAST_ID='" & Session("ID") & "' where ID='" & Request.QueryString("id") & "'", con)
        ElseIf roleID = "1024" Then
            'comm = New SqlCommand("update QUEST_APPLICATION set STATUS='DISBURSED',SEND_TO='4041',DISBURSED='1',DISBURSED_DATE=GETDATE(),DB_IDD='" & Session("ID") & "',LAST_ID='" & Session("ID") & "' where ID='" & Request.QueryString("id") & "'", con)
            comm = New SqlCommand("update QUEST_APPLICATION set STATUS='DISBURSED',SEND_TO='4041',DISBURSED='1',DISBURSED_DATE='" & txtDisburseDate.Text & "',DB_IDD='" & Session("ID") & "',LAST_ID='" & Session("ID") & "' where ID='" & Request.QueryString("id") & "'", con)
            '    'comm = New SqlCommand("update QUEST_APPLICATION set STATUS='APPROVED FOR DISBURSAL',SEND_TO='4041',APPROVED_FOR_DISBURSAL='1',DB_IDD='" & Session("ID") & "',LAST_ID='" & Session("ID") & "' where ID='" & Request.QueryString("id") & "'", con)
            'ElseIf roleID = "4041" Then
            '    comm = New SqlCommand("update QUEST_APPLICATION set STATUS='DISBURSED',SEND_TO='',DISBURSED='1',DISBURSED_DATE=GETDATE(),LAST_ID='" & Session("ID") & "' where ID='" & Request.QueryString("id") & "'", con)
        End If
        Return comm
    End Function

    Protected Function getCommandNew(ByVal roleID As String) As SqlCommand
        Dim comm As New SqlCommand
        If roleID = "4042" Then
            comm = New SqlCommand("update QUEST_APPLICATION set STATUS='RECOMMENDED',SEND_TO='4043',RECOMMENDED='1',REC_DATE=GETDATE(),FIN_AMT='" & txtRecAmt.Text & "',LM_ID='" & Session("ID") & "',LAST_ID='" & Session("ID") & "' where ID='" & Request.QueryString("id") & "'", con)
        ElseIf roleID = "4043" Then
            comm = New SqlCommand("update QUEST_APPLICATION set STATUS='APPROVED1',SEND_TO='4044',APP1_APPROVED='1',APP1_DATE=GETDATE(),FIN_AMT='" & txtRecAmt.Text & "',HL_ID='" & Session("ID") & "',LAST_ID='" & Session("ID") & "' where ID='" & Request.QueryString("id") & "'", con)
        ElseIf roleID = "4044" Then
            comm = New SqlCommand("update QUEST_APPLICATION set STATUS='APPROVED2',SEND_TO='1024',APP2_APPROVED='1',APP2_DATE=GETDATE(),FIN_AMT='" & txtRecAmt.Text & "',MD_ID='" & Session("ID") & "',LAST_ID='" & Session("ID") & "' where ID='" & Request.QueryString("id") & "'", con)
        ElseIf roleID = "1024" Then
            comm = New SqlCommand("update QUEST_APPLICATION set STATUS='DISBURSED',SEND_TO='',DISBURSED='1',DISBURSED_DATE=GETDATE(),DB_IDD='" & Session("ID") & "',LAST_ID='" & Session("ID") & "' where ID='" & Request.QueryString("id") & "'", con)
        End If
        Return comm
    End Function

    Protected Function getEducation() As String
        If cmbEducation.SelectedValue = "Other" Then
            Return Trim("Other: " & BankString.removeSpecialCharacter(txtEducationOther.Text))
        Else
            Return cmbEducation.SelectedValue
        End If
    End Function

    Protected Sub grdAppHistory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles grdAppHistory.SelectedIndexChanged

    End Sub

    Protected Sub grdDocuments_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles grdDocuments.PageIndexChanging
        grdDocuments.PageIndex = e.NewPageIndex
        loadUploadedFiles(globLoanID)
    End Sub

    Protected Sub grdDocuments_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles grdDocuments.RowCommand
        If e.CommandName = "Select" Then
            Dim docID = e.CommandArgument
            'lblDetailID.Text = docID
            'btnModalPopup.Visible = True
            Dim strscript As String

            strscript = "<script langauage=JavaScript>"
            strscript += "window.open('viewDocument.aspx?id=" & docID & "');"
            strscript += "</script>"
            'ClientScript.RegisterStartupScript(Me.GetType(), "HideLabel", "<script type=""text/javascript"">setTimeout(""document.getElementById('" & lblAppUploadMsg.ClientID & "').style.display='none'"",5000)</script>")
            ClientScript.RegisterStartupScript(Me.GetType(), "newwin", strscript)
        End If
    End Sub

    Protected Sub grdDocuments_SelectedIndexChanged(sender As Object, e As EventArgs) Handles grdDocuments.SelectedIndexChanged

    End Sub

    Protected Sub insertInterestAccounts(loanID As String)
        'get ineterest to maturity
        Dim cmdInt = New SqlCommand("select max(cumulative_interest) from AMORTIZATION_SCHEDULE where LOANID='" & loanID & "'", con)
        Dim intToMaturity As Double = 0
        If con.State <> ConnectionState.Closed Then
            con.Close()
        End If
        con.Open()
        intToMaturity = cmdInt.ExecuteScalar
        con.Close()

        cmd = New SqlCommand("SaveAccountsTrxns", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@Type", "System Entry")
        cmd.Parameters.AddWithValue("@Category", "Interest Payable")
        'cmd.Parameters.AddWithValue("@Date", Today.Date.ToString)
        'cmd.Parameters.AddWithValue("@Ref", [Refrence])
        cmd.Parameters.AddWithValue("@Ref", Request.QueryString("id"))
        cmd.Parameters.AddWithValue("@Desc", "Interest to Maturity")
        'cmd.Parameters.AddWithValue("@Debit", txtFinReqAmt.Text)
        cmd.Parameters.AddWithValue("@Debit", intToMaturity)
        cmd.Parameters.AddWithValue("@Credit", 0.0)
        cmd.Parameters.AddWithValue("@Account", "213/1")
        cmd.Parameters.AddWithValue("@ContraAccount", "223/1")
        cmd.Parameters.AddWithValue("@Status", 1)
        'cmd.Parameters.AddWithValue("@Other", [Loan Debtor Account Number])
        cmd.Parameters.AddWithValue("@Other", txtCustNo.Text)
        cmd.Parameters.AddWithValue("@BankAccID", "")
        cmd.Parameters.AddWithValue("@BankAccName", "")
        'cmd.Parameters.AddWithValue("@BatchRef", cmbBatchNo.SelectedItem.Text)
        cmd.Parameters.AddWithValue("@BatchRef", "")
        cmd.Parameters.AddWithValue("@TrxnDate", txtDisburseDate.Text)

        Dim cmd1 = New SqlCommand("SaveAccountsTrxns", con)
        cmd1.CommandType = CommandType.StoredProcedure
        cmd1.Parameters.AddWithValue("@Type", "System Entry")
        cmd1.Parameters.AddWithValue("@Category", "Interest Payable")
        'cmd1.Parameters.AddWithValue("@Date", Today.Date.ToString)
        'cm1d.Parameters.AddWithValue("@Ref", [Refrence])
        cmd1.Parameters.AddWithValue("@Ref", Request.QueryString("id"))
        cmd1.Parameters.AddWithValue("@Desc", "Interest to Maturity")
        'cmd1.Parameters.AddWithValue("@Debit", txtFinReqAmt.Text)
        cmd1.Parameters.AddWithValue("@Debit", 0.0)
        cmd1.Parameters.AddWithValue("@Credit", intToMaturity)
        cmd1.Parameters.AddWithValue("@Account", "223/1") 'unearned interest
        cmd1.Parameters.AddWithValue("@ContraAccount", "213/1") 'loan and advances
        cmd1.Parameters.AddWithValue("@Status", 1)
        'cm1d.Parameters.AddWithValue("@Other", [Loan Debtor Account Number])
        cmd1.Parameters.AddWithValue("@Other", txtCustNo.Text)
        cmd1.Parameters.AddWithValue("@BankAccID", "")
        cmd1.Parameters.AddWithValue("@BankAccName", "")
        'cm1d.Parameters.AddWithValue("@BatchRef", cmbBatchNo.SelectedItem.Text)
        cmd1.Parameters.AddWithValue("@BatchRef", "")
        cmd1.Parameters.AddWithValue("@TrxnDate", txtDisburseDate.Text)

        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        cmd.ExecuteNonQuery()
        cmd1.ExecuteNonQuery()
        con.Close()
    End Sub

    Protected Sub isValidSession()
        If Trim(Session("UserID")) = "" Then
            Response.Redirect("~/Logout.aspx")
        Else
        End If
    End Sub

    Protected Sub loadAppForm()
        Try
            cmd = New SqlCommand("select [APP_FORM],[APP_FORM_EXT] from QUEST_APPLICATION where ID = '" & Request.QueryString("id") & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "appForm")
            If ds.Tables(0).Rows.Count > 0 Then
                Dim fileData As Byte() = DirectCast(ds.Tables(0).Rows(0).Item("APP_FORM"), Byte())
                Dim sTempFileName As String = Server.MapPath("~/Images/" & Request.QueryString("id") & "_AppForm" & ds.Tables(0).Rows(0).Item("APP_FORM_EXT"))
                Using fs As New FileStream(sTempFileName, FileMode.OpenOrCreate, FileAccess.Write)
                    fs.Write(fileData, 0, fileData.Length)
                    fs.Flush()
                    fs.Close()
                End Using
                lnkViewAppForm.Visible = True
                lnkViewAppForm.NavigateUrl = "~/Images/" & Request.QueryString("id") & "_AppForm" & ds.Tables(0).Rows(0).Item("APP_FORM_EXT")
                lnkViewAppForm.Target = "_blank"
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub loadClasses()
        Try
            For Each it As RepeaterItem In repNavBar.Items
                Dim lnk1 = DirectCast(it.FindControl("lnkNav"), LinkButton)
                lnk1.CssClass = "inactiveView"
                If it.ItemIndex = mltAppForm.ActiveViewIndex Then
                    lnk1.CssClass = "activeView"
                End If
            Next
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub loadClientTypes()
        Try
            cmd = New SqlCommand("select * from PARA_CLIENT_TYPES", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "Clients")
            If ds.Tables(0).Rows.Count > 0 Then
                rdbClientType.DataSource = ds.Tables(0)
                rdbClientType.DataValueField = "CLIENT_TYPE"
                rdbClientType.DataTextField = "CLIENT_TYPE"
            Else
                rdbClientType.DataSource = Nothing
            End If
            rdbClientType.DataBind()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub loadListbox()
        Try
            'If txtAccToKeep1.Text <> "" Then
            '    cmd = New SqlCommand("select id, convert(varchar,Description)  + '           ' + Category + '             ' + convert(varchar,Debit) + '             ' + convert(varchar,Credit) as description from Accounts_Transactions where Description  like '%" & Trim(txtAccToKeep1.Text) & "%' ", con)
            'Else
            '  If search = "" Then
            cmd = New SqlCommand("select id, AccountName  + '  ' + convert(varchar,MainAccount)  + '/' + convert(varchar,SubAccount) as AccountName from tbl_FinancialAccountsCreation where MainAccount=212", con)
            'End If
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "LRS2")
            If ds.Tables(0).Rows.Count > 0 Then
                cmbddlist.Visible = True
                cmbddlist.DataSource = ds.Tables(0)
                cmbddlist.DataTextField = "AccountName"
                cmbddlist.DataValueField = "id"
            Else
                cmbddlist.DataSource = Nothing
            End If
            cmbddlist.DataBind()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub loadNavBar()
        Try
            Dim ViewCount As Integer = Me.mltAppForm.Views.Count
            Dim ActiveIndex As Integer = Me.mltAppForm.ActiveViewIndex
            Dim lnk As LinkButton = DirectCast(repNavBar.FindControl("lnkNav"), LinkButton)
            Dim dt As New DataTable
            Dim ds As New DataSet
            dt.Columns.Add("PageNumber")
            dt.Columns.Add("ViewNumber")
            'For Each vw As View In mltappform.Views
            '    dt.Rows.Add(vw.
            'Next
            For i = 0 To ViewCount - 1
                dt.Rows.Add(i + 1, i)
                'dt.Rows.Add(mltappform.Views(i).ID, i)
            Next
            repNavBar.DataSource = dt
            repNavBar.DataBind()
            loadClasses()
        Catch ex As Exception
        End Try
    End Sub

    Protected Sub loadOtherLoans()
        Try
            cmd = New SqlCommand("select [OTHER_DESC] as [DESCRIPTION],[OTHER_ACCNO] as [ACCOUNT NUMBER],CONVERT(DECIMAL(30,2),[OTHER_AMT]) as [AMOUNT] from QUEST_OTHER_LOANS where CUSTOMER_NUMBER='" & txtCustNo.Text & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "Other")
            If ds.Tables(0).Rows.Count > 0 Then
                grdOtherLoan.DataSource = ds.Tables(0)
            Else
                grdOtherLoan.DataSource = Nothing
            End If
            grdOtherLoan.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub loadUploadedFiles(loanID As String)
        Try
            cmd = New SqlCommand("select * from QUEST_DOCUMENTS where LOAN_ID='" & loanID & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "QD")
            If ds.Tables(0).Rows.Count > 0 Then
                grdDocuments.DataSource = ds.Tables(0)
            Else
                grdDocuments.DataSource = Nothing
            End If
            grdDocuments.DataBind()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Try
            isValidSession()
            Page.MaintainScrollPositionOnPostBack = True
            con = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            If Not IsPostBack Then
                globLoanID = Request.QueryString("id")
                mltAppForm.ActiveViewIndex = 0
                btnNavBack.Enabled = False
                btnNavBack.CssClass = "disabledNavButton"
                loadNavBar()
                loadClientTypes()
                getAppHistory()
                getAppDetails(globLoanID)
                writeSubmitButton(Session("ROLE"))
                'loadAppForm()
                lnkViewAppForm.NavigateUrl = "Amortization.aspx?ID=" & globLoanID & "&App=1"
                lnkAppRating.NavigateUrl = "ApplicationRating.aspx?loanID=" & globLoanID
                If amortizationAlreadyCreated(globLoanID) Then
                    lnkAmortizationSchedule.NavigateUrl = "rptAmortizationSchedule.aspx?loanID=" & globLoanID
                    lnkAmortizationSchedule.Visible = True
                End If
                loadUploadedFiles(globLoanID)
                If Session("ROLE") <> "1024" Then
                    btnGenAgrmt.Visible = False
                    chkPartial.Visible = True
                ElseIf Session("ROLE") = "4042" Then
                    btnGenAgrmt.Visible = True
                    chkPartial.Visible = False
                End If
            End If
            loadListbox()
            'ClientScript.RegisterStartupScript(Me.GetType, "disburse", "<script type=""text/javascript"">showDisburseAmt();</script>")
        Catch ex As Exception
        End Try
    End Sub
#Region "Armotization"
#End Region
    Protected Sub rdbSubIndividual_SelectedIndexChanged(sender As Object, e As EventArgs) Handles rdbSubIndividual.SelectedIndexChanged

    End Sub

    Protected Sub recordDisbursalTrans(custNo As String, loanID As String, amt As Double)
        'cmd = New SqlCommand("insert into QUEST_TRANSACTIONS (CUST_NO,LOANID,TRANS_DATE,TRANS_DESC,DEBIT,CREDIT,BAL_BFWD,BAL_CFWD) VALUES ('" & custNo & "','" & loanID & "',GETDATE(),'Loan Disbursement','" & amt & "','0','0','" & amt & "')", con)
        cmd = New SqlCommand("insert into QUEST_TRANSACTIONS (CUST_NO,LOANID,TRANS_DATE,TRANS_DESC,DEBIT,CREDIT,BAL_BFWD,BAL_CFWD) VALUES ('" & custNo & "','" & loanID & "','" & txtDisburseDate.Text & "','Loan Disbursement','" & amt & "','0','0','" & amt & "')", con)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
    End Sub
    Protected Sub repNavBar_ItemCommand(source As Object, e As RepeaterCommandEventArgs) Handles repNavBar.ItemCommand
        If e.CommandName = "ChangeView" Then
            Dim lnk = DirectCast(e.Item.FindControl("lnkNav"), LinkButton)
            'lnk.CssClass = "activeView"
            mltAppForm.ActiveViewIndex = lnk.CommandArgument
            loadClasses()
            If mltAppForm.ActiveViewIndex = mltAppForm.Views.Count - 1 Then
                btnNavNext.Enabled = False
                btnNavNext.CssClass = "disabledNavButton"
                btnNavBack.Enabled = True
                btnNavBack.CssClass = "navButton"
            ElseIf mltAppForm.ActiveViewIndex > 0 Then
                btnNavBack.Enabled = True
                btnNavBack.CssClass = "navButton"
                btnNavNext.Enabled = True
                btnNavNext.CssClass = "navButton"
            ElseIf mltAppForm.ActiveViewIndex = 0 Then
                btnNavBack.Enabled = False
                btnNavBack.CssClass = "disabledNavButton"
                btnNavNext.Enabled = True
                btnNavNext.CssClass = "navButton"
            End If
        End If
    End Sub

    Protected Sub saveComment()
        Try
            'If Not (Trim(txtComment.Text) = "" Or Trim(txtRecAmt.Text) = "") Then
            cmd = New SqlCommand("insert into REQUEST_HISTORY (LOANID,COMMENT_DATE,USERID,COMMENT,RECOMMENDED_AMT) values('" & Request.QueryString("id") & "',GETDATE(),'" & Session("UserID") & "','" & BankString.removeSpecialCharacter(txtComment.Text) & "','" & txtRecAmt.Text & "')", con)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
            'End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub tickSSB()
        Try
            If rdbSubIndividual.SelectedValue = "SSB" Then
                chkTickSSB.Visible = True
                'btnSubmit.Enabled = False
                btnSubmit.Style.Add("display", "none")
                lblTickSSB.Visible = True
            Else
                lblTickSSB.Visible = False
                chkTickSSB.Visible = False
            End If
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub writeSubmitButton(ByVal roleID As String)
        If roleID = "4042" Then
            btnSubmit.Text = "Recommend"
        ElseIf roleID = "4043" Then
            btnSubmit.Text = "Approve"
        ElseIf roleID = "4044" Then
            btnSubmit.Text = "Approve"
        ElseIf roleID = "1024" Then
            'btnSubmit.Text = "Approve for Disbursal"
            btnSubmit.Text = "Disburse"
            lblDisburseDate.Visible = True
            txtDisburseDate.Visible = True
            'ElseIf roleID = "4041" Then
            '    btnSubmit.Text = "Disburse"
        End If
    End Sub
End Class