﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports CreditManager
Imports ErrorLogging

Partial Class Credit_ApplicationApproval
    Inherits System.Web.UI.Page
    Dim adp As SqlDataAdapter
    Dim cmd As SqlCommand
    Dim con As New SqlConnection

    Public Sub fillType()
        Try
            Dim ds As New DataSet
            cmd = New SqlCommand("Select * from Quest_Assets", con)
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "Assets")
            ddlAssets.Items.Add("")
            ddlAssets.DataSource = ds.Tables(0)
            ddlAssets.DataValueField = "Selling_Price"
            ddlAssets.DataTextField = "Name"
            ddlAssets.DataBind()
            ddlAssets.Items.Insert(0, "--SELECT--")
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Function amortizationAlreadyCreated(loanID As String) As Boolean
        Dim ds As New DataSet
        Using cmd = New SqlCommand("select * from AMORTIZATION_SCHEDULE where LOANID='" & loanID & "'", con)
            adp = New SqlDataAdapter(cmd)
        End Using
        adp.Fill(ds, "AMO")
        If ds.Tables(0).Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If
    End Function

    Protected Sub btnDisburse_Click(sender As Object, e As EventArgs) Handles btnDisburse.Click
        Try
            If Trim(txtDisburseDate.Text) = "" Or Not IsDate(txtDisburseDate.Text) Then
                msgbox("Please enter disbursement date")
                'txtDisburseDate.Focus()
            ElseIf Trim(cmbBanks.SelectedItem.Text) = "Select Account" Then
                msgbox("Please select the account to disburse from")
            Else
                If Not chkPartial.Checked Then
                    txtAmtToDisburse.Text = txtFinReqAmt.Text
                End If
                If Convert.ToDouble(txtAmtToDisburse.Text) > Convert.ToDouble(txtFinReqAmt.Text) Then
                    msgbox("Amount to disburse is greater than amount applied")
                Else
                    '''''''''''''''''''''''first save amt to disburse********************
                    '''''''''''''''''''''''RUN IN STORED PROCEDURE************************
                    cmd = New SqlCommand("sp_disburse", con)
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@loanID", Request.QueryString("id"))
                    cmd.Parameters.AddWithValue("@amtToDisburse", txtAmtToDisburse.Text.Replace(",", ""))
                    cmd.Parameters.AddWithValue("@disburseDate", txtDisburseDate.Text)
                    cmd.Parameters.AddWithValue("@userID", Session("ID"))
                    If con.State = ConnectionState.Open Then
                        con.Close()
                    End If
                    con.Open()
                    If cmd.ExecuteNonQuery() Then
                        saveComment()
                        recordDisbursalTrans(txtCustNo.Text, Request.QueryString("id"), txtAmtToDisburse.Text)
                        'If Not isAmortized(Request.QueryString("id")) Then
                        createAmortizationOptions(Request.QueryString("id"))
                        'End If

                        Dim cmdAcc = New SqlCommand("SaveAccountsTrxnsTempWithContra", con)
                        cmdAcc.CommandType = CommandType.StoredProcedure
                        cmdAcc.Parameters.AddWithValue("@Type", "System Entry")
                        cmdAcc.Parameters.AddWithValue("@Category", "Loan Disbursement")
                        cmdAcc.Parameters.AddWithValue("@Ref", Request.QueryString("id"))
                        cmdAcc.Parameters.AddWithValue("@Desc", "Disbursement")
                        cmdAcc.Parameters.AddWithValue("@Debit", txtAmtToDisburse.Text.Replace(",", ""))
                        cmdAcc.Parameters.AddWithValue("@Credit", 0.0)
                        cmdAcc.Parameters.AddWithValue("@Account", "213/1") 'loan debtor
                        'cmdAcc.Parameters.AddWithValue("@ContraAccount", IIf(Session("ROLE") = "4045", cmbBanks.SelectedValue, "211/1")) 'cash
                        cmdAcc.Parameters.AddWithValue("@ContraAccount", cmbBanks.SelectedValue)
                        cmdAcc.Parameters.AddWithValue("@Status", 1)
                        cmdAcc.Parameters.AddWithValue("@Other", txtCustNo.Text)
                        cmdAcc.Parameters.AddWithValue("@BankAccID", "")
                        cmdAcc.Parameters.AddWithValue("@BankAccName", "")
                        cmdAcc.Parameters.AddWithValue("@BatchRef", "")
                        cmdAcc.Parameters.AddWithValue("@TrxnDate", txtDisburseDate.Text)
                        cmdAcc.Parameters.AddWithValue("@CaptureBy", Session("UserId"))

                        If con.State = ConnectionState.Open Then
                            con.Close()
                        End If
                        con.Open()
                        cmdAcc.ExecuteNonQuery()
                        con.Close()

                        'new function to insert interest to maturity on disbursement
                        'insertInterestAccounts(Request.QueryString("id"))
                        insertInterestAccountsTemp(Request.QueryString("id"))

                        If Session("ROLE") = "4042" Then
                            Response.Write("<script>alert('Loan successfully recommended') ; location.href='ApplicationView.aspx'</script>")
                        ElseIf Session("ROLE") = "1024" Then
                            Response.Write("<script>alert('Loan successfully disbursed') ; location.href='ApplicationView.aspx'</script>")
                        Else
                            Response.Write("<script>alert('Loan successfully approved') ; location.href='ApplicationView.aspx'</script>")
                        End If
                        Dim strEmail As String
                        Dim SignatoryEMail As String
                        'SignatoryEMail = Mailhelper.GetEMailID(ddl_SendTo.SelectedValue.ToString())

                        strEmail = "<Strong>Dear Sir/Madam,</strong><br>You Have Received A New Loan Application Request. Details are as follows<br><br>"
                        strEmail = strEmail & "<Table bgcolor='444444'><font forecolor='ffffff'>"
                        strEmail = strEmail & "<tr bgcolor='999999'><td>Date:</td><td>" & Now & "</td></tr>"
                        strEmail = strEmail & "<tr bgcolor='eeeeee'><td>Applicant Type:</td><td>" & rdbClientType.SelectedValue & "</td></tr>"
                        strEmail = strEmail & "<tr bgcolor='999999'><td>Branch:</td><td>" & lblBranchCode.Text.Trim() & " - " & lblBranchName.Text.Trim() & "</td></tr>"
                        'strEmail = strEmail & "<tr bgcolor='999999'><td>Branch Name:</td><td>" & txt_BranchName.Text.Trim() & "</td></tr>"
                        strEmail = strEmail & "<tr bgcolor='999999'><td>Client Name:</td><td>" & txtForenames.Text & " " & txtSurname.Text & "</td></tr>"
                        'strEmail = strEmail & "<tr bgcolor='999999'><td>Transaction Type:</td><td>" & ddl_TransactionTy.SelectedItem.Text.Trim() & "</td></tr>"
                        strEmail = strEmail & "<tr bgcolor='999999'><td>Amount:</td><td>" & txtFinReqAmt.Text & "</td></tr>"
                        strEmail = strEmail & "</font></Table>"
                        strEmail = strEmail & "<br><Strong>Thanks & Regards,<br>IT Support Team</strong>"
                        If Session("ROLE") = "4042" Then
                            SignatoryEMail = Mailhelper.GetMultiBranchRoleEMailID(Session("BRANCHCODE"), "4043")
                            If Trim(SignatoryEMail) = "" Then
                                SignatoryEMail = Mailhelper.GetMultipleEMailID("4043")
                            End If
                            Mailhelper.SendMailMessage("administrator", SignatoryEMail, "", "", "Escrow Credit Management - Loan Application", strEmail)
                        ElseIf Session("ROLE") = "4043" Then
                            SignatoryEMail = Mailhelper.GetMultiBranchRoleEMailID(Session("BRANCHCODE"), "4044")
                            If Trim(SignatoryEMail) = "" Then
                                SignatoryEMail = Mailhelper.GetMultipleEMailID("4044")
                            End If
                            Mailhelper.SendMailMessage("administrator", SignatoryEMail, "", "", "Escrow Credit Management - Loan Application", strEmail)
                        End If
                    End If

                End If
            End If

        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub btnGenAgrmt_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGenAgrmt.Click
        Try
            Dim strscript As String = "<script langauage=JavaScript>"
            strscript += "window.open('rptAcknowledgement.aspx?ID=" & Request.QueryString("id") & "');"
            strscript += "</script>"
            ClientScript.RegisterStartupScript(Me.GetType(), "newwin", strscript)
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub btnReject_Click(sender As Object, e As EventArgs) Handles btnReject.Click
        Try
            Dim retRole = ""
            If Session("ROLE") = "4044" Then
                retRole = "4043"
            ElseIf Session("ROLE") = "4043" Then
                retRole = "4042"
            ElseIf Session("ROLE") = "4042" Then
                retRole = "4041"
            ElseIf Session("ROLE") = "1024" Or Session("ROLE") = "4045" Then
                retRole = "4044"
            End If
            retRole = "4041"
            cmd = New SqlCommand("update QUEST_APPLICATION set STATUS='REJECTED', SEND_TO='" & retRole & "',LAST_ID='" & Session("ID") & "' where ID='" & ViewState("loanID") & "'", con)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            If cmd.ExecuteNonQuery Then
                Dim comm = ""
                If Trim(txtComment.Text) = "" Then
                    comm = "REJECTED"
                Else
                    comm = txtComment.Text
                End If
                'If Not (Trim(txtComment.Text) = "" Or Trim(txtRecAmt.Text) = "") Then
                saveComment()
                Dim strEmail As String
                Dim SignatoryEMail As String
                'SignatoryEMail = Mailhelper.GetEMailID(ddl_SendTo.SelectedValue.ToString())

                strEmail = "Dear Sir/Madam,<br/><br/>A loan applicaation you processed has been returned. Details of the application are as follows<br><br>"
                strEmail = strEmail & "<table style='border: 1px solid black; width:750px;border-collapse: collapse; font-size:11px'>"
                strEmail = strEmail & "<tr style='background-color: #f5f5f5;padding: 15px;text-align: left;'><th style='border: 1px solid black;'>Client Name:</th><td style='border: 1px solid black;'>" & txtSurname.Text & " " & txtForenames.Text & "</td></tr>"
                strEmail = strEmail & "<tr style='background-color: white;padding: 15px;text-align: left;'><th style='border: 1px solid black;'>Date:</th><td style='border: 1px solid black;'>" & Now & "</td></tr>"
                strEmail = strEmail & "<tr style='background-color: #f5f5f5;padding: 15px;text-align: left;'><th style='border: 1px solid black;'>Applicant Type:</th><td style='border: 1px solid black;'>" & rdbClientType.SelectedValue & "</td></tr>"
                strEmail = strEmail & "<tr style='background-color: white;padding: 15px;text-align: left;'><th style='border: 1px solid black;'>Product:</th><td style='border: 1px solid black;'>" & cmbProductType.SelectedItem.Text.ToString & "</td></tr>"
                strEmail = strEmail & "<tr style='background-color: #f5f5f5;padding: 15px;text-align: left;'><th style='border: 1px solid black;'>Sector:</th><td style='border: 1px solid black;'>" & cmbSector.SelectedItem.Text.ToString & "</td></tr>"
                strEmail = strEmail & "<tr style='background-color: white;padding: 15px;text-align: left;'><th style='border: 1px solid black;'>Branch:</th><td style='border: 1px solid black;'>" & lblBranchCode.Text.Trim() & " - " & lblBranchName.Text.Trim() & "</td></tr>"
                strEmail = strEmail & "<tr style='background-color: #f5f5f5;padding: 15px;text-align: left;'><th style='border: 1px solid black;'>Amount:</th><td style='border: 1px solid black;'>" & FormatCurrency(txtFinReqAmt.Text).ToString.Replace("Z", "US") & "</td></tr>"
                strEmail = strEmail & "</table>"
                strEmail = strEmail & "<br/>Thanks & Regards,<br/><b>Escrow 360 Support Team</b>"
                strEmail = strEmail + "<br/><br/><p style='font-size:10px; color:gray;'>Powered by <a href='escrowsystems.net'>Escrow Systems</a></p>"
                SignatoryEMail = Mailhelper.GetEMailID(ViewState("prev"))
                Mailhelper.SendMailMessage("administrator", SignatoryEMail, "", "", "Escrow Credit Management - Loan Application", strEmail)
                Response.Write("<script>alert('Loan successfully rejected'); location.href='ApplicationView.aspx';</script>")
            Else
                notify("Error saving", "error")
            End If
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- btnReject_Click", ex.ToString)
        End Try
    End Sub

    Protected Sub btnSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        Try
            If Trim(txtRecAmt.Text) = "" Or Not IsNumeric(txtRecAmt.Text) Then
                CreditManager.notify("Enter recommended amount", "error")
                txtRecAmt.Focus()
                Exit Sub
            Else
                If CDbl(txtRecAmt.Text) = 0 Then
                    notify("Recommended amount cannot be 0", "error")
                    txtRecAmt.Focus()
                    Exit Sub
                ElseIf CDbl(txtRecAmt.Text) > CDbl(txtFinReqAmt.Text) Then
                    notify("Recommended amount cannot be greater than the applied amount", "error")
                    txtRecAmt.Focus()
                    Exit Sub
                End If
            End If
            If ViewState("StageAction") = "Disbursement" And btnSubmit.Text = "Disburse" Then
                btnDisburse_Click(sender, New EventArgs)
            Else
                'if is final disbursal then create armotization schedule'
                Dim cmdSubmit = New SqlCommand("update QUEST_APPLICATION set STATUS='" & ViewState("StageName") & "',SEND_TO='" & ViewState("NextRole") & "',LAST_ID='" & Session("ID") & "',[ApprovalNumber]=[ApprovalNumber]+1 where ID='" & ViewState("loanID") & "'", con)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                If cmdSubmit.ExecuteNonQuery() Then
                    saveComment()
                    If btnSubmit.Text = "Recommend" Then
                        Response.Write("<script>alert('Loan successfully recommended') ; location.href='ApplicationView.aspx'</script>")
                    ElseIf btnSubmit.Text = "Approve" Then
                        Response.Write("<script>alert('Loan successfully approved') ; location.href='ApplicationView.aspx'</script>")
                    ElseIf btnSubmit.Text = "Disburse" Then
                        Response.Write("<script>alert('Loan successfully disbursed') ; location.href='ApplicationView.aspx'</script>")
                    End If
                    Dim strEmail As String
                    Dim SignatoryEMail As String
                    strEmail = "Dear Sir/Madam,<br/><br/>You have received a request for " & ViewState("NextStageName") & ". Details of the application are as follows<br><br>"
                    strEmail = strEmail & "<table style='border: 1px solid black; width:750px;border-collapse: collapse; font-size:11px'>"
                    strEmail = strEmail & "<tr style='background-color: #f5f5f5;padding: 15px;text-align: left;'><th style='border: 1px solid black;'>Client Name:</th><td style='border: 1px solid black;'>" & txtSurname.Text & " " & txtForenames.Text & "</td></tr>"
                    strEmail = strEmail & "<tr style='background-color: white;padding: 15px;text-align: left;'><th style='border: 1px solid black;'>Date:</th><td style='border: 1px solid black;'>" & Now & "</td></tr>"
                    strEmail = strEmail & "<tr style='background-color: #f5f5f5;padding: 15px;text-align: left;'><th style='border: 1px solid black;'>Applicant Type:</th><td style='border: 1px solid black;'>" & rdbClientType.SelectedValue & "</td></tr>"
                    strEmail = strEmail & "<tr style='background-color: white;padding: 15px;text-align: left;'><th style='border: 1px solid black;'>Product:</th><td style='border: 1px solid black;'>" & cmbProductType.SelectedItem.Text.ToString & "</td></tr>"
                    strEmail = strEmail & "<tr style='background-color: #f5f5f5;padding: 15px;text-align: left;'><th style='border: 1px solid black;'>Sector:</th><td style='border: 1px solid black;'>" & cmbSector.SelectedItem.Text.ToString & "</td></tr>"
                    strEmail = strEmail & "<tr style='background-color: white;padding: 15px;text-align: left;'><th style='border: 1px solid black;'>Branch:</th><td style='border: 1px solid black;'>" & lblBranchCode.Text.Trim() & " - " & lblBranchName.Text.Trim() & "</td></tr>"
                    strEmail = strEmail & "<tr style='background-color: #f5f5f5;padding: 15px;text-align: left;'><th style='border: 1px solid black;'>Amount:</th><td style='border: 1px solid black;'>" & FormatCurrency(txtFinReqAmt.Text).ToString.Replace("Z", "US") & "</td></tr>"
                    strEmail = strEmail & "</table>"
                    strEmail = strEmail & "<br/>Thanks & Regards,<br/><b>Escrow 360 Support Team</b>"
                    strEmail = strEmail + "<br/><br/><p style='font-size:10px; color:gray;'>Powered by <a href='escrowsystems.net'>Escrow Systems</a></p>"

                    SignatoryEMail = Mailhelper.GetMultipleEMailID(ViewState("NextRole"))
                    Mailhelper.SendMailMessage("administrator", SignatoryEMail, "", "", "Escrow 360 Credit Management - Loan Application", strEmail)

                End If
            End If
            con.Close()
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- btnSubmit_Click()", ex.ToString)
        End Try
    End Sub

    Protected Sub chkPartial_CheckedChanged(sender As Object, e As EventArgs) Handles chkPartial.CheckedChanged
        If chkPartial.Checked Then
            modalDisburse.Visible = True
        Else
            modalDisburse.Visible = False
        End If
    End Sub

    Protected Sub chkTickSSB_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkTickSSB.CheckedChanged
        Try
            If chkTickSSB.Checked Then
                lblTickSSB.Visible = False
                btnSubmit.Enabled = True
            Else
                lblTickSSB.Visible = True
                btnSubmit.Enabled = False
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub createAmortizationOptions(ByVal loanID As String)
        Try
            cmd = New SqlCommand("select * from QUEST_APPLICATION where ID='" & loanID & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "LOANS")
            Dim repOpt As String = ""
            Dim intSett As String = ""
            If ds.Tables(0).Rows.Count > 0 Then
                If ds.Tables(0).Rows(0).Item("FIN_REPAY_OPT") = "Interest" Then
                    'amortizeSimple(loanID)
                    cmd = New SqlCommand("sp_amortize_simple_daily", con)
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@loanID", loanID)
                ElseIf ds.Tables(0).Rows(0).Item("FIN_REPAY_OPT") = "Balance" Then
                    'amortizeNormal(loanID)
                    cmd = New SqlCommand("sp_amortize_normal_daily", con)
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@loanID", loanID)
                    'amortizeInterestFixed(loanID)
                Else
                    'amortizeNormal(loanID)
                    cmd = New SqlCommand("sp_amortize_normal_daily", con)
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@loanID", loanID)
                End If
                If con.State <> ConnectionState.Closed Then
                    con.Close()
                End If
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End If
        Catch ex As Exception
            WriteLogFile(Session("UserId"), "QuestCredit/ApplicationApproval - createAmortizationOptions(" & loanID & ")", ex.Message)
            msgbox("Unable to create amortization schedule. Make sure all parameters are entered")
        End Try
    End Sub

    'Protected Sub ddlAssets_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlAssets.SelectedIndexChanged
    '    txtFinReqAmt.Text = ddlAssets.SelectedValue
    'End Sub

    Protected Sub getAppDetails(ByVal loanID As String)
        Try
            cmd = New SqlCommand("select *,convert(varchar,DOB,106) as DOB1,convert(varchar,ISSUE_DATE,106) as ISSUE_DATE1,convert(varchar,GUARANTOR_DOB,106) as GUARANTOR_DOB1 from QUEST_APPLICATION where ID='" & loanID & "'", con)
            Dim ds As New DataSet
            Dim adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "APP")
            If ds.Tables(0).Rows.Count > 0 Then
                Try
                    ViewState("prev") = ds.Tables(0).Rows(0).Item("LAST_ID")
                Catch ex As Exception
                    ViewState("prev") = ""
                End Try
                getNextApproval(ds.Tables(0).Rows(0).Item("ApprovalNumber") + 1)
                txtCustNo.Text = ds.Tables(0).Rows(0).Item("CUSTOMER_NUMBER")
                txtSurname.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SURNAME"))
                txtForenames.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FORENAMES"))
                lblBranchCode.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("BRANCH_CODE"))
                lblBranchName.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("BRANCH_NAME"))
                txtAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ADDRESS"))
                'txtCreditLimit.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CREDIT_LIMIT"))
                txtPhoneNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PHONE_NO"))
                txtCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CITY"))
                txtCurrEmployer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMPLOYER"))
                txtEducationOther.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("EDUCATION"))
                txtEmpAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_ADD"))
                txtEmpCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_CITY"))
                txtEmpEmail.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_EMAIL"))
                txtEmpFax.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_FAX"))
                'Try
                '    txtEmpHowLong.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_LENGTH")), 0)
                'Catch ex As Exception
                '    txtEmpHowLong.Text = ""
                'End Try
                Try
                    txtEmpOtherIncome.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_INCOME")), 2)
                Catch ex As Exception

                End Try

                txtEmpPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_PHONE"))
                txtEmpPosition.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_POSITION"))
                Try
                    txtEmpSalary.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_SALARY")), 2)
                Catch ex As Exception
                    txtEmpSalary.Text = ""
                End Try
                Try
                    txtHouseHowLong.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("HOME_LENGTH")), 0)
                Catch ex As Exception
                    txtHouseHowLong.Text = ""
                End Try

                txtIDNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("IDNO"))
                txtNationality.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("NATIONALITY"))
                txtNoChildren.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("NO_CHILDREN"))
                txtNoDependant.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("NO_DEPENDANTS"))
                'txtPrevEmpAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_ADD"))
                'Try
                '    txtPrevEmpAnnualIncome.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_INCOME")), 2)
                'Catch ex As Exception
                '    txtPrevEmpAnnualIncome.Text = ""
                'End Try

                'txtPrevEmpCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_CITY"))
                'txtPrevEmpEmail.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_EMAIL"))
                'txtPrevEmpFax.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_FAX"))
                'Try
                '    txtPrevEmpHowLong.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_LENGTH")), 0)
                'Catch ex As Exception
                '    txtPrevEmpHowLong.Text = ""
                'End Try

                'txtPrevEmployer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMPLOYER"))
                'txtPrevEmpPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_PHONE"))
                'txtPrevEmpPosition.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_POSITION"))
                'Try
                '    txtPrevEmpSalary.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("PREV_EMP_SALARY")), 2)
                'Catch ex As Exception
                '    txtPrevEmpSalary.Text = ""
                'End Try
                Try
                    txtRent.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("MONTHLY_RENT")), 2)
                Catch ex As Exception
                    txtRent.Text = ""
                End Try

                txtSpouse.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_NAME"))
                txtSpouseEmployer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_EMPLOYER"))
                txtSpouseOccupation.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_OCCUPATION"))
                txtSpousePhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("SPOUSE_PHONE"))
                txtTradeRef1.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("TRADE_REF1"))
                txtTradeRef2.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("TRADE_REF2"))
                txtGuarCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_CITY"))
                txtGuarCurrAdd.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_ADD"))
                txtGuarCurrEmp.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMPLOYER"))
                txtGuarEmpAdd.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_ADD"))
                txtGuarEmpEmail.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_EMAIL"))
                txtGuarEmpFax.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_FAX"))
                Try
                    txtGuarEmpLength.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_LENGTH")), 0)
                Catch ex As Exception
                    txtGuarEmpLength.Text = 0
                End Try
                Try
                    txtGuarEmpIncome.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_INCOME")), 2)
                Catch ex As Exception
                    txtGuarEmpIncome.Text = 0
                End Try
                txtGuarEmpPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_PHONE"))
                txtGuarEmpPosition.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_POSTN"))
                Try
                    txtGuarHomeLength.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_HOME_LENGTH")), 0)
                Catch ex As Exception
                    txtGuarHomeLength.Text = ""
                End Try
                Try
                    txtGuarEmpSalary.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_EMP_SALARY")), 2)
                Catch ex As Exception
                    txtGuarEmpSalary.Text = ""
                End Try
                txtGuarIDNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_IDNO"))
                Try
                    txtGuarMonthRent.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_RENT")), 2)
                Catch ex As Exception
                    txtGuarMonthRent.Text = ""
                End Try
                txtGuarName.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_NAME"))
                txtGuarNameRelative.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_NAME"))
                txtGuarPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_PHONE"))
                txtGuarRelAddress.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_ADD"))
                txtGuarRelCity.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_CITY"))
                txtGuarRelPhone.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_PHONE"))
                txtGuarRelReltnship.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_REL_RELTNSHP"))
                txtFinReqAccNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_ACCNO"))
                Try
                    txtFinReqAmt.Text = FormatNumber(BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_AMT")), 2)
                Catch ex As Exception
                    txtFinReqAmt.Text = ""
                End Try
                Try
                    txtRecAmt.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_AMT"))
                Catch ex As Exception
                    txtRecAmt.Text = ""
                End Try

                Try
                    txtAmtToDisburse.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_AMT"))
                Catch ex As Exception
                    txtAmtToDisburse.Text = ""
                End Try

                txtFinReqBank.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_BANK"))
                txtFinReqBranchCode.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_BRANCH_CODE"))
                txtFinReqBranchName.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_BRANCH"))
                txtFinReqIntRate.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_INT_RATE"))
                txtFinReqPurpose.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_PURPOSE"))
                txtFinReqSecOffer.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_SEC_OFFER"))
                txtFinReqSource.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_SRC_REPAYMT"))
                txtFinReqTenor.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_TENOR"))
                txtQuesAgent.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("QUES_AGENT"))
                txtQuesEmployee.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("QUES_EMPLOYEE"))
                txtInterestRate.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("INT_RATE"))
                txtInsuranceRate.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("INSURANCE_RATE"))
                txtAdminRate.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ADMIN_RATE"))

             bdpFinReqRepaymt.Text=BankString.isNullString(ds.Tables(0).Rows(0).Item("FIN_REPAY_DATE"))

                Try
                      cmbSector.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("Sector"))
                Catch ex As Exception
                    cmbSector.ClearSelection()
                End Try
                Try
                    cmbProductType.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("FinProductType"))
                Catch ex As Exception
                    cmbProductType.ClearSelection()
                End Try
                loadOtherLoans()
                Try
                    rdbClientType.SelectedValue = ds.Tables(0).Rows(0).Item("CUSTOMER_TYPE")
                Catch ex As Exception
                    rdbClientType.ClearSelection()
                End Try
                Try
                    rdbGender.SelectedValue = ds.Tables(0).Rows(0).Item("GENDER")
                Catch ex As Exception
                    rdbGender.ClearSelection()
                End Try
                Try
                    cmbEducation.SelectedValue = ds.Tables(0).Rows(0).Item("EDUCATION")
                Catch ex As Exception
                    cmbEducation.ClearSelection()
                End Try
                Try
                    rdbQuesHow.SelectedValue = ds.Tables(0).Rows(0).Item("QUES_HOW")
                Catch ex As Exception
                    rdbQuesHow.ClearSelection()
                End Try
                Try
                    rdbGuarHomeType.SelectedValue = ds.Tables(0).Rows(0).Item("GUARANTOR_HOME_TYPE")
                Catch ex As Exception
                    rdbGuarHomeType.ClearSelection()
                End Try
                Try
                    cmbMaritalStatus.SelectedValue = ds.Tables(0).Rows(0).Item("MARITAL_STATUS")
                Catch ex As Exception
                    cmbMaritalStatus.ClearSelection()
                End Try
                Try
                    rdbHouse.SelectedValue = ds.Tables(0).Rows(0).Item("HOME_TYPE")
                Catch ex As Exception
                    rdbHouse.ClearSelection()
                End Try
                Try
                    rdbFinReqDisburseOption.SelectedValue = ds.Tables(0).Rows(0).Item("DISBURSE_OPTION")
                Catch ex As Exception
                    rdbFinReqDisburseOption.ClearSelection()
                End Try

                If BankString.isNullString(ds.Tables(0).Rows(0).Item("DOB1")) = "01 Jan 1900" Then
                    bdpDOB.Text = ""
                Else
                    bdpDOB.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("DOB1"))
                End If
                If BankString.isNullString(ds.Tables(0).Rows(0).Item("ISSUE_DATE1")) = "01 Jan 1900" Then
                    bdpIssDate.Text = ""
                Else
                    bdpIssDate.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ISSUE_DATE1"))
                End If
                If BankString.isNullString(ds.Tables(0).Rows(0).Item("GUARANTOR_DOB1")) = "01 Jan 1900" Then
                    bdpGuarDOB.Text = ""
                Else
                    bdpGuarDOB.Text = ds.Tables(0).Rows(0).Item("GUARANTOR_DOB1")
                End If
                If rdbClientType.SelectedValue = "Individual" Then
                    Try
                        rdbSubIndividual.Visible = True
                        rdbSubIndividual.SelectedValue = ds.Tables(0).Rows(0).Item("SUB_INDIVIDUAL")
                    Catch ex As Exception

                    End Try
                    Try
                        cmbBankAppType.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("AppTypeBank"))
                    Catch ex As Exception
                        cmbBankAppType.ClearSelection()
                    End Try
                    Try
                        cmbBranchAppType.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("AppTypeBranch"))
                    Catch ex As Exception
                        cmbBranchAppType.ClearSelection()
                    End Try
                    Try
                        cmbPDAAppType.SelectedValue = BankString.isNullString(ds.Tables(0).Rows(0).Item("PDACode"))
                    Catch ex As Exception
                        cmbPDAAppType.ClearSelection()
                    End Try
                    Try
                        txtOtherAppType.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("AppTypeOtherDesc"))
                    Catch ex As Exception
                        txtOtherAppType.Text = ""
                    End Try
                    lblSurname.Text = "Surname"
                    lblForenames.Text = "Forenames"
                    lblForenames.Visible = True
                    txtForenames.Visible = True
                ElseIf rdbClientType.SelectedValue = "Business" Then
                    lblSurname.Text = "Name"
                    lblForenames.Visible = False
                    txtForenames.Visible = False
                    txtForenames.Text = ""
                End If
                If rdbSubIndividual.SelectedValue = "SSB" Then
                   ' txtMinDept.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("MIN_DEPT"))
                    txtMinDeptNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("MIN_DEPT_NO"))
                    txtECNo.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("ECNO"))
                    txtECNoCD.Text = BankString.isNullString(ds.Tables(0).Rows(0).Item("CD"))

                    'lblMinDept.Visible = True
                    'lblMinDeptNo.Visible = True
                    'lblEmpCode.Visible = True
                    'txtMinDept.Visible = True
                    'txtMinDeptNo.Visible = True
                    txtECNo.Visible = True
                    txtECNoCD.Visible = True
                End If
                   Try
                    txtECNo.Text=BankString.isNullString(ds.Tables(0).Rows(0).Item("ECNO"))
                Catch ex As Exception
                     txtECNo.Text=""
                End Try
                txtEmpSalaryNet.Text=BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_NET"))
                txtGuarEmpAdd.Text=BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMPLOYER"))
                txtGuarCurrEmp.Text=BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_ADD"))
                txtGuarEmpPosition.Text=BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_POSITION"))
                txtEmpPhone.Text=BankString.isNullString(ds.Tables(0).Rows(0).Item("CURR_EMP_PHONE"))
                If rdbFinReqDisburseOption.SelectedValue = "Ecocash" Then
                    lblEcocashNumber.Visible = True
                    txtEcocashNumber.Visible = True
                    txtEcocashNumber.Text = ds.Tables(0).Rows(0).Item("ECOCASH_NUMBER")
                End If
            Else
            End If
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- getAppDetails()", ex.ToString)
        End Try
    End Sub

    Protected Sub getAppHistory()
        Try
            cmd = New SqlCommand("select COMMENT_DATE as [DATE], USERID as [USER],CONVERT(DECIMAL(30,2),[RECOMMENDED_AMT]) as [RECOMMENDED AMOUNT],COMMENT from REQUEST_HISTORY where LOANID='" & Request.QueryString("id") & "' order by COMMENT_DATE", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "COMMENT")
            If ds.Tables(0).Rows.Count > 0 Then
                grdAppHistory.DataSource = ds.Tables(0)
            Else
                grdAppHistory.DataSource = Nothing
            End If
            grdAppHistory.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Function getBatchNo() As String
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd As New SqlCommand("select max(isnull(nullif(SUBSTRING(BatchRef,4,10),''),0)) as MaxBatch from Accounts_Transactions where Category='Disbursment'", con)
                    Dim ds As New DataSet
                    Dim adp = New SqlDataAdapter(cmd)
                    adp.Fill(ds, "APP")
                    Dim batchNo = ""
                    If ds.Tables(0).Rows(0).Item("MaxBatch") = 0 Then
                        batchNo = "10001"
                    Else
                        batchNo = ds.Tables(0).Rows(0).Item("MaxBatch") + 1
                    End If
                    Return "Dis" & batchNo
                End Using
            End Using
        Catch ex As Exception
            ErrorLogging.WriteLogFile(Session("UserId"), "QuestCredit/ApplicationApproval---getBatchNo()", ex.Message)
            Return ""
        End Try
    End Function

    Protected Function getCommand(ByVal roleID As String) As SqlCommand
        Dim comm As New SqlCommand
        comm = New SqlCommand("update QUEST_APPLICATION set STATUS='" & ViewState("StageName") & "',SEND_TO='" & ViewState("NextRole") & "',LAST_ID='" & Session("ID") & "' where ID='" & ViewState("loanID") & "'", con)
        Return comm
    End Function

    Protected Function getEducation() As String
        If cmbEducation.SelectedValue = "Other" Then
            Return Trim("Other: " & BankString.removeSpecialCharacter(txtEducationOther.Text))
        Else
            Return cmbEducation.SelectedValue
        End If
    End Function
    Protected Sub getNextApproval(currLevel As Integer)
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
                Using cmd = New SqlCommand("select * from [ParaApprovalStages] where [StageOrder]='" & currLevel & "'", con)
                    Dim ds As New DataSet
                    Dim adp = New SqlDataAdapter(cmd)
                    adp.Fill(ds, "PAS")
                    If ds.Tables(0).Rows.Count > 0 Then
                        Dim dr = ds.Tables(0).Rows(0)
                        ViewState("StageName") = dr("StageName")
                        ViewState("StageAction") = dr("StageAction")
                    End If
                End Using
                Using cmd = New SqlCommand("select * from [ParaApprovalStages] where [StageOrder]='" & currLevel + 1 & "'", con)
                    Dim ds As New DataSet
                    Dim adp = New SqlDataAdapter(cmd)
                    adp.Fill(ds, "PAS")
                    If ds.Tables(0).Rows.Count > 0 Then
                        Dim dr = ds.Tables(0).Rows(0)
                        ViewState("NextRole") = dr("RoleId")
                        ViewState("NextStageName") = dr("StageName")
                        If dr("StageAction") = "Disbursement" Then
                            ViewState("ReadyToDisburse") = "1"
                        Else
                            ViewState("ReadyToDisburse") = "0"
                        End If
                    Else
                        ViewState("NextRole") = "0"
                        ViewState("ReadyToDisburse") = "0"
                        ViewState("NextStageName") = ""
                    End If
                End Using
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- getNextApproval()", ex.Message)
        End Try
    End Sub

    Protected Sub grdDocuments_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles grdDocuments.PageIndexChanging
        grdDocuments.PageIndex = e.NewPageIndex
        loadUploadedFiles(ViewState("loanID"))
    End Sub

    Protected Sub grdDocuments_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles grdDocuments.RowCommand
        If e.CommandName = "Select" Then
            Dim docID = e.CommandArgument
            'lblDetailID.Text = docID
            'btnModalPopup.Visible = True
            Dim strscript As String

            strscript = "<script langauage=JavaScript>"
            strscript += "window.open('viewDocument.aspx?id=" & docID & "');"
            strscript += "</script>"
            'ClientScript.RegisterStartupScript(Me.GetType(), "HideLabel", "<script type=""text/javascript"">setTimeout(""document.getElementById('" & lblAppUploadMsg.ClientID & "').style.display='none'"",5000)</script>")
            ClientScript.RegisterStartupScript(Me.GetType(), "newwin", strscript)

        End If
    End Sub

    Protected Sub insertInterestAccounts(loanID As String)
        'get ineterest to maturity
        Dim cmdInt = New SqlCommand("select max(cumulative_interest) from AMORTIZATION_SCHEDULE where LOANID='" & loanID & "'", con)
        Dim intToMaturity As Double = 0
        If con.State <> ConnectionState.Closed Then
            con.Close()
        End If
        con.Open()
        intToMaturity = cmdInt.ExecuteScalar
        con.Close()

        cmd = New SqlCommand("SaveAccountsTrxns", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@Type", "System Entry")
        cmd.Parameters.AddWithValue("@Category", "Interest Payable")
        cmd.Parameters.AddWithValue("@Ref", loanID)
        cmd.Parameters.AddWithValue("@Desc", "Interest to Maturity")
        cmd.Parameters.AddWithValue("@Debit", intToMaturity)
        cmd.Parameters.AddWithValue("@Credit", 0.0)
        cmd.Parameters.AddWithValue("@Account", "213/1")
        cmd.Parameters.AddWithValue("@ContraAccount", "223/1")
        cmd.Parameters.AddWithValue("@Status", 1)
        cmd.Parameters.AddWithValue("@Other", txtCustNo.Text)
        cmd.Parameters.AddWithValue("@BankAccID", "")
        cmd.Parameters.AddWithValue("@BankAccName", "")
        cmd.Parameters.AddWithValue("@BatchRef", "")
        cmd.Parameters.AddWithValue("@TrxnDate", txtDisburseDate.Text)

        Dim cmd1 = New SqlCommand("SaveAccountsTrxns", con)
        cmd1.CommandType = CommandType.StoredProcedure
        cmd1.Parameters.AddWithValue("@Type", "System Entry")
        cmd1.Parameters.AddWithValue("@Category", "Interest Payable")
        cmd1.Parameters.AddWithValue("@Ref", loanID)
        cmd1.Parameters.AddWithValue("@Desc", "Interest to Maturity")
        cmd1.Parameters.AddWithValue("@Debit", 0.0)
        cmd1.Parameters.AddWithValue("@Credit", intToMaturity)
        cmd1.Parameters.AddWithValue("@Account", "223/1") 'unearned interest
        cmd1.Parameters.AddWithValue("@ContraAccount", "213/1") 'loan and advances
        cmd1.Parameters.AddWithValue("@Status", 1)
        cmd1.Parameters.AddWithValue("@Other", txtCustNo.Text)
        cmd1.Parameters.AddWithValue("@BankAccID", "")
        cmd1.Parameters.AddWithValue("@BankAccName", "")
        cmd1.Parameters.AddWithValue("@BatchRef", "")
        cmd1.Parameters.AddWithValue("@TrxnDate", txtDisburseDate.Text)

        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        cmd.ExecuteNonQuery()
        cmd1.ExecuteNonQuery()
        con.Close()
    End Sub

    Protected Sub insertInterestAccountsTemp(loanID As String)
        'get ineterest to maturity
        Dim cmdInt = New SqlCommand("select max(cumulative_interest) from AMORTIZATION_SCHEDULE where LOANID='" & loanID & "'", con)
        Dim intToMaturity As Double = 0
        If con.State <> ConnectionState.Closed Then
            con.Close()
        End If
        con.Open()
        intToMaturity = cmdInt.ExecuteScalar
        con.Close()

        Using cmd = New SqlCommand("SaveAccountsTrxnsTempWithContra", con)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@Type", "System Entry")
            cmd.Parameters.AddWithValue("@Category", "Interest Payable")
            cmd.Parameters.AddWithValue("@Ref", loanID)
            cmd.Parameters.AddWithValue("@Desc", "Interest to Maturity")
            cmd.Parameters.AddWithValue("@Debit", intToMaturity)
            cmd.Parameters.AddWithValue("@Credit", 0.0)
            cmd.Parameters.AddWithValue("@Account", "213/1")
            cmd.Parameters.AddWithValue("@ContraAccount", "223/1")
            cmd.Parameters.AddWithValue("@Status", 1)
            cmd.Parameters.AddWithValue("@Other", txtCustNo.Text)
            cmd.Parameters.AddWithValue("@BankAccID", "")
            cmd.Parameters.AddWithValue("@BankAccName", "")
            cmd.Parameters.AddWithValue("@BatchRef", "")
            cmd.Parameters.AddWithValue("@TrxnDate", txtDisburseDate.Text)
            cmd.Parameters.AddWithValue("@CaptureBy", Session("UserId"))
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            cmd.ExecuteNonQuery()
            con.Close()
        End Using
    End Sub

    Protected Sub isValidSession()
        If Trim(Session("UserID")) = "" Then
            Response.Redirect("~/Logout.aspx")
        Else
        End If
    End Sub

    Protected Sub loadAppForm()
        Try
            cmd = New SqlCommand("select [APP_FORM],[APP_FORM_EXT] from QUEST_APPLICATION where ID = '" & Request.QueryString("id") & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "appForm")
            If ds.Tables(0).Rows.Count > 0 Then
                Dim fileData As Byte() = DirectCast(ds.Tables(0).Rows(0).Item("APP_FORM"), Byte())
                Dim sTempFileName As String = Server.MapPath("~/Images/" & Request.QueryString("id") & "_AppForm" & ds.Tables(0).Rows(0).Item("APP_FORM_EXT"))
                Using fs As New FileStream(sTempFileName, FileMode.OpenOrCreate, FileAccess.Write)
                    fs.Write(fileData, 0, fileData.Length)
                    fs.Flush()
                    fs.Close()
                End Using
                lnkViewAppForm.Visible = True
                lnkViewAppForm.NavigateUrl = "~/Images/" & Request.QueryString("id") & "_AppForm" & ds.Tables(0).Rows(0).Item("APP_FORM_EXT")
                lnkViewAppForm.Target = "_blank"
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub loadClientTypes()
        Try
            cmd = New SqlCommand("select * from PARA_CLIENT_TYPES", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "Clients")
            If ds.Tables(0).Rows.Count > 0 Then
                rdbClientType.DataSource = ds.Tables(0)
                rdbClientType.DataValueField = "CLIENT_TYPE"
                rdbClientType.DataTextField = "CLIENT_TYPE"
            Else
                rdbClientType.DataSource = Nothing
            End If
            rdbClientType.DataBind()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub loadDropDown(mainAcc As String)
        Try
            Using cmd = New SqlCommand("select convert(varchar,MainAccount)  + '/' + convert(varchar,SubAccount) as AccountNo, AccountName  + '  ' + convert(varchar,MainAccount)  + '/' + convert(varchar,SubAccount) as AccountName from tbl_FinancialAccountsCreation where MainAccount='" & mainAcc & "'", con)
                'End if
                Dim ds As New DataSet
                Using adp = New SqlDataAdapter(cmd)
                    adp.Fill(ds, "LRS2")
                End Using
                cmbBanks.Visible = True
                loadCombo(ds.Tables(0), cmbBanks, "AccountName", "AccountNo")
            End Using
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

   Protected Sub loadOtherLoans()
        Try
            cmd = New SqlCommand("select [OTHER_DESC] as [DESCRIPTION],[OTHER_ACCNO] as [ACCOUNT NUMBER],CONVERT(DECIMAL(30,2),[OTHER_AMT]) as [AMOUNT] from QUEST_OTHER_LOANS where CUSTOMER_NUMBER='" & txtCustNo.Text & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "Other")
            If ds.Tables(0).Rows.Count > 0 Then
                grdOtherLoan.DataSource = ds.Tables(0)
            Else
                grdOtherLoan.DataSource = Nothing
            End If
            grdOtherLoan.DataBind()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub loadUploadedFiles(loanID As String)
        Try
            cmd = New SqlCommand("select * from QUEST_DOCUMENTS where LOAN_ID='" & loanID & "'", con)
            Dim ds As New DataSet
            adp = New SqlDataAdapter(cmd)
            adp.Fill(ds, "QD")
            If ds.Tables(0).Rows.Count > 0 Then
                grdDocuments.DataSource = ds.Tables(0)
            Else
                grdDocuments.DataSource = Nothing
            End If
            grdDocuments.DataBind()
        Catch ex As Exception
            msgbox(ex.Message)
        End Try
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            isValidSession()
            Page.MaintainScrollPositionOnPostBack = True
            con = New SqlConnection(ConfigurationManager.ConnectionStrings("Constring").ConnectionString)
            If Not IsPostBack Then
                ViewState("loanID") = Request.QueryString("id")
                fillType()
                loadProductType(cmbProductType)
                loadClientTypes()
                getAppHistory()
                getAppDetails(ViewState("loanID"))
                writeSubmitButton(ViewState("StageAction"))
                loadSectors(cmbSector)
                'loadAppForm()
                lnkViewAppForm.NavigateUrl = "Amortization.aspx?ID=" & ViewState("loanID") & "&App=1"
                lnkAppRating.NavigateUrl = "ApplicationRating.aspx?loanID=" & ViewState("loanID")
                If amortizationAlreadyCreated(ViewState("loanID")) Then
                    lnkAmortizationSchedule.NavigateUrl = "rptAmortizationSchedule.aspx?loanID=" & ViewState("loanID")
                    lnkAmortizationSchedule.Visible = True
                End If
                loadUploadedFiles(ViewState("loanID"))

                If Request.QueryString("isd") = "1" Then
                    btnSubmit.Visible = False
                    btnReject.Visible = False
                End If
            End If
            'ClientScript.RegisterStartupScript(Me.GetType, "disburse", "<script type=""text/javascript"">showDisburseAmt();</script>")
        Catch ex As Exception

        End Try
    End Sub
    Protected Sub rdbDisbursementOption_SelectedIndexChanged(sender As Object, e As EventArgs) Handles rdbDisbursementOption.SelectedIndexChanged
        If rdbDisbursementOption.SelectedValue = "Cash" Then
            loadDropDown("211")
        ElseIf rdbDisbursementOption.SelectedValue = "RTGS" Then
            loadDropDown("212")
        ElseIf rdbDisbursementOption.SelectedValue = "Mobile" Then
            loadDropDown("212")
        ElseIf rdbDisbursementOption.SelectedValue = "Asset" Then
            loadDropDown("216")
        End If
    End Sub

    Protected Sub recordDisbursalTrans(custNo As String, loanID As String, amt As Double)
        'cmd = New SqlCommand("insert into QUEST_TRANSACTIONS (CUST_NO,LOANID,TRANS_DATE,TRANS_DESC,DEBIT,CREDIT,BAL_BFWD,BAL_CFWD) VALUES ('" & custNo & "','" & loanID & "',GETDATE(),'Loan Disbursement','" & amt & "','0','0','" & amt & "')", con)
        cmd = New SqlCommand("insert into QUEST_TRANSACTIONS (CUST_NO,LOANID,TRANS_DATE,TRANS_DESC,DEBIT,CREDIT,BAL_BFWD,BAL_CFWD) VALUES ('" & custNo & "','" & loanID & "','" & txtDisburseDate.Text & "','Loan Disbursement','" & amt & "','0','0','" & amt & "')", con)
        If con.State = ConnectionState.Open Then
            con.Close()
        End If
        con.Open()
        cmd.ExecuteNonQuery()
        con.Close()
    End Sub
    Protected Sub saveComment()
        Try
            Using cmd = New SqlCommand("insert into REQUEST_HISTORY (LOANID,COMMENT_DATE,USERID,COMMENT,RECOMMENDED_AMT,ROLEID,APP_STAGE) values('" & ViewState("loanID") & "',GETDATE(),'" & Session("UserID") & "','" & BankString.removeSpecialCharacter(txtComment.Text) & "','" & txtRecAmt.Text & "','" & Session("ROLE") & "','" & ViewState("StageName") & "')", con)
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Open()
                cmd.ExecuteNonQuery()
                con.Close()
            End Using
        Catch ex As Exception
            WriteLogFile(Session("UserId"), Request.Url.ToString & " --- saveComment()", ex.ToString)
        End Try
    End Sub

    Protected Sub writeSubmitButton(ByVal appStage As String)
        If appStage = "Origination" Then
            btnSubmit.Text = "Submit"
        ElseIf appStage = "Recommendation" Then
            btnSubmit.Text = "Recommend"
        ElseIf appStage = "Approval" Then
            btnSubmit.Text = "Approve"
        ElseIf appStage = "Disbursement" Then
            btnSubmit.Visible=False
            lblDisburseDate.Visible = False
            txtDisburseDate.Visible = False
            spanDDate.Visible = False
            spanDDate.Visible=false
            btnReject.Visible=false
        End If
    End Sub

    Protected Sub btnTerminate_Click(sender As Object, e As EventArgs) Handles btnTerminate.Click
        ' msgbox(ViewState("loanID"))
        Using cmd = New SqlCommand("DELETE FROM AMORTIZATION_SCHEDULE where LOANID='" & ViewState("loanID") & "' DELETE FROM AMORTIZATION_SCHEDULE_DAILY where LOANID='" & ViewState("loanID") & "' INSERT INTO QUEST_APPLICATION_Removed (LOANID, CUSTOMER_TYPE, SUB_INDIVIDUAL, CUSTOMER_NUMBER, SURNAME, FORENAMES, DOB, IDNO, ISSUE_DATE, ADDRESS, CITY, PHONE_NO, NATIONALITY, GENDER, HOME_TYPE, MONTHLY_RENT, HOME_LENGTH, MARITAL_STATUS, EDUCATION, CURR_EMPLOYER, CURR_EMP_ADD, CURR_EMP_LENGTH, CURR_EMP_PHONE, CURR_EMP_EMAIL, CURR_EMP_FAX, CURR_EMP_CITY, CURR_EMP_POSITION, CURR_EMP_SALARY, CURR_EMP_NET, CURR_EMP_INCOME, PREV_EMPLOYER, PREV_EMP_ADD, PREV_EMP_LENGTH, PREV_EMP_PHONE, PREV_EMP_EMAIL, PREV_EMP_FAX, PREV_EMP_CITY, PREV_EMP_POSITION, PREV_EMP_SALARY, PREV_EMP_NET, PREV_EMP_INCOME, SPOUSE_NAME, SPOUSE_OCCUPATION, SPOUSE_EMPLOYER, SPOUSE_PHONE, NO_CHILDREN, NO_DEPENDANTS, TRADE_REF1, TRADE_REF2, CREDIT_LIMIT, HAS_ACCOUNT, ACCOUNT_BRANCH, ACCOUNT_NUMBER, GUARANTOR_NAME, GUARANTOR_DOB, GUARANTOR_IDNO, GUARANTOR_PHONE, GUARANTOR_ADD, GUARANTOR_CITY, GUARANTOR_HOME_TYPE, GUARANTOR_RENT, GUARANTOR_HOME_LENGTH, GUARANTOR_EMPLOYER, GUARANTOR_EMP_ADD, GUARANTOR_EMP_LENGTH, GUARANTOR_EMP_PHONE, GUARANTOR_EMP_EMAIL, GUARANTOR_EMP_FAX, GUARANTOR_EMP_POSTN, GUARANTOR_EMP_SALARY, GUARANTOR_EMP_INCOME, GUARANTOR_REL_NAME, GUARANTOR_REL_ADD, GUARANTOR_REL_CITY, GUARANTOR_REL_PHONE, GUARANTOR_REL_RELTNSHP, FIN_REPAY_OPT, FIN_AMT, FIN_TENOR, FIN_INT_RATE, FIN_ADMIN, FIN_PURPOSE, FIN_SRC_REPAYMT, FIN_SEC_OFFER, FIN_BANK, FIN_BRANCH, FIN_BRANCH_CODE, FIN_ACCNO, FIN_REPAY_DATE, OTHER_DESC, OTHER_ACCNO, OTHER_AMT, QUES_HOW, QUES_EMPLOYEE, QUES_AGENT, APPL_SIGNATURE, APPL_DATE, JOINT_APPL_SIGNATURE, APP1_APPROVED, RECOMMENDED_AMT, REC_DATE, RECOMMENDED, DISBURSED, DISBURSED_DATE, APP1_SIGNATURE, APP1_DATE, APP2_APPROVED, APPROVED_AMT, APP2_SIGNATURE, APP2_DATE, INSTALLMENT, PERIOD, STATUS, SEND_TO, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE, BUS_TYPE, BUS_PERIOD, SOURCE1, SOURCE2, SOURCE3, BORROWING1, BORROWING2, BORROWING3, BRANCH_CODE, BRANCH_NAME, REPAID, AREA, LOAN_SECTOR, AMT_APPLIED, ECOCASH_NUMBER, OTHER_CHARGES, APP_FORM, APP_FORM_TYPE, DISBURSE_OPTION, APP_FORM_EXT, MIN_DEPT, MIN_DEPT_NO, ECNO, CD, SSB_NEW, SSB_CHANGE, SSB_CEASE, SSB_MONTHLY_RATE, SSB_FROM, SSB_TO, SSB_REF, SSB_GENERATOR, SSB_GEN_DATE, APPROVED_FOR_DISBURSAL, INITIATOR_ID, LM_ID, HL_ID, MD_ID, DB_IDD, LAST_ID, LO_ID, MONTH_EXPENSE, MONTH_INCOME, PREV_SALES, CURR_ESTIMATE, CROPS, FARM_PERIOD, SPOUSE_ADDRESS, SPOUSE_IDNO, IS_PARTIAL, ORIGINAL_ID, INT_RATE, INSURANCE_RATE, ADMIN_RATE, ASSET_NAME, PDACode, MaturityDate, AppTypeBank, AppTypeBranch, AppTypeOtherDesc, FinProductType, Sector, DefaultIntInterval, IntCalcMethod, IntTrigger, DaysInYear, RepaymentFreq, HasGracePeriod, GracePeriodType, GracePeriodLength, GracePeriodUnit, AllowRepaymentOnWknd, IfRepaymentFallsOnWknd, AllowEditingPaymentSchedule, RepayOrder1, RepayOrder2, RepayOrder3, RepayOrder4, TolerancePeriodNum, TolerancePeriodUnit, ArrearNonWorkingDays, PenaltyCharged, PenaltyOption, AmtToPenalise, ProductFees, ProductFeeCalc, ProductFeeAmtPerc, ApprovalNumber, ReadyToDisburse, CUSTOMER_TYPE_ID, RepaymentIntervalNum, RepaymentIntervalUnit, Bank, BankBranch, BankAccountNo, BranchCode, ExportedFile, FromLoan)select ID, CUSTOMER_TYPE, SUB_INDIVIDUAL, CUSTOMER_NUMBER, SURNAME, FORENAMES, DOB, IDNO, ISSUE_DATE, ADDRESS, CITY, PHONE_NO, NATIONALITY, GENDER, HOME_TYPE, MONTHLY_RENT, HOME_LENGTH, MARITAL_STATUS, EDUCATION, CURR_EMPLOYER, CURR_EMP_ADD, CURR_EMP_LENGTH, CURR_EMP_PHONE, CURR_EMP_EMAIL, CURR_EMP_FAX, CURR_EMP_CITY, CURR_EMP_POSITION, CURR_EMP_SALARY, CURR_EMP_NET, CURR_EMP_INCOME, PREV_EMPLOYER, PREV_EMP_ADD, PREV_EMP_LENGTH, PREV_EMP_PHONE, PREV_EMP_EMAIL, PREV_EMP_FAX, PREV_EMP_CITY, PREV_EMP_POSITION, PREV_EMP_SALARY, PREV_EMP_NET, PREV_EMP_INCOME, SPOUSE_NAME, SPOUSE_OCCUPATION, SPOUSE_EMPLOYER, SPOUSE_PHONE, NO_CHILDREN, NO_DEPENDANTS, TRADE_REF1, TRADE_REF2, CREDIT_LIMIT, HAS_ACCOUNT, ACCOUNT_BRANCH, ACCOUNT_NUMBER, GUARANTOR_NAME, GUARANTOR_DOB, GUARANTOR_IDNO, GUARANTOR_PHONE, GUARANTOR_ADD, GUARANTOR_CITY, GUARANTOR_HOME_TYPE, GUARANTOR_RENT, GUARANTOR_HOME_LENGTH, GUARANTOR_EMPLOYER, GUARANTOR_EMP_ADD, GUARANTOR_EMP_LENGTH, GUARANTOR_EMP_PHONE, GUARANTOR_EMP_EMAIL, GUARANTOR_EMP_FAX, GUARANTOR_EMP_POSTN, GUARANTOR_EMP_SALARY, GUARANTOR_EMP_INCOME, GUARANTOR_REL_NAME, GUARANTOR_REL_ADD, GUARANTOR_REL_CITY, GUARANTOR_REL_PHONE, GUARANTOR_REL_RELTNSHP, FIN_REPAY_OPT, FIN_AMT, FIN_TENOR, FIN_INT_RATE, FIN_ADMIN, FIN_PURPOSE, FIN_SRC_REPAYMT, FIN_SEC_OFFER, FIN_BANK, FIN_BRANCH, FIN_BRANCH_CODE, FIN_ACCNO, FIN_REPAY_DATE, OTHER_DESC, OTHER_ACCNO, OTHER_AMT, QUES_HOW, QUES_EMPLOYEE, QUES_AGENT, APPL_SIGNATURE, APPL_DATE, JOINT_APPL_SIGNATURE, APP1_APPROVED, RECOMMENDED_AMT, REC_DATE, RECOMMENDED, DISBURSED, DISBURSED_DATE, APP1_SIGNATURE, APP1_DATE, APP2_APPROVED, APPROVED_AMT, APP2_SIGNATURE, APP2_DATE, INSTALLMENT, PERIOD, STATUS, SEND_TO, CREATED_BY, CREATED_DATE, MODIFIED_BY, MODIFIED_DATE, BUS_TYPE, BUS_PERIOD, SOURCE1, SOURCE2, SOURCE3, BORROWING1, BORROWING2, BORROWING3, BRANCH_CODE, BRANCH_NAME, REPAID, AREA, LOAN_SECTOR, AMT_APPLIED, ECOCASH_NUMBER, OTHER_CHARGES, APP_FORM, APP_FORM_TYPE, DISBURSE_OPTION, APP_FORM_EXT, MIN_DEPT, MIN_DEPT_NO, ECNO, CD, SSB_NEW, SSB_CHANGE, SSB_CEASE, SSB_MONTHLY_RATE, SSB_FROM, SSB_TO, SSB_REF, SSB_GENERATOR, SSB_GEN_DATE, APPROVED_FOR_DISBURSAL, INITIATOR_ID, LM_ID, HL_ID, MD_ID, DB_IDD, LAST_ID, LO_ID, MONTH_EXPENSE, MONTH_INCOME, PREV_SALES, CURR_ESTIMATE, CROPS, FARM_PERIOD, SPOUSE_ADDRESS, SPOUSE_IDNO, IS_PARTIAL, ORIGINAL_ID, INT_RATE, INSURANCE_RATE, ADMIN_RATE, ASSET_NAME, PDACode, MaturityDate, AppTypeBank, AppTypeBranch, AppTypeOtherDesc, FinProductType, Sector, DefaultIntInterval, IntCalcMethod, IntTrigger, DaysInYear, RepaymentFreq, HasGracePeriod, GracePeriodType, GracePeriodLength, GracePeriodUnit, AllowRepaymentOnWknd, IfRepaymentFallsOnWknd, AllowEditingPaymentSchedule, RepayOrder1, RepayOrder2, RepayOrder3, RepayOrder4, TolerancePeriodNum, TolerancePeriodUnit, ArrearNonWorkingDays, PenaltyCharged, PenaltyOption, AmtToPenalise, ProductFees, ProductFeeCalc, ProductFeeAmtPerc, ApprovalNumber, ReadyToDisburse, CUSTOMER_TYPE_ID, RepaymentIntervalNum, RepaymentIntervalUnit, Bank, BankBranch, BankAccountNo, BranchCode, ExportedFile, FromLoan from QUEST_APPLICATION where ID='" & ViewState("loanID") & "'", con)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            If cmd.ExecuteNonQuery() Then
                removeLoanCompletely()
            End If
            con.Close()
        End Using
    End Sub
    Sub removeLoanCompletely()
        Using cmd = New SqlCommand("DELETE FROM QUEST_APPLICATION where ID='" & ViewState("loanID") & "'", con)
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            con.Open()
            If cmd.ExecuteNonQuery() Then
                Response.Write("<script>alert('Loan Removed Completely') ; location.href='ApplicationView.aspx'</script>")
            End If
            con.Close()
        End Using
    End Sub
End Class